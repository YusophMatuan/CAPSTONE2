<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminMat.css?v=1.7"?>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</head>
<body> 
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src= "media/MainLogo.png" class="navbar-logo"></a>
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.html">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.html">Purchasing</a>
          <a href="AdminSup.html">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminPurch.html">Approvals</a>
      <a href="AdminHsty.html">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="8" r="4"/>
          <path d="M4 20c0-4 4-7 8-7s8 3 8 7"/>
        </svg>
      </div>
      <span>Username</span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.html">Log Out</a>
      </div>
    </div>
  </nav>
  <?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

// Connect to database
$conn = new mysqli($servername, $username, $passwordDB, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch tools
$sql = "SELECT id, MaterialsName, Quantity, DateAdded, FastMoving, SlowMoving FROM materials";
$result = $conn->query($sql);
?>
<div class="materials-section">
    <div class="materials-header">
        <h2>MATERIALS</h2>
        <div class="header-controls">
            <input type="text" placeholder="Search" class="search-input">
            <button class="print-button">Print</button>
            <button class="add-button">Add</button>
        </div>
    </div>
    <table class="materials-table">
        <thead>
            <tr>
                <th>Material Name</th>
                <th>Action</th>
                <th>Quantity</th>
                <th>Date Added</th>
                <th>Fast Moving</th>
                <th>Slow Moving</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['MaterialsName']); ?></td>
                        <td><button class="delete-button" data-id="<?php echo $row['id']; ?>">🗑️</button></td>
                        <td><?php echo htmlspecialchars($row['Quantity']); ?></td>
                        <td><?php echo htmlspecialchars($row['DateAdded']); ?></td>
                        <td><?php echo $row['FastMoving'] ? 'Fast' : ''; ?></td>
                        <td><?php echo $row['SlowMoving'] ? 'Slow' : ''; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No materials found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<!-- Delete Modal -->
<div id="deleteModal" class="modal">
  <div class="modal-content">
    <button id="closeBtn" class="close-button">X</button>
    <p>Are you sure you want to delete?</p>
    
    <label for="Materials">Materialss:</label>
    <input type="text" id="Materials" name="Materialss" placeholder="Enter material name">

    <label for="quantity">Quantity:</label>
    <input type="number" id="quantity" name="quantity" placeholder="Enter quantity">

    <label for="date">Date:</label>
    <input type="date" id="date" name="date" value="2025-10-24">

    <button id="doneBtn">Done</button>
  </div>
</div>

<!-- Add Modal -->
<div id="addmodal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <span class="title">Add Materials</span>
      <button id="closeBtn2" class="close-button">X</button>
    </div>
<form id="MaterialsForm">
  <label for="MaterialsName">Materials name:</label>
  <input type="text" id="ToolsName" name="MaterialsName" />

  <label for="dateAdd">Date:</label>
  <input type="date" id="dateAdd" name="dateAdd" />

  <label for="quantityAdd">Quantity:</label>
  <input type="number" id="quantityAdd" name="quantityAdd" />

  <div class="radio-group">
  <label><input type="radio" name="movingType" value="fast" /> Fast Moving</label>
  <label><input type="radio" name="movingType" value="slow" /> Slow Moving</label>
</div>

  <button type="submit" id="doneButton">Done</button>
</form>
  </div>
</div>



<!-- Updated Confirmation Modal -->
<div id="updatedModal" class="modal" style="display:none;">
  <div class="modal-content" style="text-align:center; padding: 20px;">
    <p>Materials Updated!</p>
    <button id="updatedDoneBtn">Done</button>
  </div>
</div>

  <!-- Restock Warning Modal -->
  <div id="restockModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <span class="title">Restock Warning</span>
        <button id="restockCloseBtn" class="close-button" aria-label="Close modal">×</button>
      </div>
      <p>The following materials are low on stock and need to be restocked:</p>
      <ul id="lowStockList"></ul>
      <button id="restockDoneBtn">Done</button>
    </div>
  </div>

<script>
// Elements for delete modal
const deleteModal = document.getElementById('deleteModal');
const deleteCloseBtn = document.getElementById('closeBtn');
const deleteDoneBtn = document.getElementById('doneBtn');

// Elements for add modal
const addModal = document.getElementById('addmodal');
const addCloseBtn2 = document.getElementById('closeBtn2');
const addButton = document.querySelector('.add-button');
const MaterialsForm = document.getElementById('MaterialsForm');

// Confirmation modal
const updatedModal = document.getElementById('updatedModal');
const updatedDoneBtn = document.getElementById('updatedDoneBtn');

// Open delete modal on delete button click
document.querySelectorAll('.delete-button').forEach(button => {
  button.addEventListener('click', () => {
    deleteModal.style.display = 'block';

    const tr = button.closest('tr');
    const materialsName = tr ? tr.querySelector('td:first-child').textContent.trim() : '';
    const materialsInput = deleteModal.querySelector('#Materials');  // Ensure this exists in your HTML
    if (materialsInput) {
      materialsInput.value = materialsName || '';
    }

    // Store material ID for deletion
    deleteModal.dataset.materialsId = button.getAttribute('data-id');
    const currentQty = tr ? tr.querySelector('td:nth-child(3)').textContent.trim() : '';
    const quantityInput = deleteModal.querySelector('#quantity');
    if (quantityInput) {
      quantityInput.placeholder = `Max: ${currentQty}`;
    }
  });
});

// Close delete modal
deleteCloseBtn.addEventListener('click', () => {
  deleteModal.style.display = 'none';
});

// Delete Done button - perform delete and show updated modal
deleteDoneBtn.addEventListener('click', () => {
  const id = deleteModal.dataset.materialsId;
  const quantityInput = deleteModal.querySelector('#quantity');
  const quantity = quantityInput ? quantityInput.value : '';

  fetch('delete_material.php', {
    method: 'POST',
    body: new URLSearchParams({ id, quantity }),
  })
    .then(response => response.text())
    .then(data => {
      if (data.trim() === "success" || data.trim() === "deleted") {
        deleteModal.style.display = 'none';
        updatedModal.style.display = 'block';  // Show updated modal
      } else {
        alert(data);
      }
    })
    .catch(error => {
      alert("Error: " + error.message);
    });
});

// Show add modal on add button click
addButton.addEventListener('click', () => {
  if (MaterialsForm) MaterialsForm.reset();
  addModal.style.display = 'block';
});

// Close add modal on close button
addCloseBtn2.addEventListener('click', () => {
  addModal.style.display = 'none';
});

// Add form submit handler
if (MaterialsForm) {
  MaterialsForm.addEventListener('submit', event => {
    event.preventDefault();
    const formData = new FormData(MaterialsForm);

    fetch('add_material.php', {
      method: 'POST',
      body: formData,
    })
      .then(response => response.text())
      .then(data => {
        if (data.trim() === "success") {
          addModal.style.display = 'none';
          updatedModal.style.display = 'block';  // Show updated modal
        } else {
          alert("Error adding materials: " + data);
        }
      })
      .catch(error => {
        alert("Error: " + error.message);
      });
  });
}

// Close updated modal on Done button click
updatedDoneBtn.addEventListener('click', () => {
  updatedModal.style.display = 'none';
  location.reload();  // Optional: reload page after confirmation dismissed
});

// Close modals if clicking outside modal content
window.addEventListener('click', (event) => {
  if (event.target === addModal) {
    addModal.style.display = 'none';
  }
  if (event.target === deleteModal) {
    deleteModal.style.display = 'none';
  }
  if (event.target === updatedModal) {
    updatedModal.style.display = 'none';
  }
});

// Check for low stock on page load
window.addEventListener('DOMContentLoaded', () => {
  fetch('get_low_stock.php')
    .then(response => response.json())
    .then(data => {
      if (data.length > 0) {
        document.getElementById('notificationBadge').style.display = 'block';
      }
    })
    .catch(error => console.error('Error fetching low stock:', error));
});

// Handle notification bell click
document.getElementById('notificationBell').addEventListener('click', () => {
  fetch('get_low_stock.php')
    .then(response => response.json())
    .then(data => {
      const list = document.getElementById('lowStockList');
      list.innerHTML = '';
      if (data.length > 0) {
        data.forEach(item => {
          const li = document.createElement('li');
          li.textContent = `${item.MaterialsName} - Quantity: ${item.Quantity}`;
          list.appendChild(li);
        });
      } else {
        const li = document.createElement('li');
        li.textContent = 'No low stock items at the moment.';
        list.appendChild(li);
      }
      document.getElementById('restockModal').style.display = 'flex';
    })
    .catch(error => {
      console.error('Error fetching low stock:', error);
      alert('Error fetching low stock data. Please check the console for details.');
    });
});

// Close modal
document.getElementById('restockCloseBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

document.getElementById('restockDoneBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

// Close modal if clicking outside
window.addEventListener('click', (event) => {
  const modal = document.getElementById('restockModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
});


// Close modal
document.getElementById('restockCloseBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

document.getElementById('restockDoneBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

// Close modal if clicking outside
window.addEventListener('click', (event) => {
  const modal = document.getElementById('restockModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
});
</script>

</body>
</html>