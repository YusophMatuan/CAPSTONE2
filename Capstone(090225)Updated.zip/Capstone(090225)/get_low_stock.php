<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

header('Content-Type: application/json');

$conn = new mysqli($servername, $username, $passwordDB, $dbname);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

// Define thresholds
$fastMovingMax = 1000;
$fastMovingThreshold = 500; // 50% of 1000
$slowMovingMax = 50;
$slowMovingThreshold = 20; // 40% of 50 (as per user feedback)

$sql = "SELECT MaterialsName, Quantity, FastMoving, SlowMoving FROM materials WHERE
        (FastMoving = 1 AND Quantity <= ?) OR
        (SlowMoving = 1 AND Quantity <= ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $fastMovingThreshold, $slowMovingThreshold);
$stmt->execute();
$result = $stmt->get_result();

$lowStockItems = [];
while ($row = $result->fetch_assoc()) {
    $lowStockItems[] = $row;
}

$stmt->close();
$conn->close();

echo json_encode($lowStockItems);
?>
