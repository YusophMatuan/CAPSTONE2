<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminProf.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body> 
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src= "media/MainLogo.png" class="navbar-logo"></a>
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.html">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.html">Purchasing</a>
          <a href="AdminSup.html">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.html">Approvals</a>
      <a href="AdminHsty.html">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <!-- Simple user SVG icon -->
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="8" r="4"/>
          <path d="M4 20c0-4 4-7 8-7s8 3 8 7"/>
        </svg>
      </div>
      <span>Username</span>
      <div class="dropdown-content profile-dropdown-content">
    <a href="AdminProf.php">Profile Settings</a>
    <a href="index.html">Log Out</a>
    </div>
  </nav>

<!-- Profile Container -->
<div class="profile-container">
  <div class="avatar">
    <img src="media/user.png" alt="Profile Icon" class="avatar-icon" />
    <p>Add image</p>
  </div>
  <div class="user-info">
    <p><strong>Name:</strong> <?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Unknown'; ?></p>
    <p><strong>Role:</strong> <?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Unknown'; ?></p>
    <p><strong>Email:</strong> <?php echo isset($_SESSION['Email']) ? htmlspecialchars($_SESSION['Email']) : 'Unknown'; ?></p>
  </div>
</div>

<!-- Buttons -->
<div class="button-container">
  <button class="button create">Create Account</button>
  <button id="deleteButton" class="button delete">Delete Account</button>
</div>

<!-- Create Account Modal -->
<div id="createAccountModal" class="modal" style="display:none; justify-content:center; align-items:center;">
  <div class="modal-content">
    <span class="close-button">&times;</span>
    <h2>Create Account</h2>
    
    <!-- Avatar Image & Upload -->
    <div class="modal-avatar" style="cursor:pointer;">
      <img src="media/user.png" alt="User Avatar" id="profileImage" />
      <input type="file" accept="image/*" id="profileImageInput" style="display:none;" />
      <p>Click to add image</p>
    </div>

    <!-- Form -->
    <form id="createAccountForm">
      <div>
        <label for="Name">Name</label>
        <input type="text" class="form-control" id="Name" name="Name" />
      </div>
      <div>
        <label for="Email">Email</label>
        <input type="text" class="form-control" id="Email" name="Email" />
      </div>
      <div class="roles">
        <label for="admin" class="radio-inline">
          <input type="radio" name="role" value="Admin" id="admin" />Admin
        </label>
        <label for="inventory" class="radio-inline">
          <input type="radio" name="role" value="Inventory Mngr." id="inventory" />Inventory
        </label>
        <label for="project" class="radio-inline">
          <input type="radio" name="role" value="Project Mngr." id="project" />Project
        </label>
      </div>
      <div>
        <label for="password">Password</label>
        <input type="password" class="form-control" id="password" name="password" required />
      </div>
      <input type="submit" class="btn btn-primary" />
    </form>
  </div>
</div>

<!-- Delete Account Modal -->
<div id="deleteAccountModal" class="modal" style="display:none; justify-content:center; align-items:center;">
  <div class="modal-content delete-modal-content" style="max-width: 600px;">
    <span class="close-button delete-close">&times;</span>
    <h2>Delete Account</h2>
    
    <table class="delete-table">
      <thead>
        <tr>
          <th>NAME</th>
          <th>ROLE</th>
          <th>EMAIL</th>
          <th></th>
        </tr>
      </thead>
      <tbody id="deleteAccountList">
      </tbody>
    </table>

    <button id="confirmDelete" class="delete-confirm-btn">DELETE</button>
  </div>
</div>

<!-- Updated Confirmation Modal -->
 <div id="updatedModal" class="modal" style="display:none; justify-content:center; align-items:center;">
  <div class="modal-content" style="text-align:center; padding: 20px;">
    <p>Account Registered!</p>
    <button id="updatedDoneBtn">Done</button>
  </div>
</div>

<script>
// --- Create Account Modal Logic ---
const createModal = document.getElementById('createAccountModal');
const createBtn = document.querySelector('.button.create');
const closeCreateBtn = createModal.querySelector('.close-button');
const profileImage = document.getElementById('profileImage');
const profileImageInput = document.getElementById('profileImageInput');

createBtn.addEventListener('click', () => {
  createModal.style.display = 'flex';
});

closeCreateBtn.addEventListener('click', () => {
  createModal.style.display = 'none';
});

window.addEventListener('click', (event) => {
  if (event.target === createModal) {
    createModal.style.display = 'none';
  }
});

// Profile image upload preview logic
document.querySelector('.modal-avatar').addEventListener('click', () => {
  profileImageInput.click();
});



profileImageInput.addEventListener('change', () => {
  const file = profileImageInput.files[0];
  if (file) {
    const reader = new FileReader();
    reader.onload = (e) => {
      profileImage.src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
});

// --- Delete Account Modal Logic ---
const deleteModal = document.getElementById('deleteAccountModal');
const deleteBtn = document.getElementById('deleteButton');
const closeDeleteBtn = deleteModal.querySelector('.delete-close');
const confirmDeleteBtn = document.getElementById('confirmDelete');

function loadAccountsForDeletion() {
  fetch('get_accounts.php')
    .then(response => response.json())
    .then(accounts => {
      const tbody = document.getElementById('deleteAccountList');
      tbody.innerHTML = ''; // Clear existing rows

      accounts.forEach(account => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${account.Name}</td>
          <td>${account.role}</td>
          <td>${account.Email}</td>
          <td><input type="checkbox" class="delete-checkbox" data-id="${account.id}" /></td>
        `;
        tbody.appendChild(tr);
      });
    });
}

// Show modal and load accounts
deleteBtn.addEventListener('click', () => {
  loadAccountsForDeletion();
  deleteModal.style.display = 'flex';
});


closeDeleteBtn.addEventListener('click', () => {
  deleteModal.style.display = 'none';
});

window.addEventListener('click', (event) => {
  if (event.target === deleteModal) {
    deleteModal.style.display = 'none';
  }
});

confirmDeleteBtn.addEventListener('click', () => {
  const checkedBoxes = document.querySelectorAll('.delete-checkbox:checked');
  const ids = Array.from(checkedBoxes).map(cb => cb.getAttribute('data-id'));

  if (ids.length === 0) {
    alert('Please select at least one account to delete.');
    return;
  }

  fetch('delete_account.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'ids[]=' + ids.join('&ids[]=')
  })
  .then(response => response.text())
  .then(result => {
    if (result.trim() === "Success") {
      loadAccountsForDeletion(); // Refresh table
      deleteModal.style.display = 'none';
    } else {
      alert("Delete failed: " + result);
    }
  });
});


// --- Show Updated Modal on Create Form Submit ---
const createAccountForm = document.getElementById('createAccountForm');
const updatedModal = document.getElementById('updatedModal');
const updatedDoneBtn = document.getElementById('updatedDoneBtn');

createAccountForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const formData = new FormData(createAccountForm);
  fetch('connect.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    // You can check server response here before showing the modal
    console.log(data);
    updatedModal.style.display = 'flex';
  })
  .catch(error => {
    alert("Error: " + error.message);
  });
});

// IMPORTANT: This closes the Updated Modal when 'Done' button clicked
updatedDoneBtn.addEventListener('click', () => {
  updatedModal.style.display = 'none';
});


</script>

</body>
</html> 