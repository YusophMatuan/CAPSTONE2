
<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminTools.css?v=2.4" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap"
  />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" />
      <div class="navbar-company">
      <span>Art Glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg
          id="notificationBell"
          width="28"
          height="28"
          viewBox="0 0 24 24"
          fill="none"
          stroke="#31ac0e"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        >
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
          <path d="M13.73 21a2 2 0 0 1-3.46 0" />
        </svg>
        <span
          class="notification-badge"
          id="notificationBadge"
          style="display: none"
        ></span>
      </div>
    </div>
<div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.html">Log Out</a>
      </div>
    </div>
  </nav>

  <?php
  $servername = "localhost";
  $username = "root";
  $passwordDB = "";
  $dbname = "capstone";

  // Connect to database
  $conn = new mysqli($servername, $username, $passwordDB, $dbname);
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  // Fetch tools
  $sql = "SELECT id, ToolsName, Quantity, DateAdded FROM tools";
  $result = $conn->query($sql);
  ?>

  <div class="tools-section">
    <div class="tools-header">
      <h2>TOOLS</h2>
      <div class="header-controls">
        <input type="text" placeholder="Search" class="search-input" />
        <button class="print-button">Print</button>
        <button class="add-button">Add</button>
      </div>
    </div>
    <table class="tools-table">
      <thead>
        <tr>
          <th>Tool Name</th>
          <th>Action</th>
          <th>Quantity</th>
          <th>Date Added</th>
          <th>Remarks</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
          <?php while($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['ToolsName']); ?></td>
              <td>
                <button class="delete-button" data-id="<?php echo $row['id']; ?>"
                  >🗑️</button
                >
              </td>
              <td><?php echo htmlspecialchars($row['Quantity']); ?></td>
              <td><?php echo htmlspecialchars($row['DateAdded']); ?></td>
              <td><?php echo htmlspecialchars($row['Remarks'] ?? ''); ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="6">No tools found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

 <!-- Delete Modal -->
<div id="deleteModal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <h2>Confirm Deletion</h2>
      <button id="closeBtn" class="close-button">×</button>
    </div>
    
    <p>Are you sure you want to delete?</p>
    
    <div class="modal-form">
      <label for="Tools">Tools:</label>
      <input type="text" id="Tools" name="Tools" placeholder="" readonly />

      <label for="quantity">Quantity:</label>
      <input
        type="number"
        id="quantity"
        name="quantity"
        placeholder="Enter quantity"
      />

      <label for="date">Date:</label>
      <input type="date" id="date" name="date" value="2025-10-24" />

      <button id="doneBtn">Done</button>
    </div>
  </div>
</div>

  <!-- Add Modal -->
  <div id="addmodal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <span class="title">Add Tools</span>
        <button id="closeBtn2" class="close-button">X</button>
      </div>
      <form id="ToolsForm">
        <label for="ToolsName">Tools name:</label>
        <input type="text" id="ToolsName" name="ToolsName" />

        <label for="dateAdd">Date:</label>
        <input type="date" id="dateAdd" name="dateAdd" />

        <label for="quantityAdd">Quantity:</label>
        <input type="number" id="quantityAdd" name="quantityAdd" />

        <label for="remarks">Remarks:</label>
        <input type="text" id="remarks" name="remarks" placeholder="Enter remarks" />

        <button type="submit" id="doneButton">Done</button>
      </form>
    </div>
  </div>

  <!-- Updated Confirmation Modal -->
  <div id="updatedModal" class="modal" style="display: none; text-align:center; padding: 20px;">
    <div class="modal-content" style="text-align:center; padding: 20px;">
      <p>Tools Updated!</p>
      <button id="updatedDoneBtn">Done</button>
    </div>
  </div>

   <!-- Updated Notification Modal -->
  <div id="notificationModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    const deleteModal = document.getElementById("deleteModal");
    const deleteCloseBtn = document.getElementById("closeBtn");
    const deleteDoneBtn = document.getElementById("doneBtn");

    const updatedModal = document.getElementById("updatedModal");
    const updatedDoneBtn = document.getElementById("updatedDoneBtn");

    const addModal = document.getElementById("addmodal");
    const addCloseBtn2 = document.getElementById("closeBtn2");
    const addButton = document.querySelector(".add-button");
    const ToolsForm = document.getElementById("ToolsForm");

    // Show delete modal on delete button click
    document.querySelectorAll(".delete-button").forEach(button => {
      button.addEventListener("click", () => {
        deleteModal.style.display = "flex";

        const tr = button.closest("tr");
        const ToolsName = tr ? tr.querySelector("td:first-child").textContent.trim() : "";
        deleteModal.querySelector("#Tools").value = ToolsName || "";

        deleteModal.dataset.toolId = button.getAttribute("data-id");
        const currentQty = tr ? tr.querySelector("td:nth-child(3)").textContent.trim() : "";
        deleteModal.querySelector("#quantity").placeholder = `Max: ${currentQty}`;
      });
    });

    // Close delete modal
    deleteCloseBtn.addEventListener("click", () => {
      deleteModal.style.display = "none";
    });

    // Delete done button: Show modal and keep it open until manual close
    deleteDoneBtn.addEventListener("click", () => {
      updatedModal.style.display = "flex";  // Show updated modal
      deleteModal.style.display = "none";    // Hide delete modal

      const id = deleteModal.dataset.toolId;
      const quantity = deleteModal.querySelector("#quantity").value;

      fetch("delete_tool.php", {
        method: "POST",
        body: new URLSearchParams({ id, quantity }),
      })
        .then(response => response.text())
        .then(data => {
          if (data.trim() === "success" || data.trim() === "deleted") {
            // Do not auto hide or reload here
            // Wait for user to close updated modal manually
            // Fix: prevent multiple rapid clicks by disabling the Done button temporarily
            updatedDoneBtn.disabled = true;
            setTimeout(() => {
              updatedDoneBtn.disabled = false;
            }, 1000); // 1 second delay before re-enabling
          } else {
            alert(data);
            updatedModal.style.display = "none";
          }
        })
        .catch(error => {
          alert("Error: " + error.message);
          updatedModal.style.display = "none";
        });
    });

    // Show add modal on add button click
    addButton.addEventListener("click", () => {
      ToolsForm.reset();
      addModal.style.display = "flex";
    });

    // Close add modal
    addCloseBtn2.addEventListener("click", () => {
      addModal.style.display = "none";
    });

    // Add form submit: show updated modal and keep open until user closes
    ToolsForm.addEventListener("submit", event => {
      event.preventDefault();

      updatedModal.style.display = "flex";  // Show updated modal
      addModal.style.display = "none";       // Hide add modal

      const formData = new FormData(ToolsForm);

      fetch("add_tool.php", {
        method: "POST",
        body: formData,
      })
        .then(response => response.text())
        .then(response => response.text())
        .then(data => {
          if (data.trim() === "success") {
            // Get form data to add row dynamically
            const toolsName = document.getElementById("ToolsName").value;
            const dateAdd = document.getElementById("dateAdd").value;
            const quantityAdd = document.getElementById("quantityAdd").value;
            const remarks = document.getElementById("remarks").value;

            console.log("Form data:", { toolsName, dateAdd, quantityAdd, remarks }); // Debug log

            // Add new row to table
            const tableBody = document.querySelector(".tools-table tbody");
            const newRow = document.createElement("tr");

            newRow.innerHTML = `
              <td>${toolsName}</td>
              <td><button class="delete-button" onclick="this.closest('tr').remove()">🗑️</button></td>
              <td>${quantityAdd}</td>
              <td>${dateAdd}</td>
              <td>${remarks || ''}</td>
            `;

            tableBody.appendChild(newRow);

            // Reset form
            ToolsForm.reset();

            console.log("New row added:", newRow); // Debug log

            // Do not reload or hide updated modal automatically,
            // user will close it by clicking button
          } else {
            alert("Error adding tool: " + data);
            updatedModal.style.display = "none";
          }
        })
        .catch(error => {
          alert("Error: " + error.message);
          updatedModal.style.display = "none";
        });
    });

    // Close updated modal when user clicks Done inside it
    updatedDoneBtn.addEventListener("click", () => {
      updatedModal.style.display = "none";
      // Optionally reload here if needed:
      location.reload();
    });

    // Print button logic
    const printButton = document.querySelector(".print-button");
    printButton.addEventListener("click", () => {
      const table = document.querySelector(".tools-table");
      html2canvas(table).then((canvas) => {
        const imgData = canvas.toDataURL("image/png");
        const pdf = new window.jspdf.jsPDF("p", "mm", "a4");
        const pageWidth = pdf.internal.pageSize.getWidth();
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pageWidth;
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

        pdf.addImage(imgData, "PNG", 0, 10, pdfWidth, pdfHeight);
        pdf.save("tools.pdf");
      });
    });

    // Close modals if user clicks outside modal content
    window.addEventListener("click", (event) => {
      if (event.target === addModal) {
        addModal.style.display = "none";
      }
      if (event.target === deleteModal) {
        deleteModal.style.display = "none";
      }
      if (event.target === updatedModal) {
        updatedModal.style.display = "none";
      }
      if (event.target === document.getElementById("notificationModal")) {
        document.getElementById("notificationModal").style.display = "none";
      }
    });

// Notification functionality
let notifications = [];
let unreadCount = 0;

// Load notifications from low stock
async function loadNotifications() {
  try {
    const response = await fetch('get_low_stock.php');
    const lowStockData = await response.json();

    // Create restock notifications from low stock data
    const restockNotifications = lowStockData.map((item, index) => ({
      id: index + 1,
      type: 'restock',
      title: 'Low Stock Alert',
      message: `${item.MaterialsName} are running low. Current quantity: ${item.Quantity}`,
      date: new Date(),
      read: false
    }));

    // For now, no other notifications; can add sample if needed
    notifications = restockNotifications;

    updateNotificationBadge();
  } catch (error) {
    console.error('Error loading notifications:', error);
    notifications = [];
    updateNotificationBadge();
  }
}

// Format date for display
function formatDate(date) {
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

// Update notification badge
function updateNotificationBadge() {
  const badge = document.getElementById('notificationBadge');
  unreadCount = notifications.filter(n => !n.read).length;
  
  if (unreadCount > 0) {
    badge.style.display = 'block';
    badge.textContent = '';  // Empty to show just the red circle without number
  } else {
    badge.style.display = 'none';
  }
}

// Render notifications in a specific tab
function renderNotifications(containerId, filterType = 'all') {
  const container = document.getElementById(containerId);
  let filteredNotifications = notifications;
  
  if (filterType === 'restock') {
    filteredNotifications = notifications.filter(n => n.type === 'restock');
  } else if (filterType === 'other') {
    filteredNotifications = notifications.filter(n => n.type === 'other');
  }
  
  if (filteredNotifications.length === 0) {
    container.innerHTML = '<div class="empty-notification">No notifications found</div>';
    return;
  }
  
  // Sort by date (newest first)
  filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  container.innerHTML = filteredNotifications.map(notification => `
    <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
      <div class="notification-title">
        <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
        ${notification.title}
      </div>
      <div class="notification-message">${notification.message}</div>
      <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
    </div>
  `).join('');
  
  // Add click event to mark as read
  container.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {
      const notificationId = parseInt(this.getAttribute('data-id'));
      markAsRead(notificationId);
      this.classList.remove('unread');
    });
  });
}

// Mark notification as read
function markAsRead(notificationId) {
  const notification = notifications.find(n => n.id === notificationId);
  if (notification && !notification.read) {
    notification.read = true;
    updateNotificationBadge();
  }
}

// Mark all notifications as read
function markAllAsRead() {
  notifications.forEach(notification => {
    notification.read = true;
  });
  updateNotificationBadge();
  
  // Update UI
  document.querySelectorAll('.notification-item').forEach(item => {
    item.classList.remove('unread');
  });
}

// Tab switching functionality
function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabPanes = document.querySelectorAll('.tab-pane');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');
      
      // Update active tab button
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // Show corresponding tab pane
      tabPanes.forEach(pane => pane.classList.remove('active'));
      document.getElementById(`${tabId}-tab`).classList.add('active');
      
      // Render notifications for this tab
      if (tabId === 'all') {
        renderNotifications('allNotificationsList');
      } else if (tabId === 'restock') {
        renderNotifications('restockNotificationsList', 'restock');
      } else if (tabId === 'other') {
        renderNotifications('otherNotificationsList', 'other');
      }
    });
  });
}

// Show notification modal
function showNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'flex';
  
  // Render all notifications initially
  renderNotifications('allNotificationsList');
  renderNotifications('restockNotificationsList', 'restock');
  renderNotifications('otherNotificationsList', 'other');
}

// Close notification modal
function closeNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'none';
}

// Initialize notification system
document.addEventListener('DOMContentLoaded', async function() {
  // Load notifications
  await loadNotifications();
  updateNotificationBadge();
  setupTabs();
  
  // Notification bell click event
  document.getElementById('notificationBell').addEventListener('click', showNotificationModal);
  
  // Modal close events
  document.getElementById('notificationCloseBtn').addEventListener('click', closeNotificationModal);
  document.getElementById('notificationDoneBtn').addEventListener('click', closeNotificationModal);
  
  // Mark all as read button
  document.getElementById('markAllReadBtn').addEventListener('click', markAllAsRead);
  
  // Close modal when clicking outside
  document.getElementById('notificationModal').addEventListener('click', function(event) {
    if (event.target === this) {
      closeNotificationModal();
    }
  });
});
  </script>
</body>
</html>
