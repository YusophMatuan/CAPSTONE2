<?php
session_start();
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$Email = strtolower(trim($_POST['email']));
$password = trim($_POST['password']);

$sql = "SELECT * FROM registration WHERE LOWER(Email) = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $Email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user && $user['password'] === $password) {
    // Store user info in session
    $_SESSION['Name'] = $user['Name'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['Email'] = $user['Email'];

    // Redirect based on role
    if ($user['role'] == "Admin") {
        header("Location: AdminDb.php");
    } elseif ($user['role'] == "Project Mngr.") {
        header("Location: ProjectDb.html");
    } elseif ($user['role'] == "Material Mngr.") {
        header("Location: InventoryDb.html");
    } else {
        echo "Unknown role.";
    }
    exit();
} else {
    echo "Invalid email or password.";
}

$conn->close();
?>