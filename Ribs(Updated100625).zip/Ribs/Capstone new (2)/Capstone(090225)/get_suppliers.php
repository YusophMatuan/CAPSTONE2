<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$result = $conn->query("SELECT Name FROM suppliers ORDER BY Name ASC");
$suppliers = [];
while ($row = $result->fetch_assoc()) {
    $suppliers[] = $row;
}
header('Content-Type: application/json');
echo json_encode($suppliers);
$conn->close();
?>