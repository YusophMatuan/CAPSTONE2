<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName = isset($_POST['siteName']) ? trim($_POST['siteName']) : '';
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    $status = "Pending"; // Always set to Pending on add

    $conn = new mysqli($servername, $username, $passwordDB, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use correct column names: SiteName, Notes
    $stmt = $conn->prepare("INSERT INTO sites (SiteName, location, date, status, Notes) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $siteName, $location, $date, $status, $notes);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>