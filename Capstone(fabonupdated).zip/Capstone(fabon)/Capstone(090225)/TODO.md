# TODO: Fix Navbar and Restock Modal in Admin Files

## Tasks
- [x] Update AdminPurch.html: Add navbar-right wrapper in navbar, update restock modal to include modal-header and style="display:none;"
- [x] Update AdminPurch.css: Change navbar display from flex to grid, add grid-template-columns: auto 1fr auto auto auto;
- [ ] Update AdminSup.html: Same as AdminPurch.html
- [ ] Update AdminSup.css: Same as AdminPurch.css
- [ ] Update AdminSites.php: Same as AdminPurch.html
- [ ] Update AdminSites.css: Same as AdminPurch.css
- [ ] Update AdminOG.html: Same as AdminPurch.html
- [ ] Update AdminOG.css: Same as AdminPurch.css
- [ ] Update AdminApvl.html: Same as AdminPurch.html
- [ ] Update AdminApvl.css: Same as AdminPurch.css
- [ ] Update AdminHsty.html: Same as AdminPurch.html
- [ ] Update AdminHsty.css: Same as AdminPurch.css

## Followup
- Test the updated pages to ensure navbar alignment and modal functionality match AdminCT.
