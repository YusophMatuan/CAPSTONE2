<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminTools.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
</head>
<body> 
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src= "media/logo.png" class="navbar-logo"></a>
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.html">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.html">Purchasing</a>
          <a href="AdminSup.html">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminPurch.html">Approvals</a>
      <a href="AdminHsty.html">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <!-- Simple user SVG icon -->
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="8" r="4"/>
          <path d="M4 20c0-4 4-7 8-7s8 3 8 7"/>
        </svg>
      </div>
      <span>Username</span>
      <div class="dropdown-content profile-dropdown-content">
    <a href="AdminProf.php">Profile Settings</a>
    <a href="index.html">Log Out</a>
    </div>
  </nav>
<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

// Connect to database
$conn = new mysqli($servername, $username, $passwordDB, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch tools
$sql = "SELECT id, ToolsName, Quantity, DateAdded, FastMoving, SlowMoving FROM tools";
$result = $conn->query($sql);
?>
<!-- Now your table -->
<div class="tools-section">
    <div class="tools-header">
        <h2>TOOLS</h2>
        <input type="text" placeholder="Search" class="search-input">
        <button class="print-button">Print</button>
        <button class="add-button">Add</button>
    </div>
    <table class="tools-table">
        <thead>
            <tr>
                <th>Tool Name</th>
                <th>Action</th>
                <th>Quantity</th>
                <th>Date Added</th>
                <th>Fast Moving</th>
                <th>Slow Moving</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['ToolsName']); ?></td>
                        <td><button class="delete-button" data-id="<?php echo $row['id']; ?>">🗑️</button></td>
                        <td><?php echo htmlspecialchars($row['Quantity']); ?></td>
                        <td><?php echo htmlspecialchars($row['DateAdded']); ?></td>
                        <td><?php echo $row['FastMoving'] ? 'Fast' : ''; ?></td>
                        <td><?php echo $row['SlowMoving'] ? 'Slow' : ''; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">No tools found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<!-- Delete Modal -->
<div id="deleteModal" class="modal">
  <div class="modal-content">
    <button id="closeBtn" class="close-button">X</button>
    <p>Are you sure you want to delete?</p>
    
    <label for="Tools">Tools:</label>
    <input type="text" id="Tools" name="Tools" placeholder="">

    <label for="quantity">Quantity:</label>
    <input type="number" id="quantity" name="quantity" placeholder="Enter quantity">

    <label for="date">Date:</label>
    <input type="date" id="date" name="date" value="2025-10-24">

    <button id="doneBtn">Done</button>
  </div>
</div>

<!-- Add Modal -->
<div id="addmodal" class="modal">
  <div class="modal-content">
    <div class="modal-header">
      <span class="title">Add Tools</span>
      <button id="closeBtn2" class="close-button">X</button>
    </div>
<form id="ToolsForm">
  <label for="ToolsName">Tools name:</label>
  <input type="text" id="ToolsName" name="ToolsName" />

  <label for="dateAdd">Date:</label>
  <input type="date" id="dateAdd" name="dateAdd" />

  <label for="quantityAdd">Quantity:</label>
  <input type="number" id="quantityAdd" name="quantityAdd" />

  <div class="radio-group">
  <label><input type="radio" name="movingType" value="fast" /> Fast Moving</label>
  <label><input type="radio" name="movingType" value="slow" /> Slow Moving</label>
</div>

  <button type="submit" id="doneButton">Done</button>
</form>
  </div>
</div>



<!-- Updated Confirmation Modal -->
<div id="updatedModal" class="modal" style="display:none;">
  <div class="modal-content" style="text-align:center; padding: 20px;">
    <p>Tools Updated!</p>
    <button id="updatedDoneBtn">Done</button>
  </div>
</div>

<!-- Restock Warning Modal -->
<div id="restockModal" class="modal">
  <div class="modal-content">
    <button id="restockCloseBtn" class="close-button">X</button>
    <h2>Restock Warning</h2>
    <p>The following materials are low on stock and need to be restocked:</p>
    <ul id="lowStockList"></ul>
    <button id="restockDoneBtn">Done</button>
  </div>
</div>

<script>
// Elements for delete modal
  const deleteModal = document.getElementById('deleteModal');
  const deleteCloseBtn = document.getElementById('closeBtn');
  const deleteDoneBtn = document.getElementById('doneBtn');

  // Show delete modal on delete button click (assuming .delete-button elements)
  document.querySelectorAll('.delete-button').forEach(button => {
  button.addEventListener('click', () => {
    deleteModal.style.display = 'block';

    const tr = button.closest('tr');
    const ToolsName = tr ? tr.querySelector('td:first-child').textContent.trim() : '';
    const ToolsInput = deleteModal.querySelector('#Tools');
    ToolsInput.value = ToolsName || '';

    // Store tool ID for deletion
    deleteModal.dataset.toolId = button.getAttribute('data-id');
    const currentQty = tr ? tr.querySelector('td:nth-child(3)').textContent.trim() : '';
    deleteModal.querySelector('#quantity').placeholder = `Max: ${currentQty}`;
  });
});

  // Close delete modal
  deleteCloseBtn.addEventListener('click', () => {
    deleteModal.style.display = 'none';
  });

  // Show updated modal after delete done
deleteDoneBtn.addEventListener('click', () => {
  const tr = document.querySelector('.delete-button[data-id="' + deleteModal.dataset.toolId + '"]').closest('tr');
  const id = deleteModal.dataset.toolId || (tr ? tr.querySelector('.delete-button').getAttribute('data-id') : '');
  const quantity = deleteModal.querySelector('#quantity').value;

  fetch('delete_tool.php', {
    method: 'POST',
    body: new URLSearchParams({ id, quantity })
  })
  .then(response => response.text())
  .then(data => {
    if (data.trim() === "success" || data.trim() === "deleted") {
      location.reload();
    } else {
      alert(data);
    }
  })
  .catch(error => {
    alert("Error: " + error.message);
  });

  deleteModal.style.display = 'none';
  updatedModal.style.display = 'block';
});



  // Elements for add modal
  const addModal = document.getElementById('addmodal');
  const addCloseBtn2 = document.getElementById('closeBtn2');
  const addButton = document.querySelector('.add-button');
  const ToolsForm = document.getElementById('ToolsForm');

  // Confirmation modal
  const updatedModal = document.getElementById('updatedModal');
  const updatedDoneBtn = document.getElementById('updatedDoneBtn');

  // Show add modal on add button click
  addButton.addEventListener('click', () => {
    ToolsForm.reset(); // Reset form on open
    addModal.style.display = 'block';
  });

  const printButton = document.querySelector('.print-button');

printButton.addEventListener('click', () => {
  const table = document.querySelector('.tools-table');
  html2canvas(table).then(canvas => {
    const imgData = canvas.toDataURL('image/png');
    const pdf = new window.jspdf.jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pageWidth;
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;

    pdf.addImage(imgData, 'PNG', 0, 10, pdfWidth, pdfHeight);
    pdf.save('tools.pdf');
  });
});

  // Close add modal on close button
  addCloseBtn2.addEventListener('click', () => {
    addModal.style.display = 'none';
  });

  // Form submit handler
ToolsForm.addEventListener('submit', event => {
  event.preventDefault();

  const formData = new FormData(ToolsForm);

  fetch('add_tool.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    if (data.trim() === "success") {
      location.reload();
    } else {
      alert("Error adding tool: " + data);
    }
  })
  .catch(error => {
    alert("Error: " + error.message);
  });

  addModal.style.display = 'none';
  updatedModal.style.display = 'block';
});
   

  // Close updated modal on Done button click
  updatedDoneBtn.addEventListener('click', () => {
    updatedModal.style.display = 'none';
  });

  // Close modals if user clicks outside modal content (optional)
  window.addEventListener('click', (event) => {
    if (event.target === addModal) {
      addModal.style.display = 'none';
    }
    if (event.target === deleteModal) {
      deleteModal.style.display = 'none';
    }
    if (event.target === updatedModal) {
      updatedModal.style.display = 'none';
    }
  });

// Check for low stock on page load
window.addEventListener('DOMContentLoaded', () => {
  fetch('get_low_stock.php')
    .then(response => response.json())
    .then(data => {
      if (data.length > 0) {
        document.getElementById('notificationBadge').style.display = 'block';
      }
    })
    .catch(error => console.error('Error fetching low stock:', error));
});

// Handle notification bell click
document.getElementById('notificationBell').addEventListener('click', () => {
  fetch('get_low_stock.php')
    .then(response => response.json())
    .then(data => {
      const list = document.getElementById('lowStockList');
      list.innerHTML = '';
      if (data.length > 0) {
        data.forEach(item => {
          const li = document.createElement('li');
          li.textContent = `${item.MaterialsName} - Quantity: ${item.Quantity}`;
          list.appendChild(li);
        });
      } else {
        const li = document.createElement('li');
        li.textContent = 'No low stock items at the moment.';
        list.appendChild(li);
      }
      document.getElementById('restockModal').style.display = 'flex';
    })
    .catch(error => {
      console.error('Error fetching low stock:', error);
      alert('Error fetching low stock data. Please check the console for details.');
    });
});

// Close modal
document.getElementById('restockCloseBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

document.getElementById('restockDoneBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

// Close modal if clicking outside
window.addEventListener('click', (event) => {
  const modal = document.getElementById('restockModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
});


// Close modal
document.getElementById('restockCloseBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

document.getElementById('restockDoneBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

// Close modal if clicking outside
window.addEventListener('click', (event) => {
  const modal = document.getElementById('restockModal');
  if (event.target === modal) {
    modal.style.display = 'none';
  }
});
</script>

</body>
</html>
