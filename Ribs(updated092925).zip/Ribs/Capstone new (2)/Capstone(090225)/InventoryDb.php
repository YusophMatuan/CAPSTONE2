<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="InventoryDb.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src= "media/MainLogo.png" class="navbar-logo"></a>
      <div class="navbar-company">
        <span>Art glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="InventoryDb.php">Home</a>
      <a href="InventoryMat.php">Materials</a>
      <a href="InventoryTools.php">Tools</a>
      <a href="InventoryCT.php">Cutting List</a>
      <a href="InventoryPurch.php">Purchasing</a>
      <a href="InventorySup.php">Suppliers</a>
    </div>
<div class="navbar-profile dropdown">
  <div class="profile-icon">
    <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
  </div>
  <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
  <div class="dropdown-content profile-dropdown-content">
    <a href="InventoryProf.php">Profile Settings</a>
    <a href="index.html">Log Out</a>
  </div>
</div>
</nav>
  <div class="dashboard-container">
    <div class="dashboard-section">
      <div class="dashboard-card">
        <div class="dashboard-title">Materials Summary</div>
        <table>
          <thead>
            <tr>
              <th>Material</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
      <div class="dashboard-card">
        <div class="dashboard-title">Tools Summary</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="dashboard-section">
      <div class="dashboard-card">
        <div class="dashboard-title">Low on stocks - Fast Moving</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
      <div class="dashboard-card">
        <div class="dashboard-title">Low on stocks - Slow Moving</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
      <div class="dashboard-card">
        <div class="dashboard-title">Sites</div>
        <table>
          <thead>
            <tr>
              <th>Site</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="restockModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Restock Warning</h2>
        <button id="restockCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <p>The following materials are low on stock and need to be restocked:</p>
        <ul id="lowStockList"></ul>
        <button id="restockDoneBtn">Done</button>
      </div>
    </div>
  </div>

  <script>
    window.addEventListener('DOMContentLoaded', () => {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          if (data.length > 0) {
            document.getElementById('notificationBadge').style.display = 'block';
          }
        })
        .catch(error => console.error('Error fetching low stock:', error));
    });

    document.getElementById('notificationBell').addEventListener('click', () => {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          const list = document.getElementById('lowStockList');
          list.innerHTML = '';
          if (data.length > 0) {
            data.forEach(item => {
              const li = document.createElement('li');
              li.textContent = `${item.MaterialsName} - Quantity: ${item.Quantity}`;
              list.appendChild(li);
            });
          } else {
            const li = document.createElement('li');
            li.textContent = 'No low stock items at the moment.';
            list.appendChild(li);
          }
          document.getElementById('restockModal').style.display = 'flex';
        })
        .catch(error => {
          console.error('Error fetching low stock:', error);
          alert('Error fetching low stock data. Please check the console for details.');
        });
    });

    document.getElementById('restockCloseBtn').addEventListener('click', () => {
      document.getElementById('restockModal').style.display = 'none';
    });

    document.getElementById('restockDoneBtn').addEventListener('click', () => {
      document.getElementById('restockModal').style.display = 'none';
    });

    document.getElementById('restockModal').addEventListener('click', (event) => {
      if (event.target === document.getElementById('restockModal')) {
        document.getElementById('restockModal').style.display = 'none';
      }
    });
  </script>
</body>
</html>