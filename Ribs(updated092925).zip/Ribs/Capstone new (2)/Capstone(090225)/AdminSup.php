<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminSup.css?v=1.1">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
   <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
        <span>Art glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>
<div class="container">
        <header>
            <h1>List of Suppliers</h1>
    <div class="header-right">
        <input type="text" class="search" placeholder="Search">
        <div class="buttons">
            <button class="add-suppliers">+ Add New Suppliers</button>
            <button class="export-pdf">Export PDF</button>
        </div>
        </header>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Invoice</th>
                </tr>
            </thead>
            <tbody>
<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$result = $conn->query("SELECT id, Name, Address, Email, Contact FROM suppliers ORDER BY id DESC LIMIT 20");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>" . htmlspecialchars($row['id']) . "</td>
            <td>" . htmlspecialchars($row['Name']) . "</td>
            <td>" . htmlspecialchars($row['Address']) . "</td>
            <td>" . htmlspecialchars($row['Email']) . "</td>
            <td>" . htmlspecialchars($row['Contact']) . "</td>
            <td><a href='#' class='invoice'><img src='media/pdflogo.png' style='width: 30px; height: auto;'></a></td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No suppliers found.</td></tr>";
}
$conn->close();
?>
</tbody>
        </table>
    </div>
<!-- Supplier Form Modal -->
  <div id="modalOverlay" class="modal" style="display:none;">
    <div class="supplier-modal-content">
      <div class="supplier-modal-header">
        <h3>Add New Supplier</h3>
        <button class="supplier-close-btn" id="supplierCloseBtn">×</button>
      </div>
      
      <form id="suppliersForm">
        <div class="supplier-form-body">
          <label for="supplier">Name</label>
          <input type="text" id="supplier" name="supplier" placeholder="Enter Supplier Name" required>

          <label for="address">Address</label>
          <input type="text" id="address" name="address" placeholder="Enter the Address" required>

          <label for="contact">Contact #</label>
          <input type="number" id="contact" name="contact" placeholder="Enter Contact #" min="1" required>

          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" placeholder="Enter Email Address" required>

          <label for="tinid">TIN ID</label>
          <input type="text" id="tinid" name="tinid" placeholder="Enter TIN ID" required>
        </div>

        <div class="supplier-button-group">
          <button type="submit" class="supplier-btn-submit">Submit</button>
          <button type="button" class="supplier-btn-cancel" id="cancelBtn">Cancel</button>
        </div>
      </form>
    </div>
  </div>

   <!-- Updated Notification Modal -->
  <div id="notificationModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>
<script>
// Get elements
    const addSuppliersBtn = document.querySelector('.add-suppliers');
    const modalOverlay = document.getElementById('modalOverlay');
    const suppliersForm = document.getElementById('suppliersForm');
    const supplierForm = document.getElementById('supplierForm'); // Alternative form reference
    const cancelBtn = document.getElementById('cancelBtn');
    const supplierCloseBtn = document.getElementById('supplierCloseBtn');
    const notificationModal = document.getElementById('notificationModal');
    const notificationBell = document.getElementById('notificationBell');

    // Notification variables
    let notifications = [];
    let unreadCount = 0;

    // Show supplier modal when "Add Suppliers" button is clicked
    addSuppliersBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      modalOverlay.style.display = 'flex';
    });

    // Hide supplier modal functions
    function closeSupplierModal() {
      if (suppliersForm) suppliersForm.reset();
      if (supplierForm) supplierForm.reset();
      modalOverlay.style.display = 'none';
    }

    // Close supplier modal events
    if (cancelBtn) cancelBtn.addEventListener('click', closeSupplierModal);
    if (supplierCloseBtn) supplierCloseBtn.addEventListener('click', closeSupplierModal);

    // Close supplier modal when clicking outside
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        closeSupplierModal();
      }
    });

    // Handle form submission with both client-side table update and server-side processing
    function handleFormSubmission(form) {
      form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Get form values
        const name = this.supplier?.value?.trim() || this.querySelector('[name="supplier"]')?.value?.trim();
        const address = this.address?.value?.trim() || this.querySelector('[name="address"]')?.value?.trim();
        const email = this.email?.value?.trim() || this.querySelector('[name="email"]')?.value?.trim();
        const contact = this.contact?.value?.trim() || this.querySelector('[name="contact"]')?.value?.trim();
        const tinid = this.tinid?.value?.trim() || this.querySelector('[name="tinid"]')?.value?.trim();

        // Validate required fields
        if (!name || !address || !email || !contact || !tinid) {
          alert('Please fill in all required fields.');
          return;
        }

        // Submit to server first
        const formData = new FormData(this);

        fetch('add_supplier.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.text())
        .then(data => {
          if (data.trim() === "success") {
            // Server submission successful, now update client-side table
            updateClientTable(name, address, email, contact, tinid);
            alert('Supplier added successfully!');
            closeSupplierModal();
          } else {
            alert('Error: ' + data);
          }
        })
        .catch(error => {
          // If server fails, still update client-side table as fallback
          console.error('Server error, updating client-side only:', error);
          updateClientTable(name, address, email, contact, tinid);
          alert('Supplier added successfully! (Note: Server sync may be pending)');
          closeSupplierModal();
        });
      });
    }

    // Update client-side table
    function updateClientTable(name, address, email, contact, tinid) {
      const tableBody = document.getElementById('suppliersTableBody');
      if (!tableBody) return;

      const existingRows = tableBody.querySelectorAll('tr');
      let nextId = 1;

      // Find the highest existing ID
      existingRows.forEach(row => {
        const firstCell = row.cells[0];
        if (firstCell && firstCell.textContent.trim() !== '') {
          const id = parseInt(firstCell.textContent);
          if (!isNaN(id) && id >= nextId) {
            nextId = id + 1;
          }
        }
      });

      // Find first empty row or create new one
      let targetRow = null;
      existingRows.forEach(row => {
        if (!targetRow && row.cells.length > 1 && row.cells[1].textContent.trim() === '') {
          targetRow = row;
        }
      });

      if (!targetRow) {
        targetRow = document.createElement('tr');
        tableBody.appendChild(targetRow);
        for (let i = 0; i < 6; i++) {
          targetRow.appendChild(document.createElement('td'));
        }
      }

      // Fill the row
      targetRow.cells[0].textContent = nextId;
      targetRow.cells[1].textContent = name;
      targetRow.cells[2].textContent = address;
      targetRow.cells[3].textContent = email;
      targetRow.cells[4].textContent = contact;
      targetRow.cells[5].textContent = tinid;
    }

    // Set up form submission handlers
    if (suppliersForm) handleFormSubmission(suppliersForm);
    if (supplierForm) handleFormSubmission(supplierForm);

    // PDF Export functionality
    const exportBtn = document.querySelector('.export-pdf');
    if (exportBtn) {
      exportBtn.addEventListener('click', function() {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        doc.text("List of Suppliers", 14, 14);

        // Get table headers and rows
        const table = document.querySelector('table');
        if (table) {
          const head = [];
          table.querySelectorAll('thead th').forEach(th => head.push(th.innerText));
          const body = [];
          table.querySelectorAll('tbody tr').forEach(tr => {
            const row = [];
            tr.querySelectorAll('td').forEach(td => row.push(td.innerText));
            // Only add non-empty rows
            if (row.some(cell => cell.trim() !== '')) {
              body.push(row);
            }
          });

          doc.autoTable({
            head: [head],
            body: body,
            startY: 20,
            styles: { fontSize: 10 }
          });

          doc.save('suppliers.pdf');
        } else {
          alert('No table found to export');
        }
      });
    }

    // Initialize notifications on page load
    window.addEventListener('DOMContentLoaded', () => {
      loadNotifications();
    });

    // Load notifications from server
    function loadNotifications() {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          notifications = [];
          unreadCount = 0;

          // Create restock notifications
          data.forEach(item => {
            const notification = {
              id: Date.now() + Math.random(),
              type: 'restock',
              title: 'Low Stock Alert',
              message: `${item.MaterialsName} is running low on stock.`,
              date: new Date().toLocaleDateString(),
              read: false
            };
            notifications.push(notification);
            if (!notification.read) unreadCount++;
          });

          // Add some sample other notifications
          const sampleNotifications = [
            {
              id: Date.now() + Math.random(),
              type: 'other',
              title: 'System Update',
              message: 'The system has been updated to the latest version.',
              date: new Date().toLocaleDateString(),
              read: false
            },
            {
              id: Date.now() + Math.random(),
              type: 'other',
              title: 'New Feature',
              message: 'Check out the new notification system!',
              date: new Date().toLocaleDateString(),
              read: true
            }
          ];

          sampleNotifications.forEach(notification => {
            notifications.push(notification);
            if (!notification.read) unreadCount++;
          });

          updateNotificationBadge();
        })
        .catch(error => {
          console.error('Error loading notifications:', error);
          // Load fallback notifications if server fails
          notifications = [];
          unreadCount = 0;
          updateNotificationBadge();
        });
    }

    // Update notification badge
    function updateNotificationBadge() {
      const badge = document.getElementById('notificationBadge');
      if (badge) {
        if (unreadCount > 0) {
          badge.style.display = 'block';
        } else {
          badge.style.display = 'none';
        }
      }
    }

    // Handle notification bell click
    if (notificationBell) {
      notificationBell.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        showNotificationModal();
      });
    }

    // Show notification modal
    function showNotificationModal() {
      if (notificationModal) {
        renderNotifications();
        notificationModal.style.display = 'flex';
      }
    }

    // Render notifications in modal
    function renderNotifications() {
      const allList = document.getElementById('allNotificationsList');
      const restockList = document.getElementById('restockNotificationsList');
      const otherList = document.getElementById('otherNotificationsList');

      if (!allList || !restockList || !otherList) return;

      allList.innerHTML = '';
      restockList.innerHTML = '';
      otherList.innerHTML = '';

      if (notifications.length === 0) {
        const emptyDiv = document.createElement('div');
        emptyDiv.className = 'empty-notification';
        emptyDiv.textContent = 'No notifications at the moment.';
        allList.appendChild(emptyDiv);
        return;
      }

      notifications.forEach(notification => {
        const itemDiv = document.createElement('div');
        itemDiv.className = `notification-item ${notification.type} ${notification.read ? '' : 'unread'}`;
        itemDiv.onclick = () => markAsRead(notification.id);

        const titleDiv = document.createElement('div');
        titleDiv.className = 'notification-title';
        titleDiv.innerHTML = `<span class="notification-type">${getTypeLabel(notification.type)}</span>${notification.title}`;

        const messageDiv = document.createElement('div');
        messageDiv.className = 'notification-message';
        messageDiv.textContent = notification.message;

        const dateDiv = document.createElement('div');
        dateDiv.className = 'notification-date';
        dateDiv.textContent = `Declared on: ${notification.date}`;

        itemDiv.appendChild(titleDiv);
        itemDiv.appendChild(messageDiv);
        itemDiv.appendChild(dateDiv);

        // Add to appropriate lists
        allList.appendChild(itemDiv.cloneNode(true));
        if (notification.type === 'restock') {
          restockList.appendChild(itemDiv.cloneNode(true));
        } else if (notification.type === 'other') {
          otherList.appendChild(itemDiv.cloneNode(true));
        }
      });

      // Add event listeners to cloned items
      document.querySelectorAll('#allNotificationsList .notification-item').forEach((item, index) => {
        item.onclick = () => markAsRead(notifications[index].id);
      });
      document.querySelectorAll('#restockNotificationsList .notification-item').forEach((item, index) => {
        const restockNotifications = notifications.filter(n => n.type === 'restock');
        if (restockNotifications[index]) {
          item.onclick = () => markAsRead(restockNotifications[index].id);
        }
      });
      document.querySelectorAll('#otherNotificationsList .notification-item').forEach((item, index) => {
        const otherNotifications = notifications.filter(n => n.type === 'other');
        if (otherNotifications[index]) {
          item.onclick = () => markAsRead(otherNotifications[index].id);
        }
      });
    }

    // Get type label
    function getTypeLabel(type) {
      switch(type) {
        case 'restock': return 'Restock';
        case 'other': return 'Info';
        default: return 'Info';
      }
    }

    // Mark notification as read
    function markAsRead(id) {
      const notification = notifications.find(n => n.id === id);
      if (notification && !notification.read) {
        notification.read = true;
        unreadCount--;
        updateNotificationBadge();
        renderNotifications();
      }
    }

    // Tab switching
    document.querySelectorAll('.tab-button').forEach(button => {
      button.addEventListener('click', () => {
        const tab = button.getAttribute('data-tab');

        // Update active tab button
        document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');

        // Update active tab pane
        document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));
        const targetTab = document.getElementById(`${tab}-tab`);
        if (targetTab) {
          targetTab.classList.add('active');
        }
      });
    });

    // Mark all as read
    const markAllReadBtn = document.getElementById('markAllReadBtn');
    if (markAllReadBtn) {
      markAllReadBtn.addEventListener('click', () => {
        notifications.forEach(notification => {
          if (!notification.read) {
            notification.read = true;
            unreadCount--;
          }
        });
        updateNotificationBadge();
        renderNotifications();
      });
    }

    // Close notification modal
    const notificationCloseBtn = document.getElementById('notificationCloseBtn');
    const notificationDoneBtn = document.getElementById('notificationDoneBtn');

    if (notificationCloseBtn) {
      notificationCloseBtn.addEventListener('click', () => {
        notificationModal.style.display = 'none';
      });
    }

    if (notificationDoneBtn) {
      notificationDoneBtn.addEventListener('click', () => {
        notificationModal.style.display = 'none';
      });
    }

    // Close notification modal when clicking outside
    if (notificationModal) {
      notificationModal.addEventListener('click', (e) => {
        if (e.target === notificationModal) {
          notificationModal.style.display = 'none';
        }
      });
    }

  </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.7.0/jspdf.plugin.autotable.min.js"></script>
</body>
</html>