<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$site_id = $_POST['site_id'];
$materials = $_POST['materials']; // array: [material_id => new_qty]

foreach ($materials as $mat_id => $new_qty) {
    $old_qty = 0;
    $res = $conn->query("SELECT quantity FROM site_materials WHERE site_id=$site_id AND material_id=$mat_id");
    if ($row = $res->fetch_assoc()) $old_qty = $row['quantity'];
    $diff = $new_qty - $old_qty;
    if ($diff > 0) {
        // Deduct from inventory
        $conn->query("UPDATE materials SET Quantity = Quantity - $diff WHERE id = $mat_id");
    } elseif ($diff < 0) {
        // Add back to inventory
        $conn->query("UPDATE materials SET Quantity = Quantity + " . abs($diff) . " WHERE id = $mat_id");
    }
    // Update assignment
    if ($old_qty == 0) {
        $conn->query("INSERT INTO site_materials (site_id, material_id, quantity) VALUES ($site_id, $mat_id, $new_qty)");
    } else {
        $conn->query("UPDATE site_materials SET quantity = $new_qty WHERE site_id = $site_id AND material_id = $mat_id");
    }
}
echo "success";
?>