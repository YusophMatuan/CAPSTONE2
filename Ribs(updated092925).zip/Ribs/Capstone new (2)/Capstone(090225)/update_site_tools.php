<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$site_id = $_POST['site_id'];
$tools = $_POST['tools']; // array: [tool_id => new_qty]

foreach ($tools as $tool_id => $new_qty) {
    $old_qty = 0;
    $res = $conn->query("SELECT quantity FROM site_tools WHERE site_id=$site_id AND tool_id=$tool_id");
    if ($row = $res->fetch_assoc()) $old_qty = $row['quantity'];
    $diff = $new_qty - $old_qty;
    if ($diff > 0) {
        // Deduct from inventory
        $conn->query("UPDATE tools SET Quantity = Quantity - $diff WHERE id = $tool_id");
    } elseif ($diff < 0) {
        // Add back to inventory
        $conn->query("UPDATE tools SET Quantity = Quantity + " . abs($diff) . " WHERE id = $tool_id");
    }
    // Update assignment
    if ($old_qty == 0) {
        $conn->query("INSERT INTO site_tools (site_id, tool_id, quantity) VALUES ($site_id, $tool_id, $new_qty)");
    } else {
        $conn->query("UPDATE site_tools SET quantity = $new_qty WHERE site_id = $site_id AND tool_id = $tool_id");
    }
}
echo "success";
?>