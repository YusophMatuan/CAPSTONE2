<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$site_id = intval($_GET['site_id'] ?? 0);

// Fetch assigned tools for this site, join to get tool name
$sql = "SELECT t.id, t.ToolsName, st.quantity 
        FROM site_tools st
        JOIN tools t ON st.tool_id = t.id
        WHERE st.site_id = $site_id";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()):
?>
<tr>
  <td>
    <input type="checkbox" class="tool-checkbox" data-id="<?= $row['id'] ?>" checked>
  </td>
  <td><?= htmlspecialchars($row['ToolsName']) ?></td>
  <td>
    <input type="number" class="tool-qty" data-id="<?= $row['id'] ?>"
      min="1"
      value="<?= $row['quantity'] ?>">
  </td>
</tr>
<?php endwhile; ?>