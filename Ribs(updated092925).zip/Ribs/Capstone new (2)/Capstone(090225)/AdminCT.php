<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminCT.css?v=2.1"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap" />
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
        <span>Art glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>

<div class="cutting-section">
    <div class="section-header">
      <h1>Cutting List</h1>
    </div>

    <div class="cutting-list">
      <div class="cutting-item">
        <div class="item-image">
          <div class="image-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21,15 16,10 5,21"/>
            </svg>
          </div>
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title"></h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="cutting-item">
        <div class="item-image">
          <div class="image-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21,15 16,10 5,21"/>
            </svg>
          </div>
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title"></h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="cutting-item">
        <div class="item-image">
          <div class="image-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21,15 16,10 5,21"/>
            </svg>
          </div>
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title"></h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

 <!-- Updated Notification Modal -->
  <div id="notificationModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Custom dropdown functionality
    document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
      const btn = dropdown.querySelector('.dropdown-btn');
      const menu = dropdown.querySelector('.dropdown-menu');
      const selectedText = dropdown.querySelector('.selected-text');
      
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        
        // Close other dropdowns
        document.querySelectorAll('.custom-dropdown').forEach(other => {
          if (other !== dropdown) {
            other.classList.remove('active');
          }
        });
        
        dropdown.classList.toggle('active');
      });
      
      dropdown.querySelectorAll('.dropdown-item').forEach(item => {
        item.addEventListener('click', (e) => {
          selectedText.textContent = item.textContent;
          dropdown.classList.remove('active');
          
          // Add selected class for styling
          dropdown.querySelectorAll('.dropdown-item').forEach(i => i.classList.remove('selected'));
          item.classList.add('selected');
        });
      });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
      document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
        dropdown.classList.remove('active');
      });
    });

// Notification functionality
let notifications = [];
let unreadCount = 0;

// Sample notification data (in a real app, this would come from a server)
function loadSampleNotifications() {
  return [
    {
      id: 1,
      type: 'restock',
      title: 'Low Stock Alert',
      message: 'Glass Panels (5mm) are running low. Current quantity: 15 pieces',
      date: new Date('2023-10-15'),
      read: false
    },
    {
      id: 2,
      type: 'restock',
      title: 'Restock Needed',
      message: 'Aluminum Frames (Silver) need to be restocked. Only 8 units left.',
      date: new Date('2023-10-14'),
      read: false
    },
    {
      id: 3,
      type: 'other',
      title: 'New Site Assignment',
      message: 'You have been assigned to the Downtown Office project.',
      date: new Date('2023-10-13'),
      read: true
    },
    {
      id: 4,
      type: 'other',
      title: 'Approval Required',
      message: 'Purchase request #PR-2023-045 needs your approval.',
      date: new Date('2023-10-12'),
      read: false
    },
    {
      id: 5,
      type: 'restock',
      title: 'Critical Stock Level',
      message: 'Silicone Sealant is almost out of stock. Only 3 tubes remaining.',
      date: new Date('2023-10-10'),
      read: false
    }
  ];
}

// Format date for display
function formatDate(date) {
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

// Update notification badge
function updateNotificationBadge() {
  const badge = document.getElementById('notificationBadge');
  unreadCount = notifications.filter(n => !n.read).length;
  
  if (unreadCount > 0) {
    badge.style.display = 'block';
    badge.textContent = '';  // Empty to show just the red circle without number
  } else {
    badge.style.display = 'none';
  }
}

// Render notifications in a specific tab
function renderNotifications(containerId, filterType = 'all') {
  const container = document.getElementById(containerId);
  let filteredNotifications = notifications;
  
  if (filterType === 'restock') {
    filteredNotifications = notifications.filter(n => n.type === 'restock');
  } else if (filterType === 'other') {
    filteredNotifications = notifications.filter(n => n.type === 'other');
  }
  
  if (filteredNotifications.length === 0) {
    container.innerHTML = '<div class="empty-notification">No notifications found</div>';
    return;
  }
  
  // Sort by date (newest first)
  filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  container.innerHTML = filteredNotifications.map(notification => `
    <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
      <div class="notification-title">
        <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
        ${notification.title}
      </div>
      <div class="notification-message">${notification.message}</div>
      <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
    </div>
  `).join('');
  
  // Add click event to mark as read
  container.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {
      const notificationId = parseInt(this.getAttribute('data-id'));
      markAsRead(notificationId);
      this.classList.remove('unread');
    });
  });
}

// Mark notification as read
function markAsRead(notificationId) {
  const notification = notifications.find(n => n.id === notificationId);
  if (notification && !notification.read) {
    notification.read = true;
    updateNotificationBadge();
  }
}

// Mark all notifications as read
function markAllAsRead() {
  notifications.forEach(notification => {
    notification.read = true;
  });
  updateNotificationBadge();
  
  // Update UI
  document.querySelectorAll('.notification-item').forEach(item => {
    item.classList.remove('unread');
  });
}

// Tab switching functionality
function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabPanes = document.querySelectorAll('.tab-pane');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');
      
      // Update active tab button
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // Show corresponding tab pane
      tabPanes.forEach(pane => pane.classList.remove('active'));
      document.getElementById(`${tabId}-tab`).classList.add('active');
      
      // Render notifications for this tab
      if (tabId === 'all') {
        renderNotifications('allNotificationsList');
      } else if (tabId === 'restock') {
        renderNotifications('restockNotificationsList', 'restock');
      } else if (tabId === 'other') {
        renderNotifications('otherNotificationsList', 'other');
      }
    });
  });
}

// Show notification modal
function showNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'flex';
  
  // Render all notifications initially
  renderNotifications('allNotificationsList');
  renderNotifications('restockNotificationsList', 'restock');
  renderNotifications('otherNotificationsList', 'other');
}

// Close notification modal
function closeNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'none';
}

// Initialize notification system
document.addEventListener('DOMContentLoaded', function() {
  // Load notifications
  notifications = loadSampleNotifications();
  updateNotificationBadge();
  setupTabs();
  
  // Notification bell click event
  document.getElementById('notificationBell').addEventListener('click', showNotificationModal);
  
  // Modal close events
  document.getElementById('notificationCloseBtn').addEventListener('click', closeNotificationModal);
  document.getElementById('notificationDoneBtn').addEventListener('click', closeNotificationModal);
  
  // Mark all as read button
  document.getElementById('markAllReadBtn').addEventListener('click', markAllAsRead);
  
  // Close modal when clicking outside
  document.getElementById('notificationModal').addEventListener('click', function(event) {
    if (event.target === this) {
      closeNotificationModal();
    }
  });
});
  </script>
</body>
</html>