<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ids = isset($_POST['ids']) ? $_POST['ids'] : [];
    if (!empty($ids)) {
        $conn = new mysqli($servername, $username, $passwordDB, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        // Prepare IDs for SQL
        $ids = array_map('intval', $ids);
        $idList = implode(',', $ids);
        $sql = "DELETE FROM registration WHERE id IN ($idList)";
        if ($conn->query($sql) === TRUE) {
            echo "Success";
        } else {
            echo "Error: " . $conn->error;
        }
        $conn->close();
    } else {
        echo "No IDs provided.";
    }
} else {
    echo "Invalid request.";
}
?>