<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminApvl.css?v=1.7"?>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
      <div class="navbar-profile dropdown">
        <div class="profile-icon">
          <!-- Simple user SVG icon -->
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 4-7 8-7s8 3 8 7" />
          </svg>
        </div>
        <span>Username</span>
        <div class="dropdown-content profile-dropdown-content">
          <a href="AdminProf.php">Profile Settings</a>
          <a href="index.html">Log Out</a>
        </div>
      </div>
    </div>
  </nav>
<div class="approvals-section">
        <h1 class="title">Approvals</h1>
<div class="approvals-header">
      <input type="text" class="search-input" placeholder="Search">
    </div>
    <table> 
            <thead>
                <tr>
                    <th>Approvals</th>
                    <th>Action</th>
                </tr>
<tbody>
<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$result = $conn->query("SELECT * FROM approvals WHERE status='pending' ORDER BY requested_at ASC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['description']) . "</td>
                <td>
                  <button class='open-btn'
                    data-id='" . $row['id'] . "'
                    data-type='" . htmlspecialchars($row['type']) . "'
                    data-table='" . htmlspecialchars($row['item_table']) . "'
                    data-itemid='" . htmlspecialchars($row['item_id']) . "'
                    data-data='" . htmlspecialchars($row['data']) . "'
                    data-note='" . htmlspecialchars($row['description']) . "'
                    data-date='" . htmlspecialchars($row['requested_at']) . "'
                    data-from='" . htmlspecialchars($row['requested_by']) . "'
                    data-to='Admin'
                  >Open</button>
                  <button class='delete-btn' data-id='" . $row['id'] . "'>🗑️</button>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='2'>No pending approvals.</td></tr>";
}
$conn->close();
?>
</tbody>
        </table>
    </div>
 
<!-- Modal -->
<div id="approvalModal" class="modal">
  <div class="modal-content">
    <button class="close-btn" id="closeModal">✖</button>
    <div class="modal-header">For approval</div>
    <div class="modal-row"><strong>From:</strong> <span id="modalFrom"></span>Date:<span id="modalDate"></span></div>
    <div class="modal-row"><strong>To:</strong> <span id="modalTo"></span></div>
    <div class="modal-row">
      <strong>Note:</strong>
      <textarea id="modalNote" class="note-box" readonly></textarea>
    </div>
    <div class="modal-row">
      <strong>Image proof:</strong><br />
      <img id="modalImg" class="image-proof" src="" alt="Image Proof" />
    </div>
    <button class="approve-btn" id="approveBtn">Approve</button>
  </div>
</div>

<script>
  // Get modal elements
  const modal = document.getElementById('approvalModal');
  const closeModalBtn = document.getElementById('closeModal');
  const modalFrom = document.getElementById('modalFrom');
  const modalDate = document.getElementById('modalDate');
  const modalTo = document.getElementById('modalTo');
  const modalNote = document.getElementById('modalNote');
  const modalImg = document.getElementById('modalImg');
  const approveBtn = document.getElementById('approveBtn');

  let currentApprovalId = null;
  // Event delegation for all open buttons to open modal with relevant data
document.querySelectorAll('.open-btn').forEach(button => {
  button.addEventListener('click', () => {
    modalFrom.textContent = button.getAttribute('data-from');
    modalDate.textContent = button.getAttribute('data-date');
    modalTo.textContent = button.getAttribute('data-to');
    modalNote.value = button.getAttribute('data-note');
    modalImg.src = button.getAttribute('data-img');
    currentApprovalId = button.getAttribute('data-id'); // <-- Store the approval ID
    modal.style.display = 'block';
  });
});

  // Close the modal when clicking the close button
  closeModalBtn.addEventListener('click', () => {
    modal.style.display = 'none';
  });

  // Close the modal if clicking outside the modal content
  window.addEventListener('click', (event) => {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  });

  // Approve button action - example alert or close modal
approveBtn.addEventListener('click', () => {
  if (!currentApprovalId) return;
  fetch('approve_action.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: 'id=' + encodeURIComponent(currentApprovalId)
  })
  .then(response => response.text())
  .then(data => {
    alert(data);
    modal.style.display = 'none';
    location.reload();
  });
});
</script>
</body>
</html>

