<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$id = intval($_POST['id'] ?? 0);
$res = $conn->query("SELECT * FROM approvals WHERE id=$id AND status='pending'");
if ($row = $res->fetch_assoc()) {
    $type = $row['type'];
    $item_id = $row['item_id'];
    $item_table = $row['item_table'];
    $data = json_decode($row['data'], true);

    if ($type === 'delete' && $item_table === 'materials' && $item_id) {
        // Delete the material
        $conn->query("DELETE FROM materials WHERE id=$item_id");
    } elseif ($type === 'update' && $item_table === 'materials' && $item_id) {
        // Update the material quantity
        $newQty = $data['currentQty'] - $data['deleteQty'];
        $stmt = $conn->prepare("UPDATE materials SET Quantity = ? WHERE id = ?");
        $stmt->bind_param("ii", $newQty, $item_id);
        $stmt->execute();
        $stmt->close();
    }

    $conn->query("UPDATE approvals SET status='approved' WHERE id=$id");
    echo "Action approved and processed.";
} else {
    echo "Approval not found or already processed.";
}
$conn->close();
?>