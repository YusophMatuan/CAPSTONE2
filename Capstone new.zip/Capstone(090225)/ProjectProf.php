<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="ProjectProf.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <a href="ProjectDb.html">
      <img src= "media/logo.png" class="navbar-logo"></a>
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="ProjectSites.html">Sites</a>
      <a href="ProjectOG.html">Outgoing</a>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <!-- Simple user SVG icon -->
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="8" r="4"/>
          <path d="M4 20c0-4 4-7 8-7s8 3 8 7"/>
        </svg>
      </div>
      <span>Username</span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="ProjectProf.php">Profile Settings</a>
        <a href="index.html">Log Out</a>
      </div>
    </div>
  </nav>
<div class="profile-container">
  <div class="avatar">
    <img src="media/user.png" alt="Profile Icon" class="avatar-icon" />
    <p>Add image</p>
  </div>
  <div class="user-info">
    <p><strong>Name:</strong> <?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Unknown'; ?></p>
    <p><strong>Role:</strong> <?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Unknown'; ?></p>
    <p><strong>Email:</strong> <?php echo isset($_SESSION['Email']) ? htmlspecialchars($_SESSION['Email']) : 'Unknown'; ?></p>
  </div>
</div>
    </div>
    <div class="button-container">
        <button class="button create">Create Account</button>
        <button class="button delete">Delete Account</button>
    </div>