<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminSup.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
     <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
      <div class="navbar-profile dropdown">
        <div class="profile-icon">
          <!-- Simple user SVG icon -->
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 4-7 8-7s8 3 8 7" />
          </svg>
        </div>
        <span>Username</span>
        <div class="dropdown-content profile-dropdown-content">
          <a href="AdminProf.php">Profile Settings</a>
          <a href="index.html">Log Out</a>
        </div>
      </div>
    </div>
  </nav>
<div class="container">
        <header>
            <h1>List of Suppliers</h1>
    <div class="header-right">
        <input type="text" class="search" placeholder="Search">
        <div class="buttons">
            <button class="add-suppliers">+ Add New Suppliers</button>
            <button class="export-pdf">Export PDF</button>
        </div>
        </header>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Invoice</th>
                </tr>
            </thead>
            <tbody>
<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$result = $conn->query("SELECT id, Name, Address, Email, Contact FROM suppliers ORDER BY id DESC LIMIT 20");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>" . htmlspecialchars($row['id']) . "</td>
            <td>" . htmlspecialchars($row['Name']) . "</td>
            <td>" . htmlspecialchars($row['Address']) . "</td>
            <td>" . htmlspecialchars($row['Email']) . "</td>
            <td>" . htmlspecialchars($row['Contact']) . "</td>
            <td><a href='#' class='invoice'><img src='media/pdflogo.png' style='width: 30px; height: auto;'></a></td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No suppliers found.</td></tr>";
}
$conn->close();
?>
</tbody>
        </table>
    </div>
<div id="modalOverlay" style="display:none;">
  <form id="supplierForm" class="modal-content">
    <h3>Add New Supplier</h3>

    <div class="form-group">
  <label for="name">Name</label>
  <input type="text" id="name" name="name" placeholder="Enter a name" required />
</div>
<div class="form-group">
  <label for="address">Address</label>
  <input type="text" id="address" name="address" placeholder="Enter the Address" required />
</div>
<div class="form-group">
    <div class="button-group">
      <button type="submit" class="btn-submit">Submit</button>
      <button type="button" class="btn-cancel" id="cancelBtn">Cancel</button>
    </div>
  </form>
</div>
<script>
// Get elements
const addSuppliersBtn = document.querySelector('.add-suppliers');
const modalOverlay = document.getElementById('modalOverlay');
const supplierForm = document.getElementById('supplierForm');
const cancelBtn = document.getElementById('cancelBtn');

// Show modal when "Add Purchase" button is clicked
addSuppliersBtn.addEventListener('click', () => {
  modalOverlay.style.display = 'flex';
});

// Hide modal and reset form when "Cancel" button clicked
cancelBtn.addEventListener('click', () => {
  supplierForm.reset();
  modalOverlay.style.display = 'none';
});

// Handle form submission
supplierForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const formData = new FormData(supplierForm);

  fetch('add_supplier.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    if (data.trim() === "success") {
      alert('Supplier added successfully!');
      // Optionally, reload the page or update the table here
      supplierForm.reset();
      modalOverlay.style.display = 'none';
    } else {
      alert('Error: ' + data);
    }
  })
  .catch(error => {
    alert('Error: ' + error.message);
  });
});

// Optional: Hide modal if clicking outside the form inside the overlay
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) {
    supplierForm.reset();
    modalOverlay.style.display = 'none';
  }
});

const exportBtn = document.querySelector('.export-pdf');
exportBtn.addEventListener('click', function() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  doc.text("List of Suppliers", 14, 14);

  // Get table headers and rows
  const table = document.querySelector('table');
  const head = [];
  table.querySelectorAll('thead th').forEach(th => head.push(th.innerText));
  const body = [];
  table.querySelectorAll('tbody tr').forEach(tr => {
    const row = [];
    tr.querySelectorAll('td').forEach(td => row.push(td.innerText));
    body.push(row);
  });

  doc.autoTable({
    head: [head],
    body: body,
    startY: 20,
    styles: { fontSize: 10 }
  });

  doc.save('suppliers.pdf');
});

  </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.7.0/jspdf.plugin.autotable.min.js"></script>
</body>
</html>