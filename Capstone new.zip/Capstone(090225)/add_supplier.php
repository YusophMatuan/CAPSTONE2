<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $contact = trim($_POST['contact'] ?? '');

    $stmt = $conn->prepare("INSERT INTO suppliers (Name, Address, Email, Contact) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $address, $email, $contact);

    if ($stmt->execute()) {
        // Log to history table
        $desc = "Added supplier: $name";
        $action = "Add Supplier";
        $conn->query("INSERT INTO history (description, action) VALUES ('$desc', '$action')");
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }
    $stmt->close();
}
$conn->close();
?>