<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminDB.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
      <div class="navbar-profile dropdown">
        <div class="profile-icon">
          <!-- Simple user SVG icon -->
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 4-7 8-7s8 3 8 7" />
          </svg>
        </div>
        <span>Username</span>
        <div class="dropdown-content profile-dropdown-content">
          <a href="AdminProf.php">Profile Settings</a>
          <a href="index.html">Log Out</a>
        </div>
      </div>
    </div>
  </nav>
  <!-- Inventory Dashboard Layout -->
<div class="dashboard-container">
  <div class="dashboard-section">
<div class="dashboard-card">
  <div class="dashboard-title">Materials Summary</div>
  <table class="scrollable-table">
    <thead>
      <tr>
        <th>Material</th>
        <th>Quantity</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $servername = "localhost";
      $username = "root";
      $passwordDB = "";
      $dbname = "capstone";
      $conn = new mysqli($servername, $username, $passwordDB, $dbname);

      $result = $conn->query("SELECT MaterialsName, Quantity FROM materials LIMIT 10");
      if ($result && $result->num_rows > 0) {
          while ($row = $result->fetch_assoc()) {
              echo "<tr><td>" . htmlspecialchars($row['MaterialsName']) . "</td><td>" . htmlspecialchars($row['Quantity']) . "</td></tr>";
          }
      } else {
          echo "<tr><td colspan='2'>No materials found.</td></tr>";
      }
      $conn->close();
      ?>
    </tbody>
  </table>
</div>
    <div class="dashboard-card">
      <div class="dashboard-title">Sites</div>
      <table>
        <thead>
          <tr>
            <th>Site</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
        <?php
        $servername = "localhost";
        $username = "root";
        $passwordDB = "";
        $dbname = "capstone";
        $conn = new mysqli($servername, $username, $passwordDB, $dbname);

        $result = $conn->query("SELECT SiteName, date FROM sites ORDER BY date ASC LIMIT 10");
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>" . htmlspecialchars($row['SiteName']) . "</td><td>" . htmlspecialchars($row['date']) . "</td></tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No sites found.</td></tr>";
        }
        $conn->close();
        ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="dashboard-section">
    <div class="dashboard-card">
      <div class="dashboard-title">Low on stocks - Fast Moving</div>
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
      <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
        </tbody>
      </table>
    </div>
    <div class="dashboard-card">
      <div class="dashboard-title">Low on stocks - Slow Moving</div>
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
        </tbody>
      </table>
    </div>
    <div class="dashboard-card">
      <div class="dashboard-title">Low on stocks</div>
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Quantity</th>
          </tr>
        </thead>
        <tbody>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
          <tr><td></td><td></td></tr>
  </div>
</div>
</body>
