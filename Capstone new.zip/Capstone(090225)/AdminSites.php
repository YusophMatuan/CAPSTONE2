<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminSites.css?v=1.3"?>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
     <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
      <div class="navbar-profile dropdown">
        <div class="profile-icon">
          <!-- Simple user SVG icon -->
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 4-7 8-7s8 3 8 7" />
          </svg>
        </div>
        <span>Username</span>
        <div class="dropdown-content profile-dropdown-content">
          <a href="AdminProf.php">Profile Settings</a>
          <a href="index.html">Log Out</a>
        </div>
      </div>
    </div>
  </nav>
<div class="sites-section">
        <h1>Sites</h1>
        
        <div class="sites-header">
            <input type="text" placeholder="Search" class="search-input">
            <div class="buttons">
                <button id="add-btn" class="add-sites">Add Sites</button>
                <button id="print-btn" class="export-pdf">Print</button>
            </div>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Site name</th>
                    <th>Location</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

<tbody>
<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);
$sql = "SELECT id, SiteName, Location, Date, Status FROM sites";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0):
    while($row = $result->fetch_assoc()):
?>
    <tr data-site-id="<?php echo $row['id']; ?>">
    <td><?php echo htmlspecialchars($row['SiteName']); ?></td>
    <td><?php echo htmlspecialchars($row['Location']); ?></td>
    <td><?php echo htmlspecialchars($row['Date']); ?></td>
    <td><?php echo htmlspecialchars($row['Status']); ?></td>
    <td class="status ongoing"><button class="status-btn open-btn">Open</button></td>
</tr>
<?php
    endwhile;
else:
?>
    <tr>
        <td colspan="5">No sites found.</td>
    </tr>
<?php endif; ?>
</tbody>
        </table>
    </div>
   <!-- Modal Structure -->
<div class="modal-overlay" id="modalOverlay">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
    <button class="close-btn" id="modalCloseBtn" aria-label="Close modal">X</button>
    <h2 id="modalTitle">Site Name</h2>
    <p><strong>Date:</strong> <span id="modalDate"></span></p>
    <p><strong>Location:</strong> <span id="modalLocation"></span></p>

    <label for="modalNote">Note:</label>
    <textarea id="modalNote" placeholder="Enter your notes here..."></textarea>

<div class="materials-tools-container" style="display: flex; gap: 40px;">
  <div>
    <strong>MATERIALS:</strong>
    <table id="modalMaterials" style="border-collapse: collapse; width: 300px;">
      <thead>
        <tr>
          <th style="text-align: left; padding: 4px;">Select</th>
          <th style="text-align: left; padding: 4px;">Material</th>
          <th style="text-align: left; padding: 4px;">Quantity</th>
        </tr>
      </thead>
      <tbody>
        <!-- materials rows will be inserted here -->
      </tbody>
    </table>
  </div>
  <div>
    <strong>TOOLS:</strong>
    <table id="modalTools" style="border-collapse: collapse; width: 300px;">
      <thead>
        <tr>
          <th style="text-align: left; padding: 4px;">Select</th>
          <th style="text-align: left; padding: 4px;">Tool</th>
          <th style="text-align: left; padding: 4px;">Quantity</th>
        </tr>
      </thead>
      <tbody>
        <!-- tools rows will be inserted here -->
      </tbody>
    </table>
  </div>
</div>
<!-- Move status radio buttons outside the tools container -->
<div class="status-radio-group" style="margin-top: 20px;">
  <label>
    <input type="radio" name="siteStatus" value="Pending" checked>
    Pending
  </label>
  <label>
    <input type="radio" name="siteStatus" value="Ongoing">
    Ongoing
  </label>
  <label>
    <input type="radio" name="siteStatus" value="Finished">
    Finished
  </label>
</div>

    <button class="done-btn" id="modalDoneBtn">Done</button>
  </div>
</div>
    <!-- Add Site Form -->
<!-- Modal structure -->
<div id="siteModal" class="modal2">
  <div class="modal-content2">
    <div class="modal-header">
      <h2>Add site</h2>
      <button id="closeBtn" title="Close">X</button>
    </div>
    <form id="siteForm">
      <label for="siteName">Site name:</label>
      <input type="text" id="siteName" name="siteName" />

      <label for="date">Date:</label>
      <input type="date" id="date" name="date" />

      <label for="location">Location:</label>
      <input type="text" id="location" name="location" />

      <label for="notes">Notes:</label>
      <textarea id="notes" name="notes" rows="5"></textarea>

<!-- Materials Selection -->
<div>
  <strong>Select Materials:</strong>
  <table>
    <thead>
      <tr>
        <th>Select</th>
        <th>Material</th>
        <th>Available</th>
        <th>Quantity</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $matConn = new mysqli($servername, $username, $passwordDB, $dbname);
      $matResult = $matConn->query("SELECT id, MaterialsName, Quantity FROM materials");
      if ($matResult && $matResult->num_rows > 0):
        while($mat = $matResult->fetch_assoc()):
      ?>
      <tr>
        <td><input type="checkbox" name="materials[]" value="<?php echo $mat['id']; ?>" class="material-checkbox"></td>
        <td><?php echo htmlspecialchars($mat['MaterialsName']); ?></td>
        <td><?php echo $mat['Quantity']; ?></td>
        <td>
          <input type="number" name="material_qty_<?php echo $mat['id']; ?>" min="1" max="<?php echo $mat['Quantity']; ?>" disabled>
        </td>
      </tr>
      <?php endwhile; endif; ?>
    </tbody>
  </table>
</div>

<!-- Tools Selection -->
<div>
  <strong>Select Tools:</strong>
  <table>
    <thead>
      <tr>
        <th>Select</th>
        <th>Tool</th>
        <th>Available</th>
        <th>Quantity</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $toolConn = new mysqli($servername, $username, $passwordDB, $dbname);
      $toolResult = $toolConn->query("SELECT id, ToolsName, Quantity FROM tools");
      if ($toolResult && $toolResult->num_rows > 0):
        while($tool = $toolResult->fetch_assoc()):
      ?>
      <tr>
        <td><input type="checkbox" name="tools[]" value="<?php echo $tool['id']; ?>" class="tool-checkbox"></td>
        <td><?php echo htmlspecialchars($tool['ToolsName']); ?></td>
        <td><?php echo $tool['Quantity']; ?></td>
        <td>
          <input type="number" name="tool_qty_<?php echo $tool['id']; ?>" min="1" max="<?php echo $tool['Quantity']; ?>" disabled>
        </td>
      </tr>
      <?php endwhile; endif; ?>
    </tbody>
  </table>
</div>

      <button type="submit" id="doneBtn">Done</button>
    </form>
  </div>
</div>
<!-- Updated Confirmation Modal -->
<div id="updatedModal" class="modal" style="display:none;">
  <div class="modal-content" style="text-align:center; padding: 20px;">
    <p>Materials Updated!</p>
    <button id="updatedDoneBtn">Done</button>
  </div>
</div>

<script>

const modalOverlay = document.getElementById('modalOverlay');
const modalCloseBtn = document.getElementById('modalCloseBtn');
const modalDoneBtn = document.getElementById('modalDoneBtn');
const modalTitle = document.getElementById('modalTitle');
const modalDate = document.getElementById('modalDate');
const modalLocation = document.getElementById('modalLocation');
const modalNote = document.getElementById('modalNote');
const modalMaterials = document.getElementById('modalMaterials');
const modalTools = document.getElementById('modalTools');

const updatedModal = document.getElementById('updatedModal');
const updatedDoneBtn = document.getElementById('updatedDoneBtn');

const modal = document.getElementById('siteModal');
const addBtn = document.querySelector('.add-btn');
const closeBtn = document.getElementById('closeBtn');
const siteForm = document.getElementById('siteForm');

let currentRow = null; // Track the currently opened row

// Example data for materials and tools per site - this could come from your backend or be dynamic
const siteData = {
  "Lores site": {
    materials: ["Cement", "Bricks", "Sand", "Steel Rods"],
    tools: ["Hammer", "Drill", "Saw", "Measuring Tape"]
  },
  "Example site 2": {
    materials: ["Wood", "Nails", "Paint"],
    tools: ["Screwdriver", "Ladder"]
  }
};

// Open modal and populate with selected site data
function openModal(row) {
  currentRow = row;

  const siteName = row.cells[0].innerText || "Unknown site";
  const date = row.cells[2].innerText || "";
  const location = row.cells[1].innerText || "";
  const statusCell = row.cells[3];
  const siteId = row.getAttribute('data-site-id');

  modalTitle.innerText = siteName;
  modalDate.innerText = date;
  modalLocation.innerText = location;
  modalNote.value = "";

  // Clear tables
  modalMaterials.querySelector('tbody').innerHTML = "";
  modalTools.querySelector('tbody').innerHTML = "";

  // Fetch materials for this site
  fetch('get_site_materials.php?site_id=' + siteId)
    .then(response => response.text())
    .then(html => {
      modalMaterials.querySelector('tbody').innerHTML = html;
      modalMaterials.querySelectorAll('.material-checkbox').forEach(cb => {
        cb.addEventListener('change', function() {
          const qtyInput = this.closest('tr').querySelector('input[type="number"]');
          qtyInput.disabled = !this.checked;
          if (!this.checked) qtyInput.value = '';
        });
      });
    });

  // Fetch tools for this site
  fetch('get_site_tools.php?site_id=' + siteId)
    .then(response => response.text())
    .then(html => {
      modalTools.querySelector('tbody').innerHTML = html;
      modalTools.querySelectorAll('.tool-checkbox').forEach(cb => {
        cb.addEventListener('change', function() {
          const qtyInput = this.closest('tr').querySelector('input[type="number"]');
          qtyInput.disabled = !this.checked;
          if (!this.checked) qtyInput.value = '';
        });
      });
    });

  // Set the radio button based on current status text in the table
  const currentStatusText = statusCell.innerText.trim();
  const radios = document.getElementsByName('siteStatus');
  let matched = false;
  radios.forEach(radio => {
    if (radio.value.toLowerCase() === currentStatusText.toLowerCase()) {
      radio.checked = true;
      matched = true;
    }
  });
  if (!matched) {
    radios[0].checked = true;
  }

  modalOverlay.style.display = "flex";
}

  

    // Enable/disable quantity input based on checkbox for materials
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.material-checkbox').forEach(cb => {
    cb.addEventListener('change', function() {
      const qtyInput = this.closest('tr').querySelector('input[type="number"]');
      qtyInput.disabled = !this.checked;
      if (!this.checked) qtyInput.value = '';
    });
  });
  document.querySelectorAll('.tool-checkbox').forEach(cb => {
    cb.addEventListener('change', function() {
      const qtyInput = this.closest('tr').querySelector('input[type="number"]');
      qtyInput.disabled = !this.checked;
      if (!this.checked) qtyInput.value = '';
    });
  });
});


// Attach event listeners to all open buttons
document.querySelectorAll('.open-btn').forEach(btn => {
  btn.addEventListener('click', (e) => {
    const row = e.target.closest('tr');
    openModal(row);
  });
});

document.addEventListener('DOMContentLoaded', function() {
  // For materials
  document.querySelectorAll('.material-checkbox').forEach(cb => {
    cb.addEventListener('change', function() {
      const qtyInput = this.closest('tr').querySelector('input[type="number"]');
      qtyInput.disabled = !this.checked;
      if (!this.checked) qtyInput.value = '';
    });
  });
  // For tools
  document.querySelectorAll('.tool-checkbox').forEach(cb => {
    cb.addEventListener('change', function() {
      const qtyInput = this.closest('tr').querySelector('input[type="number"]');
      qtyInput.disabled = !this.checked;
      if (!this.checked) qtyInput.value = '';
    });
  });
});

// Close modal handlers for site details modal
modalCloseBtn.addEventListener('click', () => {
  modalOverlay.style.display = "none";
});
modalDoneBtn.addEventListener('click', () => {
  if (!currentRow) return;

  // Get selected status from radio buttons
  const selectedStatus = document.querySelector('input[name="siteStatus"]:checked').value;

  // Update the status cell text and class for styling
  const statusCell = currentRow.cells[3];
  statusCell.innerText = selectedStatus;

  // Optionally update the class for styling (remove old classes and add new)
  statusCell.className = 'status'; // reset classes
  if (selectedStatus.toLowerCase() === 'ongoing') {
    statusCell.classList.add('ongoing');
  } else if (selectedStatus.toLowerCase() === 'onpause') {
    statusCell.classList.add('onpause');
  } else if (selectedStatus.toLowerCase() === 'onstop') {
    statusCell.classList.add('onstop');
  }

  modalOverlay.style.display = "none";
});

// Optional: close modal when clicking outside modal content
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) {
    modalOverlay.style.display = "none";
  }
});

// Show the Add Site modal when Add button is clicked
addBtn.addEventListener('click', () => {
  modal.style.display = 'flex'; // Using flex to center modal content
});

// Close the Add Site modal when Close (X) button is clicked
closeBtn.addEventListener('click', () => {
  modal.style.display = 'none';
  siteForm.reset(); // Reset form when closing
});

// Close the Add Site modal if clicked outside the modal-content box
window.addEventListener('click', (event) => {
  if (event.target === modal) {
    modal.style.display = 'none';
    siteForm.reset();
  }
});

// Handle Add Site form submission
siteForm.addEventListener('submit', (e) => {
  e.preventDefault();

  const formData = new FormData(siteForm);

  fetch('add_site.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    if (data.trim() === "success") {
      location.reload();
    } else {
      alert("Error adding site: " + data);
    }
  })
  .catch(error => {
    alert("Error: " + error.message);
  });

  modal.style.display = 'none';
  siteForm.reset();
  updatedModal.style.display = 'block';
});

// Close updated modal on Done button click
updatedDoneBtn.addEventListener('click', () => {
  updatedModal.style.display = 'none';
});

// Optional: close updated modal if clicking outside modal content
window.addEventListener('click', (event) => {
  if (event.target === updatedModal) {
    updatedModal.style.display = 'none';
  }
});

 
</script>

</body>
</html>