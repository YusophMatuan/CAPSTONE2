<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName = isset($_POST['siteName']) ? trim($_POST['siteName']) : '';
    $date = isset($_POST['date']) ? $_POST['date'] : '';
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    $status = "P";

    // --- Collect selected materials and quantities ---
    $materialsArr = [];
    if (!empty($_POST['materials'])) {
        foreach ($_POST['materials'] as $matId) {
            $qtyField = 'material_qty_' . $matId;
            $qty = isset($_POST[$qtyField]) ? intval($_POST[$qtyField]) : 0;
            if ($qty > 0) {
                $materialsArr[] = $matId . ':' . $qty;
                // Deduct from materials table
                $conn->query("UPDATE materials SET Quantity = Quantity - $qty WHERE id = $matId AND Quantity >= $qty");
            }
        }
    }
    $materialsStr = implode(',', $materialsArr);

    // --- Collect selected tools and quantities ---
    $toolsArr = [];
    if (!empty($_POST['tools'])) {
        foreach ($_POST['tools'] as $toolId) {
            $qtyField = 'tool_qty_' . $toolId;
            $qty = isset($_POST[$qtyField]) ? intval($_POST[$qtyField]) : 0;
            if ($qty > 0) {
                $toolsArr[] = $toolId . ':' . $qty;
                // Deduct from tools table
                $conn->query("UPDATE tools SET Quantity = Quantity - $qty WHERE id = $toolId AND Quantity >= $qty");
            }
        }
    }
    $toolsStr = implode(',', $toolsArr);

    // --- Insert into sites table, including materials and tools columns ---
    $stmt = $conn->prepare("INSERT INTO sites (SiteName, date, location, Notes, materials, tools, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $siteName, $date, $location, $notes, $materialsStr, $toolsStr, $status);

    if ($stmt->execute()) {
        $site_id = $conn->insert_id;

        // Insert into site_materials
        if (!empty($_POST['materials'])) {
            foreach ($_POST['materials'] as $matId) {
                $qtyField = 'material_qty_' . $matId;
                $qty = isset($_POST[$qtyField]) ? intval($_POST[$qtyField]) : 0;
                if ($qty > 0) {
                    $conn->query("INSERT INTO site_materials (site_id, material_id, quantity) VALUES ($site_id, $matId, $qty)");
                }
            }
        }

        // Insert into site_tools
        if (!empty($_POST['tools'])) {
            foreach ($_POST['tools'] as $toolId) {
                $qtyField = 'tool_qty_' . $toolId;
                $qty = isset($_POST[$qtyField]) ? intval($_POST[$qtyField]) : 0;
                if ($qty > 0) {
                    $conn->query("INSERT INTO site_tools (site_id, tool_id, quantity) VALUES ($site_id, $toolId, $qty)");
                }
            }
        }

        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>