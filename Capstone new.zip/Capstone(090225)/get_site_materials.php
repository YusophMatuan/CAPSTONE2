<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$site_id = intval($_GET['site_id'] ?? 0);

// Fetch assigned materials for this site, join to get material name
$sql = "SELECT m.id, m.MaterialsName, sm.quantity 
        FROM site_materials sm
        JOIN materials m ON sm.material_id = m.id
        WHERE sm.site_id = $site_id";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()):
?>
<tr>
  <td>
<input type="checkbox" class="material-checkbox" data-id="<?= $row['id'] ?>" checked>
  </td>
  <td><?= htmlspecialchars($row['MaterialsName']) ?></td>
  <td>
<input type="number" class="material-qty" data-id="<?= $row['id'] ?>"
      min="1"
      value="<?= $row['quantity'] ?>">
  </td>
</tr>
<?php endwhile; ?>