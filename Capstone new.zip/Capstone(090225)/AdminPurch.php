<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminPurch.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
        <span>Art glass</span>
        <span>And Aluminum Supplies</span>
      </div>
    </div>
    <div class="navbar-links">
   <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.html">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.html">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
      <div class="navbar-profile dropdown">
        <div class="profile-icon">
          <!-- Simple user SVG icon -->
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 4-7 8-7s8 3 8 7" />
          </svg>
        </div>
        <span>Username</span>
        <div class="dropdown-content profile-dropdown-content">
          <a href="AdminProf.php">Profile Settings</a>
          <a href="index.html">Log Out</a>
        </div>
      </div>
    </div>
  </nav>
<div class="container">
        <header>
            <h1>Purchase Product List</h1>
<div class="header-right">
        <input type="text" class="search" placeholder="Search">
            <div class="buttons">
                <button class="add-purchase">+ Add New Purchase</button>
                <button class="export-pdf">Export PDF</button>
            </div>
        </header>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Products</th>
                    <th>Suppliers</th>
                    <th>Qty.</th>
                    <th>Date</th>
                    <th>Invoice</th>
                </tr>
            </thead>
<tbody>
<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$result = $conn->query("SELECT id, Product, Supplier, Quantity, Date FROM purchase ORDER BY Date DESC LIMIT 20");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
    <td>" . htmlspecialchars($row['id']) . "</td>
    <td>" . htmlspecialchars($row['Product']) . "</td>
    <td>" . htmlspecialchars($row['Supplier']) . "</td>
    <td>" . htmlspecialchars($row['Quantity']) . "</td>
    <td>" . htmlspecialchars($row['Date']) . "</td>
    <td>
      <a href='#' class='invoice'
         data-id='" . htmlspecialchars($row['id']) . "'
         data-product='" . htmlspecialchars($row['Product']) . "'
         data-supplier='" . htmlspecialchars($row['Supplier']) . "'
         data-quantity='" . htmlspecialchars($row['Quantity']) . "'
         data-date='" . htmlspecialchars($row['Date']) . "'>
        <img src='media/pdflogo.png' style='width: 30px; height: auto;'>
      </a>
    </td>
</tr>";
    }
} else {
    echo "<tr><td colspan='6'>No purchases found.</td></tr>";
}
$conn->close();
?>
</tbody>
        </table>
    </div>
  

<div id="modalOverlay" style="display:none;">
  <form id="purchaseForm" class="modal-content">
    <h3>Add New Purchase</h3>

    <label for="product">Product</label>
    <input type="text" id="product" name="product" placeholder="Enter Product name" required />

<label for="supplier">Supplier</label>
<select id="supplier" name="supplier" required>
  <option value="">Select supplier</option>
</select>

    <label for="quantity">Quantity</label>
    <input type="number" id="quantity" name="quantity" placeholder="Enter quantity" min="1" required />

    <label for="date">Date</label>
    <input type="date" id="date" name="date" required />

    <div class="button-group">
      <button type="submit" class="btn-submit">Submit</button>
      <button type="button" class="btn-cancel" id="cancelBtn">Cancel</button>
    </div>
  </form>
</div>



  <script>
// Get elements
const addPurchaseBtn = document.querySelector('.add-purchase');
const modalOverlay = document.getElementById('modalOverlay');
const purchaseForm = document.getElementById('purchaseForm');
const cancelBtn = document.getElementById('cancelBtn');

// Show modal when "Add Purchase" button is clicked
addPurchaseBtn.addEventListener('click', () => {
  modalOverlay.style.display = 'flex';
});

// Hide modal and reset form when "Cancel" button clicked
cancelBtn.addEventListener('click', () => {
  purchaseForm.reset();
  modalOverlay.style.display = 'none';
});

// Handle form submission
purchaseForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const formData = new FormData(purchaseForm);

  fetch('add_purchase.php', {
    method: 'POST',
    body: formData
  })
  .then(response => response.text())
  .then(data => {
    if (data.trim() === "success") {
      alert('Purchase added successfully!');
      purchaseForm.reset();
      modalOverlay.style.display = 'none';
      // Optionally, reload the table here
    } else {
      alert('Error: ' + data);
    }
  })
  .catch(error => {
    alert('Error: ' + error.message);
  });
});

// Optional: Hide modal if clicking outside the form inside the overlay
modalOverlay.addEventListener('click', (e) => {
  if (e.target === modalOverlay) {
    purchaseForm.reset();
    modalOverlay.style.display = 'none';
  }
});

// Fetch supplier names and populate the dropdown
function loadSuppliers() {
  fetch('get_suppliers.php')
    .then(response => response.json())
    .then(data => {
      const supplierSelect = document.getElementById('supplier');
      supplierSelect.innerHTML = '<option value="">Select supplier</option>';
      data.forEach(supplier => {
        const option = document.createElement('option');
        option.value = supplier.Name;
        option.textContent = supplier.Name;
        supplierSelect.appendChild(option);
      });
    });
}

// Load suppliers when modal opens
addPurchaseBtn.addEventListener('click', () => {
  loadSuppliers();
  modalOverlay.style.display = 'flex';
});

const exportBtn = document.querySelector('.export-pdf');
exportBtn.addEventListener('click', function() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  doc.text("List of Purchases", 14, 14);

  // Get table headers and rows
  const table = document.querySelector('table');
  const head = [];
  table.querySelectorAll('thead th').forEach(th => head.push(th.innerText));
  const body = [];
  table.querySelectorAll('tbody tr').forEach(tr => {
    const row = [];
    tr.querySelectorAll('td').forEach(td => row.push(td.innerText));
    body.push(row);
  });

  doc.autoTable({
    head: [head],
    body: body,
    startY: 20,
    styles: { fontSize: 10 }
  });

  doc.save('purchases.pdf');
});

// Invoice PDF generation
document.querySelectorAll('.invoice').forEach(btn => {
  btn.addEventListener('click', function(e) {
    e.preventDefault();
    const product = this.getAttribute('data-product');
    const supplier = this.getAttribute('data-supplier');
    const quantity = this.getAttribute('data-quantity');
    const date = this.getAttribute('data-date');
    const id = this.getAttribute('data-id');

    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFontSize(18);
    doc.text("Purchase Invoice", 14, 20);

    doc.setFontSize(12);
    doc.text(`Invoice #: ${id}`, 14, 35);
    doc.text(`Date: ${date}`, 14, 45);

    doc.text(`Supplier: ${supplier}`, 14, 60);

    doc.autoTable({
      startY: 75,
      head: [['Product', 'Quantity']],
      body: [
        [product, quantity]
      ]
    });

    doc.text("Thank you for your business!", 14, doc.lastAutoTable.finalY + 20);

    doc.save(`invoice_${id}.pdf`);
  });
});
  </script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.7.0/jspdf.plugin.autotable.min.js"></script>
</body>
</body>
</html>