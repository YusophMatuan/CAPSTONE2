# TODO: Change Fast/Slow Moving to Remarks in AdminTools.php

- [x] Change table headers from "Fast Moving" and "Slow Moving" to "Remarks"
- [x] Update table body to display remarks text instead of fast/slow values
- [x] Add remarks input field to the add tools modal form
- [x] Update database query to use remarks column instead of FastMoving/SlowMoving
- [x] Update form submission JavaScript to handle remarks input
