<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT id, Name, role, Email FROM registration");
$accounts = [];
while ($row = $result->fetch_assoc()) {
    $accounts[] = $row;
}
$conn->close();

header('Content-Type: application/json');
echo json_encode($accounts);
?>