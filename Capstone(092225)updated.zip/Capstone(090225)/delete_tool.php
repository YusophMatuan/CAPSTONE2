<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $deleteQty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

    $conn = new mysqli($servername, $username, $passwordDB, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get current quantity
    $stmt = $conn->prepare("SELECT Quantity FROM tools WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($currentQty);
    $stmt->fetch();
    $stmt->close();

    if ($deleteQty > 0 && $currentQty >= $deleteQty) {
        $newQty = $currentQty - $deleteQty;
        if ($newQty > 0) {
            $stmt = $conn->prepare("UPDATE tools SET Quantity = ? WHERE id = ?");
            $stmt->bind_param("ii", $newQty, $id);
            $stmt->execute();
            $stmt->close();
            echo "success";
        } else {
            // Optionally delete the row if quantity is zero
            $stmt = $conn->prepare("DELETE FROM tools WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
            echo "deleted";
        }
    } else {
        echo "error: Invalid quantity";
    }

    $conn->close();
}
?>