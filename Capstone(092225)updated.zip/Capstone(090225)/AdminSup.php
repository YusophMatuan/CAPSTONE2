<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminSup.css?v=1.5">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body> 
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo">
      <div class="navbar-company">
       <span>Art Glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
    
    <!-- Notification bell -->
    <div class="navbar-notification">
      <div class="notification-icon">
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    
    <!-- Profile section -->
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.html">Log Out</a>
      </div>
    </div>
  </nav>

  <div class="container">
    <header>
      <h1>List of Suppliers</h1>
      <div class="header-right">
        <input type="text" class="search" placeholder="Search">
        <div class="buttons">
          <button class="add-suppliers">+ Add New Suppliers</button>
          <button class="export-pdf">Export PDF</button>
        </div>
      </div>
    </header>

    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Address</th>
          <th>Email</th>
          <th>Contact</th>
          <th>TIN ID</th>
        </tr>
      </thead>
      <tbody id="suppliersTableBody">
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
        <tr>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
          <td></td>
        </tr>
      </tbody>
    </table>
  </div>

  <!-- Supplier Form Modal -->
  <div id="modalOverlay" class="modal" style="display:none;">
    <div class="supplier-modal-content">
      <div class="supplier-modal-header">
        <h3>Add New Supplier</h3>
        <button class="supplier-close-btn" id="supplierCloseBtn">×</button>
      </div>
      
      <form id="suppliersForm">
        <div class="supplier-form-body">
          <label for="supplier">Name</label>
          <input type="text" id="supplier" name="supplier" placeholder="Enter Supplier Name" required>

          <label for="address">Address</label>
          <input type="text" id="address" name="address" placeholder="Enter the Address" required>

          <label for="contact">Contact #</label>
          <input type="number" id="contact" name="contact" placeholder="Enter Contact #" min="1" required>

          <label for="email">Email Address</label>
          <input type="email" id="email" name="email" placeholder="Enter Email Address" required>

          <label for="tinid">TIN ID</label>
          <input type="text" id="tinid" name="tinid" placeholder="Enter TIN ID" required>
        </div>

        <div class="supplier-button-group">
          <button type="submit" class="supplier-btn-submit">Submit</button>
          <button type="button" class="supplier-btn-cancel" id="cancelBtn">Cancel</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Restock Warning Modal -->
  <div id="restockModal" class="modal" style="display:none;">
    <div class="restock-modal-content">
      <div class="restock-modal-header">
        <h2>Restock Warning</h2>
        <button id="restockCloseBtn" class="restock-close-button">×</button>
      </div>
      <div class="restock-modal-body">
        <p>The following materials are low on stock and need to be restocked:</p>
        <ul id="lowStockList"></ul>
      </div>
      <div class="restock-modal-footer">
        <button id="restockDoneBtn">Done</button>
      </div>
    </div>
  </div>

  <script>
    // Get elements
    const addSuppliersBtn = document.querySelector('.add-suppliers');
    const modalOverlay = document.getElementById('modalOverlay');
    const suppliersForm = document.getElementById('suppliersForm');
    const cancelBtn = document.getElementById('cancelBtn');
    const supplierCloseBtn = document.getElementById('supplierCloseBtn');
    const restockModal = document.getElementById('restockModal');
    const notificationBell = document.getElementById('notificationBell');

    // Show supplier modal when "Add Suppliers" button is clicked
    addSuppliersBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      modalOverlay.style.display = 'flex';
    });

    // Hide supplier modal functions
    function closeSupplierModal() {
      suppliersForm.reset();
      modalOverlay.style.display = 'none';
    }

    // Close supplier modal events
    cancelBtn.addEventListener('click', closeSupplierModal);
    supplierCloseBtn.addEventListener('click', closeSupplierModal);

    // Close supplier modal when clicking outside
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        closeSupplierModal();
      }
    });

    // Handle form submission
    suppliersForm.addEventListener('submit', function(event) {
      event.preventDefault();

      // Get form values
      const name = this.supplier.value.trim();
      const address = this.address.value.trim();
      const email = this.email.value.trim();
      const contact = this.contact.value.trim();
      const tinid = this.tinid.value.trim();

      // Validate required fields
      if (!name || !address || !email || !contact || !tinid) {
        alert('Please fill in all required fields.');
        return;
      }

      // Auto-generate ID (simple counter)
      const tableBody = document.getElementById('suppliersTableBody');
      const existingRows = tableBody.querySelectorAll('tr');
      let nextId = 1;
      
      // Find the highest existing ID
      existingRows.forEach(row => {
        const firstCell = row.cells[0];
        if (firstCell && firstCell.textContent.trim() !== '') {
          const id = parseInt(firstCell.textContent);
          if (!isNaN(id) && id >= nextId) {
            nextId = id + 1;
          }
        }
      });

      // Find first empty row or create new one
      let targetRow = null;
      existingRows.forEach(row => {
        if (!targetRow && row.cells[1].textContent.trim() === '') {
          targetRow = row;
        }
      });

      if (!targetRow) {
        targetRow = document.createElement('tr');
        tableBody.appendChild(targetRow);
        for (let i = 0; i < 6; i++) {
          targetRow.appendChild(document.createElement('td'));
        }
      }

      // Fill the row
      targetRow.cells[0].textContent = nextId;
      targetRow.cells[1].textContent = name;
      targetRow.cells[2].textContent = address;
      targetRow.cells[3].textContent = email;
      targetRow.cells[4].textContent = contact;
      targetRow.cells[5].textContent = tinid;

      alert('Supplier added successfully!');
      closeSupplierModal();
    });

    // Check for low stock on page load
    window.addEventListener('DOMContentLoaded', () => {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          if (data.length > 0) {
            document.getElementById('notificationBadge').style.display = 'block';
          }
        })
        .catch(error => console.error('Error fetching low stock:', error));
    });

    // Handle notification bell click
    notificationBell.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          const list = document.getElementById('lowStockList');
          list.innerHTML = '';
          if (data.length > 0) {
            data.forEach(item => {
              const li = document.createElement('li');
              li.textContent = `${item.MaterialsName} - Quantity: ${item.Quantity}`;
              list.appendChild(li);
            });
          } else {
            const li = document.createElement('li');
            li.textContent = 'No low stock items at the moment.';
            list.appendChild(li);
          }
          restockModal.style.display = 'flex';
        })
        .catch(error => {
          console.error('Error fetching low stock:', error);
          const list = document.getElementById('lowStockList');
          list.innerHTML = '<li>Error loading stock data. Please try again later.</li>';
          restockModal.style.display = 'flex';
        });
    });

    // Close restock modal
    document.getElementById('restockCloseBtn').addEventListener('click', () => {
      restockModal.style.display = 'none';
    });

    document.getElementById('restockDoneBtn').addEventListener('click', () => {
      restockModal.style.display = 'none';
    });

    // Close restock modal when clicking outside
    restockModal.addEventListener('click', (e) => {
      if (e.target === restockModal) {
        restockModal.style.display = 'none';
      }
    });
  </script>
</body>
</html>