<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminDB.css?v=2.4">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo">
      <div class="navbar-company">
       <span>Art Glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
<div class="navbar-profile dropdown">
  <div class="profile-icon">
    <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
  </div>
  <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
  <div class="dropdown-content profile-dropdown-content">
    <a href="AdminProf.php">Profile Settings</a>
    <a href="index.html">Log Out</a>
  </div>
</div>
</nav>
  <div class="dashboard-container">
    <div class="dashboard-section">
      <div class="dashboard-card">
        <div class="dashboard-title">Materials Summary</div>
        <table>
          <thead>
            <tr>
              <th>Material</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
      <div class="dashboard-card">
        <div class="dashboard-title">Tools Summary</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="dashboard-section">
      <div class="dashboard-card">
        <div class="dashboard-title">Low on stocks - Fast Moving</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
      <div class="dashboard-card">
        <div class="dashboard-title">Low on stocks - Slow Moving</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
      <div class="dashboard-card">
        <div class="dashboard-title">Sites</div>
        <table>
          <thead>
            <tr>
              <th>Site</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
            <tr><td></td><td></td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div id="restockModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Restock Warning</h2>
        <button id="restockCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <p>The following materials are low on stock and need to be restocked:</p>
        <ul id="lowStockList"></ul>
        <button id="restockDoneBtn">Done</button>
      </div>
    </div>
  </div>

  <script>
    window.addEventListener('DOMContentLoaded', () => {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          if (data.length > 0) {
            document.getElementById('notificationBadge').style.display = 'block';
          }
        })
        .catch(error => console.error('Error fetching low stock:', error));
    });

    document.getElementById('notificationBell').addEventListener('click', () => {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          const list = document.getElementById('lowStockList');
          list.innerHTML = '';
          if (data.length > 0) {
            data.forEach(item => {
              const li = document.createElement('li');
              li.textContent = `${item.MaterialsName} - Quantity: ${item.Quantity}`;
              list.appendChild(li);
            });
          } else {
            const li = document.createElement('li');
            li.textContent = 'No low stock items at the moment.';
            list.appendChild(li);
          }
          document.getElementById('restockModal').style.display = 'flex';
        })
        .catch(error => {
          console.error('Error fetching low stock:', error);
          alert('Error fetching low stock data. Please check the console for details.');
        });
    });

    document.getElementById('restockCloseBtn').addEventListener('click', () => {
      document.getElementById('restockModal').style.display = 'none';
    });

    document.getElementById('restockDoneBtn').addEventListener('click', () => {
      document.getElementById('restockModal').style.display = 'none';
    });

    document.getElementById('restockModal').addEventListener('click', (event) => {
      if (event.target === document.getElementById('restockModal')) {
        document.getElementById('restockModal').style.display = 'none';
      }
    });
  </script>
</body>
</html>