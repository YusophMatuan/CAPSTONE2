<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminCT.css?v=1.7"?/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap" />
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src= "media/MainLogo.png" class="navbar-logo"></a>
      <div class="navbar-company">
       <span>Art Glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
    <a href="AdminProf.php">Profile Settings</a>
    <a href="index.html">Log Out</a>
    </div>
  </nav>

<div class="cutting-section">
    <div class="section-header">
      <h1>Cutting List</h1>
    </div>

    <div class="cutting-list">
      <div class="cutting-item">
        <div class="item-image">
          <div class="image-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21,15 16,10 5,21"/>
            </svg>
          </div>
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title"></h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="cutting-item">
        <div class="item-image">
          <div class="image-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21,15 16,10 5,21"/>
            </svg>
          </div>
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title"></h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="cutting-item">
        <div class="item-image">
          <div class="image-placeholder">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#666" stroke-width="2">
              <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
              <circle cx="8.5" cy="8.5" r="1.5"/>
              <polyline points="21,15 16,10 5,21"/>
            </svg>
          </div>
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title"></h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                  <div class="dropdown-item" data-value=""> </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Restock Warning Modal -->
  <div id="restockModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Restock Warning</h2>
        <button id="restockCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <p>The following materials are low on stock and need to be restocked:</p>
        <ul id="lowStockList"></ul>
        <button id="restockDoneBtn">Done</button>
      </div>
    </div>
  </div>

  <script>
    // Custom dropdown functionality
    document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
      const btn = dropdown.querySelector('.dropdown-btn');
      const menu = dropdown.querySelector('.dropdown-menu');
      const selectedText = dropdown.querySelector('.selected-text');
      
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        
        // Close other dropdowns
        document.querySelectorAll('.custom-dropdown').forEach(other => {
          if (other !== dropdown) {
            other.classList.remove('active');
          }
        });
        
        dropdown.classList.toggle('active');
      });
      
      dropdown.querySelectorAll('.dropdown-item').forEach(item => {
        item.addEventListener('click', (e) => {
          selectedText.textContent = item.textContent;
          dropdown.classList.remove('active');
          
          // Add selected class for styling
          dropdown.querySelectorAll('.dropdown-item').forEach(i => i.classList.remove('selected'));
          item.classList.add('selected');
        });
      });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
      document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
        dropdown.classList.remove('active');
      });
    });

    // Low stock notification functionality
    window.addEventListener('DOMContentLoaded', () => {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          if (data.length > 0) {
            document.getElementById('notificationBadge').style.display = 'block';
          }
        })
        .catch(error => console.error('Error fetching low stock:', error));
    });

    document.getElementById('notificationBell').addEventListener('click', () => {
      fetch('get_low_stock.php')
        .then(response => response.json())
        .then(data => {
          const list = document.getElementById('lowStockList');
          list.innerHTML = '';
          if (data.length > 0) {
            data.forEach(item => {
              const li = document.createElement('li');
              li.textContent = `${item.MaterialsName} - Quantity: ${item.Quantity}`;
              list.appendChild(li);
            });
          } else {
            const li = document.createElement('li');
            li.textContent = 'No low stock items at the moment.';
            list.appendChild(li);
          }
          document.getElementById('restockModal').style.display = 'flex';
        })
        .catch(error => {
          console.error('Error fetching low stock:', error);
          alert('Error fetching low stock data. Please check the console for details.');
        });
    });

    document.getElementById('restockCloseBtn').addEventListener('click', () => {
      document.getElementById('restockModal').style.display = 'none';
    });

    document.getElementById('restockDoneBtn').addEventListener('click', () => {
      document.getElementById('restockModal').style.display = 'none';
    });

    window.addEventListener('click', (event) => {
      const modal = document.getElementById('restockModal');
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
  </script>
</body>
</html>