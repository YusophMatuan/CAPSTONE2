<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}

// Handle profile photo upload
if (isset($_POST['savePhoto']) && isset($_FILES['profilePhoto'])) {
    $file = $_FILES['profilePhoto'];
    if ($file['error'] == 0) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $fileName = uniqid() . '_' . basename($file['name']);
        $uploadPath = $uploadDir . $fileName;
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            $_SESSION['profilePhoto'] = $uploadPath;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminProf.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src= "media/MainLogo.png" class="navbar-logo"></a>
      <div class="navbar-company">
      <span>Art Glass and Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
    <a href="AdminProf.php">Profile Settings</a>
    <a href="index.html">Log Out</a>
    </div>
  </nav>

<!-- Profile Container -->
<div class="container">
        <div class="profile-card">
            <div class="profile-header">
                <form method="post" enctype="multipart/form-data">
                    <div class="avatar-container">
                        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile Avatar" class="avatar" id="currentAvatar">
                        <div class="avatar-overlay">
                            <span>Change Photo</span>
                        </div>
                    </div>
                    <input type="file" accept="image/*" id="profilePhotoInput" name="profilePhoto" style="display:none;">
                    <button type="submit" name="savePhoto" class="btn btn-primary" style="margin-top: 10px;">Save Photo</button>
                </form>
                <div class="profile-info">
                    <h2 id="profileName"><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Unknown'; ?></h2>
                    <div class="role" id="profileRole"><?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Unknown'; ?></div>
                    <div class="email" id="profileEmail"><?php echo isset($_SESSION['Email']) ? htmlspecialchars($_SESSION['Email']) : 'Unknown'; ?></div>
                </div>
            </div>

            <div class="info-grid">
                <div class="info-item">
                    <label>Full Name</label>
                    <div class="value" id="displayName"><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Unknown'; ?></div>
                </div>
                <div class="info-item">
                    <label>Role</label>
                    <div class="value" id="displayRole"><?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Unknown'; ?></div>
                </div>
                <div class="info-item">
                    <label>Email Address</label>
                    <div class="value" id="displayEmail"><?php echo isset($_SESSION['Email']) ? htmlspecialchars($_SESSION['Email']) : 'Unknown'; ?></div>
                </div>
                <div class="info-item">
                    <label>Password</label>
                    <div class="password-field">
                        <input type="password" id="passwordField" value="********" readonly>
                        <button class="toggle-password" id="togglePassword">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <div class="actions">
                <button class="btn btn-primary" id="createAccountBtn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    Create New Account
                </button>
                <button class="btn btn-danger" id="deleteAccountBtn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3,6 5,6 21,6"></polyline>
                        <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
                        <line x1="10" y1="11" x2="10" y2="17"></line>
                        <line x1="14" y1="11" x2="14" y2="17"></line>
                    </svg>
                    Manage Accounts
                </button>
            </div>
        </div>
    </div>

    <!-- Create Account Modal -->
    <div id="createAccountModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New Account</h2>
                <button class="close-btn" id="closeCreateModal">&times;</button>
            </div>

            <div class="modal-avatar">
                <img src="https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=100&h=100&fit=crop&crop=face" alt="Profile" id="modalProfileImage">
                <input type="file" accept="image/*" id="profileImageInput" style="display:none;">
                <p>Click image to change photo</p>
            </div>

            <form id="createAccountForm">
                <div class="form-group">
                    <label for="newName">Full Name</label>
                    <input type="text" id="newName" name="Name" required>
                </div>

                <div class="form-group">
                    <label for="newEmail">Email Address</label>
                    <input type="email" id="newEmail" name="Email" required>
                </div>

                <div class="form-group">
                    <label>Select Role</label>
                    <div class="role-selector">
                        <div class="role-option">
                            <input type="radio" name="role" value="Admin" id="adminRole">
                            <label for="adminRole">Admin</label>
                        </div>
                        <div class="role-option">
                            <input type="radio" name="role" value="Inventory Mngr." id="inventoryRole">
                            <label for="inventoryRole">Inventory</label>
                        </div>
                        <div class="role-option">
                            <input type="radio" name="role" value="Project Mngr." id="projectRole">
                            <label for="projectRole">Project</label>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="newPassword">Password</label>
                    <input type="password" id="newPassword" name="password" required>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Create Account
                </button>
            </form>
        </div>
    </div>

    <!-- Delete Account Modal -->
    <div id="deleteAccountModal" class="modal">
        <div class="modal-content delete-modal-content">
            <div class="modal-header">
                <h2>Manage Accounts</h2>
                <button class="close-btn" id="closeDeleteModal">&times;</button>
            </div>

            <table class="delete-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th style="text-align: center;">Select</th>
                    </tr>
                </thead>
                <tbody id="deleteAccountList">
                    <tr>
                        <td>Jane Smith</td>
                        <td>Project Manager</td>
                        <td>jane.smith@company.com</td>
                        <td style="text-align: center;"><input type="checkbox" class="delete-checkbox" data-id="1"></td>
                    </tr>
                    <tr>
                        <td>Mike Johnson</td>
                        <td>Inventory Manager</td>
                        <td>mike.johnson@company.com</td>
                        <td style="text-align: center;"><input type="checkbox" class="delete-checkbox" data-id="2"></td>
                    </tr>
                    <tr>
                        <td>Sarah Wilson</td>
                        <td>Administrator</td>
                        <td>sarah.wilson@company.com</td>
                        <td style="text-align: center;"><input type="checkbox" class="delete-checkbox" data-id="3"></td>
                    </tr>
                </tbody>
            </table>

            <div style="text-align: center;">
                <button id="confirmDeleteBtn" class="btn btn-danger">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3,6 5,6 21,6"></polyline>
                        <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
                    </svg>
                    Delete Selected Accounts
                </button>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal success-modal">
        <div class="modal-content">
            <div class="success-icon">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <polyline points="20,6 9,17 4,12"></polyline>
                </svg>
            </div>
            <h2>Success!</h2>
            <p>Account has been created successfully.</p>
            <button class="btn btn-primary" id="successDoneBtn">Done</button>
        </div>
    </div>

    <script>
        // Modal functionality
        const createModal = document.getElementById('createAccountModal');
        const deleteModal = document.getElementById('deleteAccountModal');
        const successModal = document.getElementById('successModal');

        // Open create modal
        document.getElementById('createAccountBtn').addEventListener('click', () => {
            createModal.style.display = 'flex';
        });

        // Open delete modal
        document.getElementById('deleteAccountBtn').addEventListener('click', () => {
            deleteModal.style.display = 'flex';
        });

        // Close modals
        document.getElementById('closeCreateModal').addEventListener('click', () => {
            createModal.style.display = 'none';
        });

        document.getElementById('closeDeleteModal').addEventListener('click', () => {
            deleteModal.style.display = 'none';
        });

        // Close on background click
        [createModal, deleteModal, successModal].forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                }
            });
        });

        // Profile image upload
        document.getElementById('modalProfileImage').addEventListener('click', () => {
            document.getElementById('profileImageInput').click();
        });

        document.getElementById('profileImageInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    document.getElementById('modalProfileImage').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });

        // Password toggle
        document.getElementById('togglePassword').addEventListener('click', () => {
            const passwordField = document.getElementById('passwordField');
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
        });

        // Form submission
        document.getElementById('createAccountForm').addEventListener('submit', (e) => {
            e.preventDefault();
            createModal.style.display = 'none';
            successModal.style.display = 'flex';
        });

        // Success modal done button
        document.getElementById('successDoneBtn').addEventListener('click', () => {
            successModal.style.display = 'none';
        });

        // Delete confirmation
        document.getElementById('confirmDeleteBtn').addEventListener('click', () => {
            const checkedBoxes = document.querySelectorAll('.delete-checkbox:checked');
            if (checkedBoxes.length === 0) {
                alert('Please select at least one account to delete.');
                return;
            }

            // Simulate deletion
            checkedBoxes.forEach(checkbox => {
                checkbox.closest('tr').remove();
            });

            deleteModal.style.display = 'none';
        });

        // Profile photo change functionality
        document.querySelector('.avatar-container').addEventListener('click', () => {
            document.getElementById('profilePhotoInput').click();
        });

        document.getElementById('profilePhotoInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    document.getElementById('currentAvatar').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });


</script>

</body>
</html> 