
<?php
// Database connection variables - update these with your info
$servername = "localhost";
$username = "root";
$passwordDB = ""; // usually empty in XAMPP
$dbname = "capstone";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Name = isset($_POST['Name']) ? $_POST['Name'] : '';
    $Email = isset($_POST['Email']) ? $_POST['Email'] : '';
    $role = isset($_POST['role']) ? $_POST['role'] : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';

    $Name = trim($Name);
    $Email = strtolower(trim($Email));
    $role = trim($role);
    $password = trim($password);

    // Hash password before saving (ONLY ONCE)
   //$hashed_password = password_hash($password, PASSWORD_DEFAULT);

    try {
        $conn = new mysqli($servername, $username, $passwordDB, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }


        $stmt = $conn->prepare("INSERT INTO registration (Name, Email, role, password) VALUES (?, ?, ?, ?)");
        if (!$stmt) {
            throw new Exception("Prepare statement failed: " . $conn->error);
        }

        $stmt->bind_param("ssss", $Name, $Email, $role, $password);

        if ($stmt->execute()) {
            echo "Success";
        } else {
            throw new Exception("Execute failed: " . $stmt->error);
        }

        $stmt->close();
        $conn->close();

    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "No form data submitted.";
}
?>
