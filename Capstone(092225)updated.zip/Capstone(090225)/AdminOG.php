<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminOG.css?v=1.4">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body> 
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src= "media/MainLogo.png" class="navbar-logo"></a>
      <div class="navbar-company">
     <span>Art Glass and Aluminum Supply</span>
      </div>
    </div>
     <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
     <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
    <a href="AdminProf.php">Profile Settings</a>
    <a href="index.html">Log Out</a>
    </div>
  </nav>
<div class="outgoing-section">
        <h1>Outgoing Product List</h1>
        <div class="outgoing-header">
            <input type="text" class="search-input" placeholder="Search">
            <div class="buttons">
                <button class="add-outgoing">+ Add Outgoing Product List</button>
                <button class="export-pdf">Export PDF</button>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Products</th>
                    <th>Sites</th>
                    <th>Qty.</th>
                    <th>Date</th>
                    <th>Invoice</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Modernized Add Outgoing Modal -->
    <div id="addOutgoingModal" class="modal" style="display:none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title">Add New Outgoing Product</h2>
                <button class="close-button" id="closeOutgoingBtn">×</button>
            </div>
            <form id="outgoingForm" class="modal-form">
                <label for="product">Product</label>
                <input type="text" id="product" name="product" placeholder="Enter Product name" required />

                <label for="site">Sites</label>
                <input type="text" id="site" name="site" placeholder="Enter Site name" required />

                <label for="quantity">Quantity</label>
                <input type="number" id="quantity" name="quantity" placeholder="Enter quantity" min="1" required />

                <label for="date">Date</label>
                <input type="date" id="date" name="date" required />

                <button type="submit" class="btn-submit">Submit Product</button>
            </form>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal" style="display:none;">
        <div class="modal-content">
            <div class="success-icon"></div>
            <p>Product Added Successfully!</p>
            <button id="successDoneBtn">Done</button>
        </div>
    </div>

    <!-- Modernized Restock Warning Modal -->
    <div id="restockModal" class="modal" style="display:none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Restock Warning</h2>
                <button id="restockCloseBtn" class="close-button">×</button>
            </div>
            <div class="modal-body">
                <p>The following materials are low on stock and need to be restocked:</p>
                <ul id="lowStockList"></ul>
                <button id="restockDoneBtn">Done</button>
            </div>
        </div>
    </div>

<script>
// Get elements
const addOutgoingBtn = document.querySelector('.add-outgoing');
const addOutgoingModal = document.getElementById('addOutgoingModal');
const outgoingForm = document.getElementById('outgoingForm');
const closeOutgoingBtn = document.getElementById('closeOutgoingBtn');
const successModal = document.getElementById('successModal');
const successDoneBtn = document.getElementById('successDoneBtn');

// Show modal when "Add Outgoing Product List" button is clicked
addOutgoingBtn.addEventListener('click', () => {
  addOutgoingModal.style.display = 'flex';
});

// Hide modal and reset form when "Close" button clicked
closeOutgoingBtn.addEventListener('click', () => {
  outgoingForm.reset();
  addOutgoingModal.style.display = 'none';
});

// Handle form submission
outgoingForm.addEventListener('submit', function(event) {
  event.preventDefault();

  // Hide add modal and show success modal
  addOutgoingModal.style.display = 'none';
  successModal.style.display = 'flex';

  // Reset form
  this.reset();
});

// Handle success modal close
successDoneBtn.addEventListener('click', () => {
  successModal.style.display = 'none';
});

// Optional: Hide modals if clicking outside the form inside the overlay
addOutgoingModal.addEventListener('click', (e) => {
  if (e.target === addOutgoingModal) {
    outgoingForm.reset();
    addOutgoingModal.style.display = 'none';
  }
});

successModal.addEventListener('click', (e) => {
  if (e.target === successModal) {
    successModal.style.display = 'none';
  }
});

// Check for low stock on page load
window.addEventListener('DOMContentLoaded', () => {
  fetch('get_low_stock.php')
    .then(response => response.json())
    .then(data => {
      if (data.length > 0) {
        document.getElementById('notificationBadge').style.display = 'block';
      }
    })
    .catch(error => console.error('Error fetching low stock:', error));
});

// Handle notification bell click
document.getElementById('notificationBell').addEventListener('click', () => {
  fetch('get_low_stock.php')
    .then(response => response.json())
    .then(data => {
      const list = document.getElementById('lowStockList');
      list.innerHTML = '';
      if (data.length > 0) {
        data.forEach(item => {
          const li = document.createElement('li');
          li.textContent = `${item.MaterialsName} - Quantity: ${item.Quantity}`;
          list.appendChild(li);
        });
      } else {
        const li = document.createElement('li');
        li.textContent = 'No low stock items at the moment.';
        list.appendChild(li);
      }
      document.getElementById('restockModal').style.display = 'flex';
    })
    .catch(error => {
      console.error('Error fetching low stock:', error);
      alert('Error fetching low stock data. Please check the console for details.');
    });
});

// Close restock modal
document.getElementById('restockCloseBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

document.getElementById('restockDoneBtn').addEventListener('click', () => {
  document.getElementById('restockModal').style.display = 'none';
});

// Close restock modal if clicking outside
document.getElementById('restockModal').addEventListener('click', (event) => {
  if (event.target === document.getElementById('restockModal')) {
    document.getElementById('restockModal').style.display = 'none';
  }
});
  </script>

</body>
</html>