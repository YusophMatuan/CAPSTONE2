<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminHsty.css?v=1.6">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
       <span>Art Glass & Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>

  <!-- Modern History Section -->
  <div class="modern-history-container">
    <div class="history-header">
      <div class="header-content">
        <h1 class="page-title">
          <i class="fas fa-history"></i>
          Activity History
        </h1>
        <p class="page-subtitle">Track all system activities and changes</p>
      </div>
      <div class="header-actions">
        <div class="search-container">
          <i class="fas fa-search search-icon"></i>
          <input type="text" class="modern-search-bar" placeholder="Search activities..." id="historySearch">
          <button class="search-clear" id="clearSearch">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <div class="filter-container">
          <button class="filter-btn" id="filterBtn">
            <i class="fas fa-filter"></i>
            Filter
          </button>
          <div class="filter-dropdown" id="filterDropdown">
            <div class="filter-option" data-filter="all">
              <i class="fas fa-list"></i>
              All Activities
            </div>
            <div class="filter-option" data-filter="create">
              <i class="fas fa-plus-circle"></i>
              Created
            </div>
            <div class="filter-option" data-filter="update">
              <i class="fas fa-edit"></i>
              Updated
            </div>
            <div class="filter-option" data-filter="delete">
              <i class="fas fa-trash"></i>
              Deleted
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="history-stats">
      <div class="stat-card">
        <div class="stat-icon">
          <i class="fas fa-chart-line"></i>
        </div>
        <div class="stat-content">
          <h3 class="stat-number" id="totalActivities">0</h3>
          <p class="stat-label">Total Activities</p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">
          <i class="fas fa-clock"></i>
        </div>
        <div class="stat-content">
          <h3 class="stat-number" id="todayActivities">0</h3>
          <p class="stat-label">Today</p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon">
          <i class="fas fa-calendar-week"></i>
        </div>
        <div class="stat-content">
          <h3 class="stat-number" id="weekActivities">0</h3>
          <p class="stat-label">This Week</p>
        </div>
      </div>
    </div>

    <div class="history-table-container">
      <div class="table-header">
        <h2>Recent Activities</h2>
        <div class="table-actions">
          <button class="action-btn export-btn">
            <i class="fas fa-download"></i>
            Export
          </button>
          <button class="action-btn refresh-btn" id="refreshBtn">
            <i class="fas fa-sync-alt"></i>
            Refresh
          </button>
        </div>
      </div>

      <div class="modern-table-wrapper">
        <table class="modern-history-table">
          <thead>
            <tr>
              <th class="sortable" data-sort="description">
                <div class="th-content">
                  <span>Activity Description</span>
                  <i class="fas fa-sort"></i>
                </div>
              </th>
              <th class="sortable" data-sort="action">
                <div class="th-content">
                  <span>Action Type</span>
                  <i class="fas fa-sort"></i>
                </div>
              </th>
            </tr>
          </thead>
          <tbody id="historyTableBody">
            <?php
            $servername = "localhost";
            $username = "root";
            $passwordDB = "";
            $dbname = "capstone";
            $conn = new mysqli($servername, $username, $passwordDB, $dbname);

            $result = $conn->query("SELECT description, action, created_at FROM history ORDER BY created_at DESC LIMIT 50");
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $actionClass = strtolower(str_replace(' ', '-', $row['action']));
                    $actionIcon = '';
                    switch(strtolower($row['action'])) {
                        case 'create':
                        case 'created':
                            $actionIcon = 'fas fa-plus-circle';
                            break;
                        case 'update':
                        case 'updated':
                            $actionIcon = 'fas fa-edit';
                            break;
                        case 'delete':
                        case 'deleted':
                            $actionIcon = 'fas fa-trash';
                            break;
                        default:
                            $actionIcon = 'fas fa-info-circle';
                    }
                    
                    echo "<tr class='activity-row' data-action='" . $actionClass . "'>
                            <td class='activity-description'>
                              <div class='activity-content'>
                                <div class='activity-text'>" . htmlspecialchars($row['description']) . "</div>
                                <div class='activity-time'>
                                  <i class='fas fa-clock'></i>
                                  " . date('M d, Y • H:i', strtotime($row['created_at'])) . "
                                </div>
                              </div>
                            </td>
                            <td class='activity-action'>
                              <span class='action-badge " . $actionClass . "'>
                                <i class='" . $actionIcon . "'></i>
                                " . htmlspecialchars($row['action']) . "
                              </span>
                            </td>
                          </tr>";
                }
            } else {
                echo "<tr class='empty-row'>
                        <td colspan='2'>
                          <div class='empty-state'>
                            <i class='fas fa-inbox'></i>
                            <h3>No History Found</h3>
                            <p>There are no activities to display at the moment.</p>
                          </div>
                        </td>
                      </tr>";
            }
            $conn->close();
            ?>
          </tbody>
        </table>
      </div>

      <div class="table-pagination">
        <div class="pagination-info">
          Showing <span id="currentRange">1-50</span> of <span id="totalRecords">50</span> records
        </div>
        <div class="pagination-controls">
          <button class="pagination-btn" disabled>
            <i class="fas fa-chevron-left"></i>
            Previous
          </button>
          <div class="pagination-numbers">
            <button class="pagination-number active">1</button>
            <button class="pagination-number">2</button>
            <button class="pagination-number">3</button>
          </div>
          <button class="pagination-btn">
            Next
            <i class="fas fa-chevron-right"></i>
          </button>
        </div>
      </div>
    </div>
  </div>

  <!-- Keep all existing modals -->
  <!-- History Modal -->
  <div id="historyModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <div class="title">History Details</div>
        <button class="close-button" id="closeModal">×</button>
      </div>
      <div class="modal-body">
        <div class="modal-info-row">
          <div class="info-item">
            <strong>From:</strong>
            <div class="info-value" id="modalFrom"></div>
          </div>
          <div class="info-item">
            <strong>Date:</strong>
            <div class="info-value" id="modalDate"></div>
          </div>
        </div>
        <div class="modal-info-row">
          <div class="info-item full-width">
            <strong>To:</strong>
            <div class="info-value" id="modalTo"></div>
          </div>
        </div>
        <div class="modal-info-row full-width">
          <div class="info-item full-width">
            <strong>Note:</strong>
            <textarea id="modalNote" class="note-box" readonly></textarea>
          </div>
        </div>
        <div class="modal-info-row full-width">
          <div class="info-item full-width">
            <strong>Image proof:</strong>
            <div class="image-container">
              <img id="modalImg" class="image-proof" src="" alt="Image Proof" />
            </div>
          </div>
        </div>
        <button class="approve-btn" id="closeBtn">Close</button>
      </div>
    </div>
  </div>
  
  <!-- Updated Notification Modal -->
  <div id="notificationModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Delete Confirmation Modal -->
  <div id="deleteModal" class="modal">
    <div class="modal-content">
      <div class="modal-header">
        <div class="title">Confirm Delete</div>
        <button class="close-button" id="deleteCloseBtn">×</button>
      </div>
      <div class="modal-body">
        <p>Are you sure you want to delete this history item?</p>
        <div class="button-group">
          <button id="confirmDeleteBtn" class="confirm-btn">Confirm</button>
          <button id="cancelDeleteBtn" class="cancel-btn">Cancel</button>
        </div>
      </div>
    </div>
  </div>

  <!-- Updated Modal -->
  <div id="updatedModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="success-icon"></div>
      <p>Item deleted successfully!</p>
      <button id="updatedDoneBtn">Done</button>
    </div>
  </div>

  <script>
    // Get modal elements
    const modal = document.getElementById('historyModal');
    const closeModalBtn = document.getElementById('closeModal');
    const modalFrom = document.getElementById('modalFrom');
    const modalDate = document.getElementById('modalDate');
    const modalTo = document.getElementById('modalTo');
    const modalNote = document.getElementById('modalNote');
    const modalImg = document.getElementById('modalImg');
    const closeBtn = document.getElementById('closeBtn');

    const deleteModal = document.getElementById('deleteModal');
    const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');
    const cancelDeleteBtn = document.getElementById('cancelDeleteBtn');
    const deleteCloseBtn = document.getElementById('deleteCloseBtn');
    const updatedModal = document.getElementById('updatedModal');
    const updatedDoneBtn = document.getElementById('updatedDoneBtn');
    let rowToDelete = null;

    // Show modal with animation
    function showModal(modalElement) {
      modalElement.style.display = 'flex';
      setTimeout(() => {
        modalElement.classList.add('show');
      }, 10);
    }

    // Hide modal with animation
    function hideModal(modalElement) {
      modalElement.classList.remove('show');
      setTimeout(() => {
        modalElement.style.display = 'none';
      }, 300);
    }

    // Event delegation for all open buttons to open modal with relevant data
    document.querySelectorAll('.open-btn').forEach(button => {
      button.addEventListener('click', () => {
        modalFrom.textContent = button.getAttribute('data-from');
        modalDate.textContent = button.getAttribute('data-date');
        modalTo.textContent = button.getAttribute('data-to');
        modalNote.value = button.getAttribute('data-note');
        modalImg.src = button.getAttribute('data-img');
        
        showModal(modal);
      });
    });

    // Close the modal when clicking the close button
    closeModalBtn.addEventListener('click', () => {
      hideModal(modal);
    });

    // Close the modal if clicking outside the modal content
    window.addEventListener('click', (event) => {
      if (event.target === modal) {
        hideModal(modal);
      }
      if (event.target === deleteModal) {
        hideModal(deleteModal);
      }
      if (event.target === updatedModal) {
        hideModal(updatedModal);
      }
      if (event.target === document.getElementById('notificationModal')) {
        closeNotificationModal();
      }
    });

    // Close button action
    closeBtn.addEventListener('click', () => {
      hideModal(modal);
    });

    // Event delegation for delete buttons
    document.querySelectorAll('.delete-btn').forEach(button => {
      button.addEventListener('click', () => {
        rowToDelete = button.closest('tr');
        showModal(deleteModal);
      });
    });

    // Confirm delete
    confirmDeleteBtn.addEventListener('click', () => {
      if (rowToDelete) {
        rowToDelete.remove();
        rowToDelete = null;
      }
      hideModal(deleteModal);
      showModal(updatedModal);
    });

    // Cancel delete
    cancelDeleteBtn.addEventListener('click', () => {
      hideModal(deleteModal);
      rowToDelete = null;
    });

    // Delete modal close button
    deleteCloseBtn.addEventListener('click', () => {
      hideModal(deleteModal);
      rowToDelete = null;
    });

    // Updated done
    updatedDoneBtn.addEventListener('click', () => {
      hideModal(updatedModal);
    });
    
    // Modern History Functionality
    document.addEventListener('DOMContentLoaded', function() {
      // Search functionality
      const searchInput = document.getElementById('historySearch');
      const clearSearchBtn = document.getElementById('clearSearch');
      const tableRows = document.querySelectorAll('.activity-row');
      
      searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        clearSearchBtn.style.display = searchTerm ? 'block' : 'none';
        
        tableRows.forEach(row => {
          const text = row.textContent.toLowerCase();
          row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
        
        updateStats();
      });
      
      clearSearchBtn.addEventListener('click', function() {
        searchInput.value = '';
        this.style.display = 'none';
        tableRows.forEach(row => row.style.display = '');
        updateStats();
      });
      
      // Filter functionality
      const filterBtn = document.getElementById('filterBtn');
      const filterDropdown = document.getElementById('filterDropdown');
      const filterOptions = document.querySelectorAll('.filter-option');
      
      filterBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        filterDropdown.classList.toggle('active');
      });
      
      document.addEventListener('click', function() {
        filterDropdown.classList.remove('active');
      });
      
      filterOptions.forEach(option => {
        option.addEventListener('click', function() {
          const filterValue = this.getAttribute('data-filter');
          
          // Update active state
          filterOptions.forEach(opt => opt.classList.remove('active'));
          this.classList.add('active');
          
          // Filter rows
          tableRows.forEach(row => {
            if (filterValue === 'all') {
              row.style.display = '';
            } else {
              const hasClass = row.classList.contains(filterValue) || 
                              row.getAttribute('data-action') === filterValue;
              row.style.display = hasClass ? '' : 'none';
            }
          });
          
          filterDropdown.classList.remove('active');
          updateStats();
        });
      });
      
      // Refresh button
      document.getElementById('refreshBtn').addEventListener('click', function() {
        const icon = this.querySelector('i');
        icon.style.animation = 'spin 1s linear';
        
        setTimeout(() => {
          icon.style.animation = '';
          // In real implementation, you would reload data here
          showToast('History refreshed successfully', 'success');
        }, 1000);
      });
      
      // Update statistics
      function updateStats() {
        const visibleRows = Array.from(tableRows).filter(row => row.style.display !== 'none');
        const totalActivities = visibleRows.length;
        
        document.getElementById('totalActivities').textContent = totalActivities;
        
        // Calculate today's activities
        const today = new Date().toDateString();
        const todayActivities = visibleRows.filter(row => {
          const timeElement = row.querySelector('.activity-time');
          if (timeElement) {
            const activityDate = new Date(timeElement.textContent.split('•')[0].trim());
            return activityDate.toDateString() === today;
          }
          return false;
        }).length;
        
        document.getElementById('todayActivities').textContent = todayActivities;
        
        // Calculate week activities (simplified)
        document.getElementById('weekActivities').textContent = Math.min(totalActivities, 15);
      }
      
      // Sortable columns
      document.querySelectorAll('.sortable').forEach(header => {
        header.addEventListener('click', function() {
          const sortType = this.getAttribute('data-sort');
          const icon = this.querySelector('i');
          
          // Toggle sort direction
          const isAsc = icon.classList.contains('fa-sort-up');
          document.querySelectorAll('.sortable i').forEach(i => i.className = 'fas fa-sort');
          icon.className = isAsc ? 'fas fa-sort-down' : 'fas fa-sort-up';
          
          // Sort rows (simplified implementation)
          showToast(`Sorted by ${sortType} ${isAsc ? 'descending' : 'ascending'}`, 'info');
        });
      });
      
      // Initialize stats
      updateStats();
    });
    
    // Toast notification function
    function showToast(message, type = 'info') {
      const toast = document.createElement('div');
      toast.className = `toast toast-${type}`;
      toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
        <span>${message}</span>
      `;
      
      document.body.appendChild(toast);
      
      setTimeout(() => toast.classList.add('show'), 100);
      setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
      }, 3000);
    }

    // Add spinning animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      
      .toast {
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        border-radius: 8px;
        padding: 12px 16px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.1);
        display: flex;
        align-items: center;
        gap: 8px;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        z-index: 10000;
      }
      
      .toast.show {
        transform: translateX(0);
      }
      
      .toast-success { border-left: 4px solid #4CAF50; }
      .toast-info { border-left: 4px solid #2196F3; }
      .toast-success i { color: #4CAF50; }
      .toast-info i { color: #2196F3; }
    `;
    document.head.appendChild(style);
    
    // Notification functionality
    let notifications = [];
    let unreadCount = 0;

    // Sample notification data (in a real app, this would come from a server)
    function loadSampleNotifications() {
      return [
        {
          id: 1,
          type: 'restock',
          title: 'Low Stock Alert',
          message: 'Glass Panels (5mm) are running low. Current quantity: 15 pieces',
          date: new Date('2023-10-15'),
          read: false
        },
        {
          id: 2,
          type: 'restock',
          title: 'Restock Needed',
          message: 'Aluminum Frames (Silver) need to be restocked. Only 8 units left.',
          date: new Date('2023-10-14'),
          read: false
        },
        {
          id: 3,
          type: 'other',
          title: 'New Site Assignment',
          message: 'You have been assigned to the Downtown Office project.',
          date: new Date('2023-10-13'),
          read: true
        },
        {
          id: 4,
          type: 'other',
          title: 'Approval Required',
          message: 'Purchase request #PR-2023-045 needs your approval.',
          date: new Date('2023-10-12'),
          read: false
        },
        {
          id: 5,
          type: 'restock',
          title: 'Critical Stock Level',
          message: 'Silicone Sealant is almost out of stock. Only 3 tubes remaining.',
          date: new Date('2023-10-10'),
          read: false
        }
      ];
    }

    // Format date for display
    function formatDate(date) {
      const now = new Date();
      const diffTime = Math.abs(now - date);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

      if (diffDays === 1) return 'Yesterday';
      if (diffDays < 7) return `${diffDays} days ago`;

      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
    }

    // Update notification badge
    function updateNotificationBadge() {
      const badge = document.getElementById('notificationBadge');
      unreadCount = notifications.filter(n => !n.read).length;

      if (unreadCount > 0) {
        badge.style.display = 'block';
        badge.textContent = '';  // Empty to show just the red circle without number
      } else {
        badge.style.display = 'none';
      }
    }

    // Render notifications in a specific tab
    function renderNotifications(containerId, filterType = 'all') {
      const container = document.getElementById(containerId);
      let filteredNotifications = notifications;

      if (filterType === 'restock') {
        filteredNotifications = notifications.filter(n => n.type === 'restock');
      } else if (filterType === 'other') {
        filteredNotifications = notifications.filter(n => n.type === 'other');
      }

      if (filteredNotifications.length === 0) {
        container.innerHTML = '<div class="empty-notification">No notifications found</div>';
        return;
      }

      // Sort by date (newest first)
      filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));

      container.innerHTML = filteredNotifications.map(notification => `
        <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
          <div class="notification-title">
            <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
            ${notification.title}
          </div>
          <div class="notification-message">${notification.message}</div>
          <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
        </div>
      `).join('');

      // Add click event to mark as read
      container.querySelectorAll('.notification-item').forEach(item => {
        item.addEventListener('click', function() {
          const notificationId = parseInt(this.getAttribute('data-id'));
          markAsRead(notificationId);
          this.classList.remove('unread');
        });
      });
    }

    // Mark notification as read
    function markAsRead(notificationId) {
      const notification = notifications.find(n => n.id === notificationId);
      if (notification && !notification.read) {
        notification.read = true;
        updateNotificationBadge();
      }
    }

    // Mark all notifications as read
    function markAllAsRead() {
      notifications.forEach(notification => {
        notification.read = true;
      });
      updateNotificationBadge();

      // Update UI
      document.querySelectorAll('.notification-item').forEach(item => {
        item.classList.remove('unread');
      });
    }

    // Tab switching functionality
    function setupTabs() {
      const tabButtons = document.querySelectorAll('.tab-button');
      const tabPanes = document.querySelectorAll('.tab-pane');

      tabButtons.forEach(button => {
        button.addEventListener('click', function() {
          const tabId = this.getAttribute('data-tab');

          // Update active tab button
          tabButtons.forEach(btn => btn.classList.remove('active'));
          this.classList.add('active');

          // Show corresponding tab pane
          tabPanes.forEach(pane => pane.classList.remove('active'));
          document.getElementById(`${tabId}-tab`).classList.add('active');

          // Render notifications for this tab
          if (tabId === 'all') {
            renderNotifications('allNotificationsList');
          } else if (tabId === 'restock') {
            renderNotifications('restockNotificationsList', 'restock');
          } else if (tabId === 'other') {
            renderNotifications('otherNotificationsList', 'other');
          }
        });
      });
    }

    // Show notification modal
    function showNotificationModal() {
      const modal = document.getElementById('notificationModal');
      modal.style.display = 'flex';

      // Render all notifications initially
      renderNotifications('allNotificationsList');
      renderNotifications('restockNotificationsList', 'restock');
      renderNotifications('otherNotificationsList', 'other');
    }

    // Close notification modal
    function closeNotificationModal() {
      const modal = document.getElementById('notificationModal');
      modal.style.display = 'none';
    }

    // Initialize notification system
    document.addEventListener('DOMContentLoaded', function() {
      // Load notifications
      notifications = loadSampleNotifications();
      updateNotificationBadge();
      setupTabs();

      // Notification bell click event
      document.getElementById('notificationBell').addEventListener('click', showNotificationModal);

      // Modal close events
      document.getElementById('notificationCloseBtn').addEventListener('click', closeNotificationModal);
      document.getElementById('notificationDoneBtn').addEventListener('click', closeNotificationModal);

      // Mark all as read button
      document.getElementById('markAllReadBtn').addEventListener('click', markAllAsRead);

      // Close modal when clicking outside
      document.getElementById('notificationModal').addEventListener('click', function(event) {
        if (event.target === this) {
          closeNotificationModal();
        }
      });
    });
  </script>
</body>
</html>