<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_id = intval($_POST['site_id']);
    $materials = json_decode($_POST['materials'], true); // Expecting JSON: [{id: 1, quantity: 5}, ...]

    // Start transaction
    $conn->begin_transaction();

    try {
        foreach ($materials as $material) {
            $mat_id = intval($material['id']);
            $new_qty = intval($material['quantity']);
            
            // Get old quantity from site_materials
            $stmt = $conn->prepare("SELECT quantity FROM site_materials WHERE site_id = ? AND material_id = ?");
            $stmt->bind_param("ii", $site_id, $mat_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $old_qty = 0;
            if ($row = $result->fetch_assoc()) {
                $old_qty = $row['quantity'];
            }
            
            $diff = $new_qty - $old_qty;
            
            if ($diff > 0) {
                // Need more materials - deduct from inventory
                // First check if enough available
                $checkStmt = $conn->prepare("SELECT Quantity FROM materials WHERE id = ?");
                $checkStmt->bind_param("i", $mat_id);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();
                $availableRow = $checkResult->fetch_assoc();
                
                if ($availableRow['Quantity'] < $diff) {
                    throw new Exception("Not enough materials available in inventory");
                }
                
                $updateStmt = $conn->prepare("UPDATE materials SET Quantity = Quantity - ? WHERE id = ?");
                $updateStmt->bind_param("ii", $diff, $mat_id);
                $updateStmt->execute();
                
            } elseif ($diff < 0) {
                // Return materials to inventory
                $absDiff = abs($diff);
                $updateStmt = $conn->prepare("UPDATE materials SET Quantity = Quantity + ? WHERE id = ?");
                $updateStmt->bind_param("ii", $absDiff, $mat_id);
                $updateStmt->execute();
            }
            
            // Update or insert site_materials record
            if ($old_qty == 0 && $new_qty > 0) {
                // Insert new record
                $insertStmt = $conn->prepare("INSERT INTO site_materials (site_id, material_id, quantity) VALUES (?, ?, ?)");
                $insertStmt->bind_param("iii", $site_id, $mat_id, $new_qty);
                $insertStmt->execute();
            } elseif ($new_qty > 0) {
                // Update existing record
                $updateStmt = $conn->prepare("UPDATE site_materials SET quantity = ? WHERE site_id = ? AND material_id = ?");
                $updateStmt->bind_param("iii", $new_qty, $site_id, $mat_id);
                $updateStmt->execute();
            } elseif ($new_qty == 0 && $old_qty > 0) {
                // Delete record if quantity is 0
                $deleteStmt = $conn->prepare("DELETE FROM site_materials WHERE site_id = ? AND material_id = ?");
                $deleteStmt->bind_param("ii", $site_id, $mat_id);
                $deleteStmt->execute();
            }
        }
        
        // Commit transaction
        $conn->commit();
        echo "success";
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        echo "error: " . $e->getMessage();
    }

    $conn->close();
}
?>