<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $deleteQty = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

    $conn = new mysqli($servername, $username, $passwordDB, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get current quantity
    $stmt = $conn->prepare("SELECT Quantity FROM materials WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($currentQty);
    $stmt->fetch();
    $stmt->close();

if ($deleteQty > 0 && $currentQty >= $deleteQty) {
    // Fetch material name for description
    $stmt = $conn->prepare("SELECT MaterialsName FROM materials WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($materialName);
    $stmt->fetch();
    $stmt->close();

    // Prepare approval request
    $desc = "Request to deduct $deleteQty from material: $materialName (Current Qty: $currentQty)";
    $data = json_encode([
        'id' => $id,
        'deleteQty' => $deleteQty,
        'currentQty' => $currentQty
    ]);
    $requested_by = "user"; // Replace with actual username/session if available

    $stmt = $conn->prepare("INSERT INTO approvals (type, item_id, item_table, description, data, requested_by) VALUES (?, ?, ?, ?, ?, ?)");
    $type = ($currentQty - $deleteQty > 0) ? 'update' : 'delete';
    $item_table = 'materials';
    $stmt->bind_param("sissss", $type, $id, $item_table, $desc, $data, $requested_by);
    $stmt->execute();
    $stmt->close();

    echo "pending approval";
} else {
    echo "error: Invalid quantity";
}

    $conn->close();
}
?>