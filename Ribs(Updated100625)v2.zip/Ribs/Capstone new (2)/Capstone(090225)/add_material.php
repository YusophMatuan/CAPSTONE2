<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $MaterialsName = isset($_POST['MaterialsName']) ? trim($_POST['MaterialsName']) : '';
    $quantity = isset($_POST['quantityAdd']) ? intval($_POST['quantityAdd']) : 0;
    $dateAdd = isset($_POST['dateAdd']) ? $_POST['dateAdd'] : null;
    $fastMoving = isset($_POST['fastMoving']) ? 1 : 0;
    $slowMoving = isset($_POST['slowMoving']) ? 1 : 0;

    $conn = new mysqli($servername, $username, $passwordDB, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO materials (MaterialsName, Quantity, DateAdded, FastMoving, SlowMoving) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sisii", $MaterialsName, $quantity, $dateAdd, $fastMoving, $slowMoving);

    if ($stmt->execute()) {
        // Log to history table
        $desc = "Added material: $MaterialsName (Qty: $quantity)";
        $action = "Add Material";
        $conn->query("INSERT INTO history (description, action) VALUES ('$desc', '$action')");
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>