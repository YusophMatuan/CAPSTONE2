<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

$id = intval($_POST['id'] ?? 0);
$res = $conn->query("SELECT * FROM approvals WHERE id=$id AND status='pending'");
if ($row = $res->fetch_assoc()) {
    $type = $row['type'];
    $item_id = $row['item_id'];
    $item_table = $row['item_table'];
    $data = json_decode($row['data'], true);

    if ($type === 'delete' && $item_table === 'materials' && $item_id) {
        // First, delete references in site_materials
        $conn->query("DELETE FROM site_materials WHERE material_id = $item_id");
        
        // Then delete the material itself
        $conn->query("DELETE FROM materials WHERE id = $item_id");
        
        // Log to history
        $conn->query("INSERT INTO history (description, action) VALUES ('Approved deletion of material ID: $item_id', 'Delete Material')");
        
    } elseif ($type === 'update' && $item_table === 'materials' && $item_id) {
        // Update the material quantity
        $newQty = $data['currentQty'] - $data['deleteQty'];
        $stmt = $conn->prepare("UPDATE materials SET Quantity = ? WHERE id = ?");
        $stmt->bind_param("ii", $newQty, $item_id);
        $stmt->execute();
        $stmt->close();
        
        // Log to history
        $conn->query("INSERT INTO history (description, action) VALUES ('Approved quantity update for material ID: $item_id', 'Update Material')");
    }

    $conn->query("UPDATE approvals SET status='approved' WHERE id=$id");
    echo "Action approved and processed.";
} else {
    echo "Approval not found or already processed.";
}
$conn->close();
?>