<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$site_id = intval($_GET['site_id'] ?? 0);

// Fetch assigned materials for this site
$stmt = $conn->prepare("SELECT m.id, m.MaterialsName, sm.quantity 
                        FROM site_materials sm
                        JOIN materials m ON sm.material_id = m.id
                        WHERE sm.site_id = ?");
$stmt->bind_param("i", $site_id);
$stmt->execute();
$result = $stmt->get_result();

while($row = $result->fetch_assoc()):
?>
<tr>
  <td>
    <input type="checkbox" class="material-checkbox" data-id="<?= $row['id'] ?>" checked>
  </td>
  <td><?= htmlspecialchars($row['MaterialsName']) ?></td>
  <td>
    <input type="number" class="material-qty" data-id="<?= $row['id'] ?>" min="1" value="<?= $row['quantity'] ?>">
  </td>
</tr>
<?php endwhile; 

$stmt->close();
$conn->close();
?>