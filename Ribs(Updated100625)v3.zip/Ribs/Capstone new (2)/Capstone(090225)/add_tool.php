<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ToolsName = isset($_POST['ToolsName']) ? trim($_POST['ToolsName']) : '';
    $quantity = isset($_POST['quantityAdd']) ? intval($_POST['quantityAdd']) : 0;
    $dateAdd = isset($_POST['dateAdd']) ? $_POST['dateAdd'] : null;
    $remarks = isset($_POST['remarks']) ? trim($_POST['remarks']) : '';

    $conn = new mysqli($servername, $username, $passwordDB, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO tools (ToolsName, Quantity, DateAdded, Remarks) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("siss", $ToolsName, $quantity, $dateAdd, $remarks);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>