<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminOG.css?v=1.9">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body> 
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
       <span>Art Glass & Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>
<div class="outgoing-section">
        <h1>Outgoing Product List</h1>
        <div class="outgoing-header">
            <input type="text" class="search-input" placeholder="Search">
            <div class="buttons">
                <button class="add-outgoing">+ Add Outgoing Product List</button>
                <button class="export-pdf">Export PDF</button>
            </div>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Products</th>
                    <th>Sites</th>
                    <th>Qty.</th>
                    <th>Date</th>
                    <th>Invoice</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td><a href="#" class="invoice"><img src="media/pdflogo.png" style="width: 30px; height: auto;"></a></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- Modernized Add Outgoing Modal -->
    <div id="addOutgoingModal" class="modal" style="display:none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="title">Add New Outgoing Product</h2>
                <button class="close-button" id="closeOutgoingBtn">×</button>
            </div>
            <form id="outgoingForm" class="modal-form">
                <label for="product">Product</label>
                <input type="text" id="product" name="product" placeholder="Enter Product name" required />

                <label for="site">Sites</label>
                <input type="text" id="site" name="site" placeholder="Enter Site name" required />

                <label for="quantity">Quantity</label>
                <input type="number" id="quantity" name="quantity" placeholder="Enter quantity" min="1" required />

                <label for="date">Date</label>
                <input type="date" id="date" name="date" required />

                <button type="submit" class="btn-submit">Submit Product</button>
            </form>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal" style="display:none;">
        <div class="modal-content">
            <div class="success-icon"></div>
            <p>Product Added Successfully!</p>
            <button id="successDoneBtn">Done</button>
        </div>
    </div>

   <!-- Updated Notification Modal -->
  <div id="notificationModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>

<script>
// Get elements
const addOutgoingBtn = document.querySelector('.add-outgoing');
const addOutgoingModal = document.getElementById('addOutgoingModal');
const outgoingForm = document.getElementById('outgoingForm');
const closeOutgoingBtn = document.getElementById('closeOutgoingBtn');
const successModal = document.getElementById('successModal');
const successDoneBtn = document.getElementById('successDoneBtn');

// Show modal when "Add Outgoing Product List" button is clicked
addOutgoingBtn.addEventListener('click', () => {
  addOutgoingModal.style.display = 'flex';
});

// Hide modal and reset form when "Close" button clicked
closeOutgoingBtn.addEventListener('click', () => {
  outgoingForm.reset();
  addOutgoingModal.style.display = 'none';
});

// Handle form submission
outgoingForm.addEventListener('submit', function(event) {
  event.preventDefault();

  // Hide add modal and show success modal
  addOutgoingModal.style.display = 'none';
  successModal.style.display = 'flex';

  // Reset form
  this.reset();
});

// Handle success modal close
successDoneBtn.addEventListener('click', () => {
  successModal.style.display = 'none';
});

// Optional: Hide modals if clicking outside the form inside the overlay
addOutgoingModal.addEventListener('click', (e) => {
  if (e.target === addOutgoingModal) {
    outgoingForm.reset();
    addOutgoingModal.style.display = 'none';
  }
});

successModal.addEventListener('click', (e) => {
  if (e.target === successModal) {
    successModal.style.display = 'none';
  }
});

// Notification functionality
let notifications = [];
let unreadCount = 0;

// Load notifications from low stock
async function loadNotifications() {
  try {
    const response = await fetch('get_low_stock.php');
    const lowStockData = await response.json();

    // Create restock notifications from low stock data
    const restockNotifications = lowStockData.map((item, index) => ({
      id: index + 1,
      type: 'restock',
      title: 'Low Stock Alert',
      message: `${item.MaterialsName} are running low. Current quantity: ${item.Quantity}`,
      date: new Date(),
      read: false
    }));

    // For now, no other notifications; can add sample if needed
    notifications = restockNotifications;

    updateNotificationBadge();
  } catch (error) {
    console.error('Error loading notifications:', error);
    notifications = [];
    updateNotificationBadge();
  }
}

// Format date for display
function formatDate(date) {
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

// Update notification badge
function updateNotificationBadge() {
  const badge = document.getElementById('notificationBadge');
  unreadCount = notifications.filter(n => !n.read).length;
  
  if (unreadCount > 0) {
    badge.style.display = 'block';
    badge.textContent = '';  // Empty to show just the red circle without number
  } else {
    badge.style.display = 'none';
  }
}

// Render notifications in a specific tab
function renderNotifications(containerId, filterType = 'all') {
  const container = document.getElementById(containerId);
  let filteredNotifications = notifications;
  
  if (filterType === 'restock') {
    filteredNotifications = notifications.filter(n => n.type === 'restock');
  } else if (filterType === 'other') {
    filteredNotifications = notifications.filter(n => n.type === 'other');
  }
  
  if (filteredNotifications.length === 0) {
    container.innerHTML = '<div class="empty-notification">No notifications found</div>';
    return;
  }
  
  // Sort by date (newest first)
  filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  container.innerHTML = filteredNotifications.map(notification => `
    <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
      <div class="notification-title">
        <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
        ${notification.title}
      </div>
      <div class="notification-message">${notification.message}</div>
      <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
    </div>
  `).join('');
  
  // Add click event to mark as read
  container.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {
      const notificationId = parseInt(this.getAttribute('data-id'));
      markAsRead(notificationId);
      this.classList.remove('unread');
    });
  });
}

// Mark notification as read
function markAsRead(notificationId) {
  const notification = notifications.find(n => n.id === notificationId);
  if (notification && !notification.read) {
    notification.read = true;
    updateNotificationBadge();
  }
}

// Mark all notifications as read
function markAllAsRead() {
  notifications.forEach(notification => {
    notification.read = true;
  });
  updateNotificationBadge();
  
  // Update UI
  document.querySelectorAll('.notification-item').forEach(item => {
    item.classList.remove('unread');
  });
}

// Tab switching functionality
function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabPanes = document.querySelectorAll('.tab-pane');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');
      
      // Update active tab button
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // Show corresponding tab pane
      tabPanes.forEach(pane => pane.classList.remove('active'));
      document.getElementById(`${tabId}-tab`).classList.add('active');
      
      // Render notifications for this tab
      if (tabId === 'all') {
        renderNotifications('allNotificationsList');
      } else if (tabId === 'restock') {
        renderNotifications('restockNotificationsList', 'restock');
      } else if (tabId === 'other') {
        renderNotifications('otherNotificationsList', 'other');
      }
    });
  });
}

// Show notification modal
function showNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'flex';
  
  // Render all notifications initially
  renderNotifications('allNotificationsList');
  renderNotifications('restockNotificationsList', 'restock');
  renderNotifications('otherNotificationsList', 'other');
}

// Close notification modal
function closeNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'none';
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
  // Load notifications
  loadNotifications();
  setupTabs();
  
  // Notification bell click event
  document.getElementById('notificationBell').addEventListener('click', showNotificationModal);
  
  // Modal close events
  document.getElementById('notificationCloseBtn').addEventListener('click', closeNotificationModal);
  document.getElementById('notificationDoneBtn').addEventListener('click', closeNotificationModal);
  
  // Mark all as read button
  document.getElementById('markAllReadBtn').addEventListener('click', markAllAsRead);
  
  // Close modal when clicking outside
  document.getElementById('notificationModal').addEventListener('click', function(event) {
    if (event.target === this) {
      closeNotificationModal();
    }
  });
});

// Close modals if user clicks outside modal content (for other modals)
window.addEventListener("click", (event) => {
  if (event.target === addModal) {
    addModal.style.display = "none";
  }
  if (event.target === deleteModal) {
    deleteModal.style.display = "none";
  }
  if (event.target === updatedModal) {
    updatedModal.style.display = "none";
  }
  if (event.target === document.getElementById("notificationModal")) {
    document.getElementById("notificationModal").style.display = "none";
  }
});
  </script>

</body>
</html>
