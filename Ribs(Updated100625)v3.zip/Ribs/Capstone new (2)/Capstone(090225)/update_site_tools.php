<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $site_id = intval($_POST['site_id']);
    $tools = json_decode($_POST['tools'], true); // Expecting JSON: [{id: 1, quantity: 3}, ...]

    // Start transaction
    $conn->begin_transaction();

    try {
        foreach ($tools as $tool) {
            $tool_id = intval($tool['id']);
            $new_qty = intval($tool['quantity']);
            
            // Get old quantity from site_tools
            $stmt = $conn->prepare("SELECT quantity FROM site_tools WHERE site_id = ? AND tool_id = ?");
            $stmt->bind_param("ii", $site_id, $tool_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $old_qty = 0;
            if ($row = $result->fetch_assoc()) {
                $old_qty = $row['quantity'];
            }
            
            $diff = $new_qty - $old_qty;
            
            if ($diff > 0) {
                // Need more tools - deduct from inventory
                // First check if enough available
                $checkStmt = $conn->prepare("SELECT Quantity FROM tools WHERE id = ?");
                $checkStmt->bind_param("i", $tool_id);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();
                $availableRow = $checkResult->fetch_assoc();
                
                if ($availableRow['Quantity'] < $diff) {
                    throw new Exception("Not enough tools available in inventory");
                }
                
                $updateStmt = $conn->prepare("UPDATE tools SET Quantity = Quantity - ? WHERE id = ?");
                $updateStmt->bind_param("ii", $diff, $tool_id);
                $updateStmt->execute();
                
            } elseif ($diff < 0) {
                // Return tools to inventory
                $absDiff = abs($diff);
                $updateStmt = $conn->prepare("UPDATE tools SET Quantity = Quantity + ? WHERE id = ?");
                $updateStmt->bind_param("ii", $absDiff, $tool_id);
                $updateStmt->execute();
            }
            
            // Update or insert site_tools record
            if ($old_qty == 0 && $new_qty > 0) {
                // Insert new record
                $insertStmt = $conn->prepare("INSERT INTO site_tools (site_id, tool_id, quantity) VALUES (?, ?, ?)");
                $insertStmt->bind_param("iii", $site_id, $tool_id, $new_qty);
                $insertStmt->execute();
            } elseif ($new_qty > 0) {
                // Update existing record
                $updateStmt = $conn->prepare("UPDATE site_tools SET quantity = ? WHERE site_id = ? AND tool_id = ?");
                $updateStmt->bind_param("iii", $new_qty, $site_id, $tool_id);
                $updateStmt->execute();
            } elseif ($new_qty == 0 && $old_qty > 0) {
                // Delete record if quantity is 0
                $deleteStmt = $conn->prepare("DELETE FROM site_tools WHERE site_id = ? AND tool_id = ?");
                $deleteStmt->bind_param("ii", $site_id, $tool_id);
                $deleteStmt->execute();
            }
        }
        
        // Commit transaction
        $conn->commit();
        echo "success";
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        echo "error: " . $e->getMessage();
    }

    $conn->close();
}
?>