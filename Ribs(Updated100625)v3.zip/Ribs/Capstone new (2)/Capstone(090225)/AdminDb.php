<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminDB.css?v=2.7">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
       <span>Art Glass & Aluminum Supply</span>
      </div>
    </div>

    <!-- Mobile Menu Toggle Button -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle">
      <span></span>
      <span></span>
      <span></span>
    </button>

    <!-- Desktop Navigation -->
    <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>

    <div class="navbar-notification">
      <div class="notification-icon">
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>

    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>

  <!-- Mobile Sidebar Menu -->
  <div class="mobile-sidebar" id="mobileSidebar">
    <div class="mobile-sidebar-header">
      <img src="media/MainLogo.png" alt="Logo">
      <span>Art Glass and Aluminum Supply</span>
    </div>
    
    <div class="mobile-sidebar-menu">
      <a href="AdminDb.php">Home</a>
      
      <button class="mobile-dropdown-btn" onclick="toggleMobileDropdown('inventory')">
        Inventory
        <svg class="mobile-dropdown-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="6,9 12,15 18,9"></polyline>
        </svg>
      </button>
      <div class="mobile-dropdown-content" id="inventory">
        <a href="AdminMat.php">Materials</a>
        <a href="AdminTools.php">Tools</a>
        <a href="AdminCT.php">Cutting List</a>
        <a href="AdminPurch.php">Purchasing</a>
        <a href="AdminSup.php">Suppliers</a>
      </div>
      
      <button class="mobile-dropdown-btn" onclick="toggleMobileDropdown('project')">
        Project
        <svg class="mobile-dropdown-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="6,9 12,15 18,9"></polyline>
        </svg>
      </button>
      <div class="mobile-dropdown-content" id="project">
        <a href="AdminSites.php">Sites</a>
        <a href="AdminOG.php">Outgoing</a>
      </div>
      
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
    
    <div class="mobile-sidebar-footer">
      <div class="mobile-profile-section">
        <div class="mobile-profile-icon">
          <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
        </div>
        <div class="mobile-profile-info">
          <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
        </div>
      </div>
      
      <div class="mobile-profile-actions">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.html">Log Out</a>
      </div>
    </div>
  </div>

  <!-- Mobile Overlay -->
  <div class="mobile-overlay" id="mobileOverlay"></div>

  <!-- Inventory Dashboard Layout - Grid Format -->
  <div class="dashboard-container">
    <!-- Left Column -->
    <div class="dashboard-section">
      <div class="dashboard-card">
        <div class="dashboard-title">Materials Summary</div>
        <table class="scrollable-table">
          <thead>
            <tr>
              <th>Material</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $servername = "localhost";
            $username = "root";
            $passwordDB = "";
            $dbname = "capstone";
            $conn = new mysqli($servername, $username, $passwordDB, $dbname);

            $result = $conn->query("SELECT MaterialsName, Quantity FROM materials LIMIT 10");
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr><td>" . htmlspecialchars($row['MaterialsName']) . "</td><td>" . htmlspecialchars($row['Quantity']) . "</td></tr>";
                }
            } else {
                echo "<tr><td colspan='2'>No materials found.</td></tr>";
            }
            $conn->close();
            ?>
          </tbody>
        </table>
      </div>

      <div class="dashboard-card">
        <div class="dashboard-title">Sites</div>
        <table>
          <thead>
            <tr>
              <th>Site</th>
              <th>Starting Date</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $conn = new mysqli("localhost", "root", "", "capstone");
          $result = $conn->query("SELECT SiteName, StartingDate FROM sites ORDER BY StartingDate ASC LIMIT 10");
          if ($result && $result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . htmlspecialchars($row['SiteName']) . "</td><td>" . htmlspecialchars($row['StartingDate']) . "</td></tr>";
              }
          } else {
              echo "<tr><td colspan='2'>No sites found.</td></tr>";
          }
          $conn->close();
          ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Right Column -->
    <div class="dashboard-section">
      <div class="dashboard-card">
        <div class="dashboard-title">Low on stocks - Fast Moving</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $conn = new mysqli("localhost", "root", "", "capstone");
          $result = $conn->query("SELECT MaterialsName as Item, Quantity FROM materials WHERE Quantity < 50 AND Quantity > 0 ORDER BY Quantity ASC LIMIT 5");
          if ($result && $result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . htmlspecialchars($row['Item']) . "</td><td>" . htmlspecialchars($row['Quantity']) . "</td></tr>";
              }
          } else {
              echo "<tr><td colspan='2'>No low stock items</td></tr>";
          }
          $conn->close();
          ?>
          </tbody>
        </table>
      </div>

      <div class="dashboard-card">
        <div class="dashboard-title">Low on stocks - Slow Moving</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $conn = new mysqli("localhost", "root", "", "capstone");
          $result = $conn->query("SELECT ToolsName as Item, Quantity FROM tools WHERE Quantity < 30 AND Quantity > 0 ORDER BY Quantity ASC LIMIT 5");
          if ($result && $result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . htmlspecialchars($row['Item']) . "</td><td>" . htmlspecialchars($row['Quantity']) . "</td></tr>";
              }
          } else {
              echo "<tr><td colspan='2'>No low stock items</td></tr>";
          }
          $conn->close();
          ?>
          </tbody>
        </table>
      </div>

      <div class="dashboard-card">
        <div class="dashboard-title">Low on stocks</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $conn = new mysqli("localhost", "root", "", "capstone");
          $result = $conn->query("
            SELECT MaterialsName as Item, Quantity FROM materials WHERE Quantity < 20
            UNION
            SELECT ToolsName as Item, Quantity FROM tools WHERE Quantity < 20
            ORDER BY Quantity ASC LIMIT 6
          ");
          if ($result && $result->num_rows > 0) {
              while ($row = $result->fetch_assoc()) {
                  echo "<tr><td>" . htmlspecialchars($row['Item']) . "</td><td>" . htmlspecialchars($row['Quantity']) . "</td></tr>";
              }
          } else {
              echo "<tr><td colspan='2'>No low stock items</td></tr>";
          }
          $conn->close();
          ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Updated Notification Modal -->
  <div id="notificationModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Mobile menu functionality
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    const mobileSidebar = document.getElementById('mobileSidebar');
    const mobileOverlay = document.getElementById('mobileOverlay');

    function toggleMobileMenu() {
      mobileMenuToggle.classList.toggle('active');
      mobileSidebar.classList.toggle('active');
      mobileOverlay.classList.toggle('active');
      
      if (mobileSidebar.classList.contains('active')) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    }

    function closeMobileMenu() {
      mobileMenuToggle.classList.remove('active');
      mobileSidebar.classList.remove('active');
      mobileOverlay.classList.remove('active');
      document.body.style.overflow = '';
    }

    function toggleMobileDropdown(id) {
      const dropdown = document.getElementById(id);
      const btn = dropdown.previousElementSibling;
      
      dropdown.classList.toggle('active');
      btn.classList.toggle('active');
    }

    mobileMenuToggle.addEventListener('click', toggleMobileMenu);
    mobileOverlay.addEventListener('click', closeMobileMenu);

    document.querySelectorAll('.mobile-sidebar-menu a').forEach(link => {
      link.addEventListener('click', closeMobileMenu);
    });

    window.addEventListener('resize', () => {
      if (window.innerWidth > 768) {
        closeMobileMenu();
      }
    });

    // Notification functionality
    let notifications = [];
    let unreadCount = 0;

    function loadSampleNotifications() {
      return [
        {
          id: 1,
          type: 'restock',
          title: 'Low Stock Alert',
          message: 'Glass Panels (5mm) are running low. Current quantity: 15 pieces',
          date: new Date('2023-10-15'),
          read: false
        },
        {
          id: 2,
          type: 'restock',
          title: 'Restock Needed',
          message: 'Aluminum Frames (Silver) need to be restocked. Only 8 units left.',
          date: new Date('2023-10-14'),
          read: false
        },
        {
          id: 3,
          type: 'other',
          title: 'New Site Assignment',
          message: 'You have been assigned to the Downtown Office project.',
          date: new Date('2023-10-13'),
          read: true
        },
        {
          id: 4,
          type: 'other',
          title: 'Approval Required',
          message: 'Purchase request #PR-2023-045 needs your approval.',
          date: new Date('2023-10-12'),
          read: false
        },
        {
          id: 5,
          type: 'restock',
          title: 'Critical Stock Level',
          message: 'Silicone Sealant is almost out of stock. Only 3 tubes remaining.',
          date: new Date('2023-10-10'),
          read: false
        }
      ];
    }

    function formatDate(date) {
      const now = new Date();
      const diffTime = Math.abs(now - date);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays === 1) return 'Yesterday';
      if (diffDays < 7) return `${diffDays} days ago`;
      
      return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
    }

    function updateNotificationBadge() {
      const badge = document.getElementById('notificationBadge');
      unreadCount = notifications.filter(n => !n.read).length;
      
      if (unreadCount > 0) {
        badge.style.display = 'block';
        badge.textContent = '';
      } else {
        badge.style.display = 'none';
      }
    }

    function renderNotifications(containerId, filterType = 'all') {
      const container = document.getElementById(containerId);
      let filteredNotifications = notifications;
      
      if (filterType === 'restock') {
        filteredNotifications = notifications.filter(n => n.type === 'restock');
      } else if (filterType === 'other') {
        filteredNotifications = notifications.filter(n => n.type === 'other');
      }
      
      if (filteredNotifications.length === 0) {
        container.innerHTML = '<div class="empty-notification">No notifications found</div>';
        return;
      }
      
      filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));
      
      container.innerHTML = filteredNotifications.map(notification => `
        <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
          <div class="notification-title">
            <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
            ${notification.title}
          </div>
          <div class="notification-message">${notification.message}</div>
          <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
        </div>
      `).join('');
      
      container.querySelectorAll('.notification-item').forEach(item => {
        item.addEventListener('click', function() {
          const notificationId = parseInt(this.getAttribute('data-id'));
          markAsRead(notificationId);
          this.classList.remove('unread');
        });
      });
    }

    function markAsRead(notificationId) {
      const notification = notifications.find(n => n.id === notificationId);
      if (notification && !notification.read) {
        notification.read = true;
        updateNotificationBadge();
      }
    }

    function markAllAsRead() {
      notifications.forEach(notification => {
        notification.read = true;
      });
      updateNotificationBadge();
      
      document.querySelectorAll('.notification-item').forEach(item => {
        item.classList.remove('unread');
      });
    }

    function setupTabs() {
      const tabButtons = document.querySelectorAll('.tab-button');
      const tabPanes = document.querySelectorAll('.tab-pane');
      
      tabButtons.forEach(button => {
        button.addEventListener('click', function() {
          const tabId = this.getAttribute('data-tab');
          
          tabButtons.forEach(btn => btn.classList.remove('active'));
          this.classList.add('active');
          
          tabPanes.forEach(pane => pane.classList.remove('active'));
          document.getElementById(`${tabId}-tab`).classList.add('active');
          
          if (tabId === 'all') {
            renderNotifications('allNotificationsList');
          } else if (tabId === 'restock') {
            renderNotifications('restockNotificationsList', 'restock');
          } else if (tabId === 'other') {
            renderNotifications('otherNotificationsList', 'other');
          }
        });
      });
    }

    function showNotificationModal() {
      const modal = document.getElementById('notificationModal');
      modal.style.display = 'flex';
      
      renderNotifications('allNotificationsList');
      renderNotifications('restockNotificationsList', 'restock');
      renderNotifications('otherNotificationsList', 'other');
    }

    function closeNotificationModal() {
      const modal = document.getElementById('notificationModal');
      modal.style.display = 'none';
    }

    document.addEventListener('DOMContentLoaded', function() {
      notifications = loadSampleNotifications();
      updateNotificationBadge();
      setupTabs();
      
      document.getElementById('notificationBell').addEventListener('click', showNotificationModal);
      document.getElementById('notificationCloseBtn').addEventListener('click', closeNotificationModal);
      document.getElementById('notificationDoneBtn').addEventListener('click', closeNotificationModal);
      document.getElementById('markAllReadBtn').addEventListener('click', markAllAsRead);
      
      document.getElementById('notificationModal').addEventListener('click', function(event) {
        if (event.target === this) {
          closeNotificationModal();
        }
      });
    });
  </script>
</body>
</html>