<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}

// Handle profile photo upload
if (isset($_POST['savePhoto']) && isset($_FILES['profilePhoto'])) {
    $file = $_FILES['profilePhoto'];
    if ($file['error'] == 0) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        $fileName = uniqid() . '_' . basename($file['name']);
        $uploadPath = $uploadDir . $fileName;
        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
            $_SESSION['profilePhoto'] = $uploadPath;
        }
    }
}

// Handle reset to default photo
if (isset($_POST['resetPhoto'])) {
    // Remove the old profile photo file if it exists
    if (isset($_SESSION['profilePhoto']) && $_SESSION['profilePhoto'] !== 'media/user.png') {
        if (file_exists($_SESSION['profilePhoto'])) {
            unlink($_SESSION['profilePhoto']);
        }
    }
    // Reset to default
    unset($_SESSION['profilePhoto']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminProf.css?v=1.7">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
       <span>Art Glass & Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>

<!-- Profile Container -->
<div class="container">
        <div class="profile-card">
            <div class="profile-header">
                <form method="post" enctype="multipart/form-data">
                    <div class="avatar-container">
                        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile Avatar" class="avatar" id="currentAvatar">
                        <div class="avatar-overlay">
                            <span>Change Photo</span>
                        </div>
                    </div>
                    <input type="file" accept="image/*" id="profilePhotoInput" name="profilePhoto" style="display:none;">
                    <div class="photo-buttons">
                        <button type="submit" name="savePhoto" class="btn btn-primary btn-sm" style="margin-top: 10px;">Save Photo</button>
                        <?php if (isset($_SESSION['profilePhoto'])): ?>
                        <button type="submit" name="resetPhoto" class="btn btn-secondary btn-sm" style="margin-top: 10px;" onclick="return confirm('Are you sure you want to reset to default photo?')">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="1,4 1,10 7,10"></polyline>
                                <path d="M3.51,15a9,9,0,0,0,2.13,2.14l1.47,1.47a8,8,0,0,0,11.32,0,9,9,0,0,0,2.13-2.14"></path>
                                <polyline points="23,20 23,14 17,14"></polyline>
                                <path d="M20.49,9a9,9,0,0,0-2.13-2.14L16.89,5.39a8,8,0,0,0-11.32,0A9,9,0,0,0,3.44,7.53"></path>
                            </svg>
                            Reset to Default
                        </button>
                        <?php endif; ?>
                    </div>
                </form>
                <div class="profile-info">
                    <h2 id="profileName"><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Unknown'; ?></h2>
                    <div class="role" id="profileRole"><?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Unknown'; ?></div>
                    <div class="email" id="profileEmail"><?php echo isset($_SESSION['Email']) ? htmlspecialchars($_SESSION['Email']) : 'Unknown'; ?></div>
                </div>
            </div>

            <div class="info-grid">
                <div class="info-item">
                    <label>Full Name</label>
                    <div class="value" id="displayName"><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Unknown'; ?></div>
                </div>
                <div class="info-item">
                    <label>Role</label>
                    <div class="value" id="displayRole"><?php echo isset($_SESSION['role']) ? htmlspecialchars($_SESSION['role']) : 'Unknown'; ?></div>
                </div>
                <div class="info-item">
                    <label>Email Address</label>
                    <div class="value" id="displayEmail"><?php echo isset($_SESSION['Email']) ? htmlspecialchars($_SESSION['Email']) : 'Unknown'; ?></div>
                </div>
                <div class="info-item">
                    <label>Password</label>
                    <div class="password-field">
                        <input type="password" id="passwordField" value="********" readonly>
                        <button class="toggle-password" id="togglePassword">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>

            <div class="actions">
                <button class="btn btn-primary" id="createAccountBtn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M22 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    Create New Account
                </button>
                <button class="btn btn-secondary" id="changePasswordBtn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <circle cx="12" cy="16" r="1"></circle>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                    Change Password
                </button>
                <button class="btn btn-danger" id="deleteAccountBtn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3,6 5,6 21,6"></polyline>
                        <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
                        <line x1="10" y1="11" x2="10" y2="17"></line>
                        <line x1="14" y1="11" x2="14" y2="17"></line>
                    </svg>
                    Manage Accounts
                </button>
            </div>
        </div>
    </div>

    <!-- Create Account Modal -->
    <div id="createAccountModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Create New Account</h2>
                <button class="close-btn" id="closeCreateModal">&times;</button>
            </div>

            <div class="modal-avatar">
                <img src="https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=100&h=100&fit=crop&crop=face" alt="Profile" id="modalProfileImage">
                <input type="file" accept="image/*" id="profileImageInput" style="display:none;">
                <p>Click image to change photo</p>
            </div>

            <form id="createAccountForm">
                <div class="form-group">
                    <label for="newName">Full Name</label>
                    <input type="text" id="newName" name="Name" required>
                </div>

                <div class="form-group">
                    <label for="newEmail">Email Address</label>
                    <input type="email" id="newEmail" name="Email" required>
                </div>

                <div class="form-group">
                    <label>Select Role</label>
                    <div class="role-selector">
                        <div class="role-option">
                            <input type="radio" name="role" value="Admin" id="adminRole">
                            <label for="adminRole">Admin</label>
                        </div>
                        <div class="role-option">
                            <input type="radio" name="role" value="Inventory Mngr." id="inventoryRole">
                            <label for="inventoryRole">Inventory</label>
                        </div>
                        <div class="role-option">
                            <input type="radio" name="role" value="Project Mngr." id="projectRole">
                            <label for="projectRole">Project</label>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="newPassword">Password</label>
                    <input type="password" id="newPassword" name="password" required>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Create Account
                </button>
            </form>
        </div>
    </div>

    <!-- Delete Account Modal -->
    <div id="deleteAccountModal" class="modal">
        <div class="modal-content delete-modal-content">
            <div class="modal-header">
                <h2>Manage Accounts</h2>
                <button class="close-btn" id="closeDeleteModal">&times;</button>
            </div>

            <table class="delete-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th style="text-align: center;">Select</th>
                    </tr>
                </thead>
                <tbody id="deleteAccountList">
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td style="text-align: center;"><input type="checkbox" class="delete-checkbox" data-id="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td style="text-align: center;"><input type="checkbox" class="delete-checkbox" data-id="3"></td>
                    </tr>
                </tbody>
            </table>

            <div style="text-align: center;">
                <button id="confirmDeleteBtn" class="btn btn-danger">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="3,6 5,6 21,6"></polyline>
                        <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a2,2,0,0,1,2-2h4a2,2,0,0,1,2,2V6"></path>
                    </svg>
                    Delete Selected Accounts
                </button>
            </div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="modal success-modal">
        <div class="modal-content">
            <div class="success-icon">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <polyline points="20,6 9,17 4,12"></polyline>
                </svg>
            </div>
            <h2>Success!</h2>
            <p>Account has been created successfully.</p>
            <button class="btn btn-primary" id="successDoneBtn">Done</button>
        </div>
    </div>

    <!-- Change Password Modal -->
    <div id="changePasswordModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Change Password</h2>
                <button class="close-btn" id="closeChangePasswordModal">&times;</button>
            </div>

            <form id="changePasswordForm">
                <div class="form-group">
                    <label for="currentPassword">Current Password</label>
                    <div class="password-input-container">
                        <input type="password" id="currentPassword" name="currentPassword" required>
                        <button type="button" class="toggle-password-btn" data-target="currentPassword">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="newPasswordModal">New Password</label>
                    <div class="password-input-container">
                        <input type="password" id="newPasswordModal" name="newPasswordModal" required>
                        <button type="button" class="toggle-password-btn" data-target="newPasswordModal">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirmPassword">Confirm New Password</label>
                    <div class="password-input-container">
                        <input type="password" id="confirmPassword" name="confirmPassword" required>
                        <button type="button" class="toggle-password-btn" data-target="confirmPassword">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="password-requirements">
                    <h4>Password Requirements:</h4>
                    <ul>
                        <li id="length">At least 8 characters</li>
                        <li id="uppercase">One uppercase letter</li>
                        <li id="lowercase">One lowercase letter</li>
                        <li id="number">One number</li>
                        <li id="special">One special character</li>
                    </ul>
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    Change Password
                </button>
            </form>
        </div>
    </div>

    <!-- Password Change Success Modal -->
    <div id="passwordSuccessModal" class="modal success-modal">
        <div class="modal-content">
            <div class="success-icon">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                    <polyline points="20,6 9,17 4,12"></polyline>
                </svg>
            </div>
            <h2>Success!</h2>
            <p>Your password has been changed successfully.</p>
            <button class="btn btn-primary" id="passwordSuccessDoneBtn">Done</button>
        </div>
    </div>

    <!-- Updated Notification Modal -->
    <div id="notificationModal" class="modal" style="display:none;">
      <div class="modal-content">
        <div class="modal-header">
          <h2>Notifications</h2>
          <button id="notificationCloseBtn" class="close-button">×</button>
        </div>
        <div class="modal-body">
          <div class="notification-tabs">
            <button class="tab-button active" data-tab="all">All</button>
            <button class="tab-button" data-tab="restock">Restock Warnings</button>
            <button class="tab-button" data-tab="other">Other Notifications</button>
          </div>
          <div class="notification-content">
            <div id="all-tab" class="tab-pane active">
              <div id="allNotificationsList" class="notification-list"></div>
            </div>
            <div id="restock-tab" class="tab-pane">
              <div id="restockNotificationsList" class="notification-list"></div>
            </div>
            <div id="other-tab" class="tab-pane">
              <div id="otherNotificationsList" class="notification-list"></div>
            </div>
          </div>
          <div class="modal-actions">
            <button id="markAllReadBtn">Mark All as Read</button>
            <button id="notificationDoneBtn">Done</button>
          </div>
        </div>
      </div>
    </div>

    <script>
        // Modal functionality
        const createModal = document.getElementById('createAccountModal');
        const deleteModal = document.getElementById('deleteAccountModal');
        const successModal = document.getElementById('successModal');
        const changePasswordModal = document.getElementById('changePasswordModal');
        const passwordSuccessModal = document.getElementById('passwordSuccessModal');

        // Open create modal
        document.getElementById('createAccountBtn').addEventListener('click', () => {
            createModal.style.display = 'flex';
        });

        // Open delete modal
        document.getElementById('deleteAccountBtn').addEventListener('click', () => {
            deleteModal.style.display = 'flex';
        });

        // Open change password modal
        document.getElementById('changePasswordBtn').addEventListener('click', () => {
            changePasswordModal.style.display = 'flex';
        });

        // Close modals
        document.getElementById('closeCreateModal').addEventListener('click', () => {
            createModal.style.display = 'none';
        });

        document.getElementById('closeDeleteModal').addEventListener('click', () => {
            deleteModal.style.display = 'none';
        });

        document.getElementById('closeChangePasswordModal').addEventListener('click', () => {
            changePasswordModal.style.display = 'none';
            document.getElementById('changePasswordForm').reset();
            resetPasswordRequirements();
        });

        document.getElementById('passwordSuccessDoneBtn').addEventListener('click', () => {
            passwordSuccessModal.style.display = 'none';
        });

        // Close on background click
        [createModal, deleteModal, successModal, changePasswordModal, passwordSuccessModal].forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.style.display = 'none';
                    if (modal === changePasswordModal) {
                        document.getElementById('changePasswordForm').reset();
                        resetPasswordRequirements();
                    }
                }
            });
        });

        // Profile image upload
        document.getElementById('modalProfileImage').addEventListener('click', () => {
            document.getElementById('profileImageInput').click();
        });

        document.getElementById('profileImageInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    document.getElementById('modalProfileImage').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });

        // Password toggle
        document.getElementById('togglePassword').addEventListener('click', () => {
            const passwordField = document.getElementById('passwordField');
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);
        });

        // Password toggle functionality for change password modal
        document.querySelectorAll('.toggle-password-btn').forEach(button => {
            button.addEventListener('click', () => {
                const targetId = button.getAttribute('data-target');
                const passwordField = document.getElementById(targetId);
                const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordField.setAttribute('type', type);
                
                // Update icon
                if (type === 'text') {
                    button.innerHTML = `
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path>
                            <line x1="1" y1="1" x2="23" y2="23"></line>
                        </svg>
                    `;
                } else {
                    button.innerHTML = `
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                            <circle cx="12" cy="12" r="3"></circle>
                        </svg>
                    `;
                }
            });
        });

        // Password requirements validation
        function validatePassword(password) {
            const requirements = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /\d/.test(password),
                special: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)
            };
            
            return requirements;
        }

        function updatePasswordRequirements(requirements) {
            Object.keys(requirements).forEach(key => {
                const element = document.getElementById(key);
                if (requirements[key]) {
                    element.style.color = '#10b981';
                    element.innerHTML = '✓ ' + element.textContent.replace('✓ ', '');
                } else {
                    element.style.color = '#ef4444';
                    element.innerHTML = element.textContent.replace('✓ ', '');
                }
            });
        }

        function resetPasswordRequirements() {
            const requirements = ['length', 'uppercase', 'lowercase', 'number', 'special'];
            requirements.forEach(req => {
                const element = document.getElementById(req);
                element.style.color = '#64748b';
                element.innerHTML = element.textContent.replace('✓ ', '');
            });
        }

        // Real-time password validation
        document.getElementById('newPasswordModal').addEventListener('input', (e) => {
            const password = e.target.value;
            const requirements = validatePassword(password);
            updatePasswordRequirements(requirements);
        });

        // Form submissions
        document.getElementById('createAccountForm').addEventListener('submit', (e) => {
            e.preventDefault();
            createModal.style.display = 'none';
            successModal.style.display = 'flex';
        });

        // Change password form submission
        document.getElementById('changePasswordForm').addEventListener('submit', (e) => {
            e.preventDefault();
            
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPasswordModal').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Validate current password
            if (currentPassword.trim() === '') {
                alert('Please enter your current password.');
                return;
            }
            
            // Validate new password requirements
            const requirements = validatePassword(newPassword);
            const allRequirementsMet = Object.values(requirements).every(req => req === true);
            
            if (!allRequirementsMet) {
                alert('Please ensure your new password meets all requirements.');
                return;
            }
            
            // Check if new passwords match
            if (newPassword !== confirmPassword) {
                alert('New passwords do not match. Please try again.');
                return;
            }
            
            // Check if new password is different from current password
            if (currentPassword === newPassword) {
                alert('New password must be different from your current password.');
                return;
            }
            
            // Simulate API call
            setTimeout(() => {
                changePasswordModal.style.display = 'none';
                passwordSuccessModal.style.display = 'flex';
                document.getElementById('changePasswordForm').reset();
                resetPasswordRequirements();
            }, 500);
        });

        // Success modal done button
        document.getElementById('successDoneBtn').addEventListener('click', () => {
            successModal.style.display = 'none';
        });

        // Delete confirmation
        document.getElementById('confirmDeleteBtn').addEventListener('click', () => {
            const checkedBoxes = document.querySelectorAll('.delete-checkbox:checked');
            if (checkedBoxes.length === 0) {
                alert('Please select at least one account to delete.');
                return;
            }

            // Simulate deletion
            checkedBoxes.forEach(checkbox => {
                checkbox.closest('tr').remove();
            });

            deleteModal.style.display = 'none';
        });

        // Profile photo change functionality
        document.querySelector('.avatar-container').addEventListener('click', () => {
            document.getElementById('profilePhotoInput').click();
        });

        document.getElementById('profilePhotoInput').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    document.getElementById('currentAvatar').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });

        // Notification functionality
        let notifications = [];
        let unreadCount = 0;

        // Sample notification data (in a real app, this would come from a server)
        function loadSampleNotifications() {
          return [
            {
              id: 1,
              type: 'restock',
              title: 'Low Stock Alert',
              message: 'Glass Panels (5mm) are running low. Current quantity: 15 pieces',
              date: new Date('2023-10-15'),
              read: false
            },
            {
              id: 2,
              type: 'restock',
              title: 'Restock Needed',
              message: 'Aluminum Frames (Silver) need to be restocked. Only 8 units left.',
              date: new Date('2023-10-14'),
              read: false
            },
            {
              id: 3,
              type: 'other',
              title: 'New Site Assignment',
              message: 'You have been assigned to the Downtown Office project.',
              date: new Date('2023-10-13'),
              read: true
            },
            {
              id: 4,
              type: 'other',
              title: 'Approval Required',
              message: 'Purchase request #PR-2023-045 needs your approval.',
              date: new Date('2023-10-12'),
              read: false
            },
            {
              id: 5,
              type: 'restock',
              title: 'Critical Stock Level',
              message: 'Silicone Sealant is almost out of stock. Only 3 tubes remaining.',
              date: new Date('2023-10-10'),
              read: false
            }
          ];
        }

        // Format date for display
        function formatDate(date) {
          const now = new Date();
          const diffTime = Math.abs(now - date);
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          
          if (diffDays === 1) return 'Yesterday';
          if (diffDays < 7) return `${diffDays} days ago`;
          
          return date.toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
          });
        }

        // Update notification badge
        function updateNotificationBadge() {
          const badge = document.getElementById('notificationBadge');
          unreadCount = notifications.filter(n => !n.read).length;
          
          if (unreadCount > 0) {
            badge.style.display = 'block';
            badge.textContent = '';  // Empty to show just the red circle without number
          } else {
            badge.style.display = 'none';
          }
        }

        // Render notifications in a specific tab
        function renderNotifications(containerId, filterType = 'all') {
          const container = document.getElementById(containerId);
          let filteredNotifications = notifications;
          
          if (filterType === 'restock') {
            filteredNotifications = notifications.filter(n => n.type === 'restock');
          } else if (filterType === 'other') {
            filteredNotifications = notifications.filter(n => n.type === 'other');
          }
          
          if (filteredNotifications.length === 0) {
            container.innerHTML = '<div class="empty-notification">No notifications found</div>';
            return;
          }
          
          // Sort by date (newest first)
          filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));
          
          container.innerHTML = filteredNotifications.map(notification => `
            <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
              <div class="notification-title">
                <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
                ${notification.title}
              </div>
              <div class="notification-message">${notification.message}</div>
              <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
            </div>
          `).join('');
          
          // Add click event to mark as read
          container.querySelectorAll('.notification-item').forEach(item => {
            item.addEventListener('click', function() {
              const notificationId = parseInt(this.getAttribute('data-id'));
              markAsRead(notificationId);
              this.classList.remove('unread');
            });
          });
        }

        // Mark notification as read
        function markAsRead(notificationId) {
          const notification = notifications.find(n => n.id === notificationId);
          if (notification && !notification.read) {
            notification.read = true;
            updateNotificationBadge();
          }
        }

        // Mark all notifications as read
        function markAllAsRead() {
          notifications.forEach(notification => {
            notification.read = true;
          });
          updateNotificationBadge();
          
          // Update UI
          document.querySelectorAll('.notification-item').forEach(item => {
            item.classList.remove('unread');
          });
        }

        // Tab switching functionality
        function setupTabs() {
          const tabButtons = document.querySelectorAll('.tab-button');
          const tabPanes = document.querySelectorAll('.tab-pane');
          
          tabButtons.forEach(button => {
            button.addEventListener('click', function() {
              const tabId = this.getAttribute('data-tab');
              
              // Update active tab button
              tabButtons.forEach(btn => btn.classList.remove('active'));
              this.classList.add('active');
              
              // Show corresponding tab pane
              tabPanes.forEach(pane => pane.classList.remove('active'));
              document.getElementById(`${tabId}-tab`).classList.add('active');
              
              // Render notifications for this tab
              if (tabId === 'all') {
                renderNotifications('allNotificationsList');
              } else if (tabId === 'restock') {
                renderNotifications('restockNotificationsList', 'restock');
              } else if (tabId === 'other') {
                renderNotifications('otherNotificationsList', 'other');
              }
            });
          });
        }

        // Show notification modal
        function showNotificationModal() {
          const modal = document.getElementById('notificationModal');
          modal.style.display = 'flex';
          
          // Render all notifications initially
          renderNotifications('allNotificationsList');
          renderNotifications('restockNotificationsList', 'restock');
          renderNotifications('otherNotificationsList', 'other');
        }

        // Close notification modal
        function closeNotificationModal() {
          const modal = document.getElementById('notificationModal');
          modal.style.display = 'none';
        }

        // Initialize notification system
        document.addEventListener('DOMContentLoaded', function() {
          // Load notifications
          notifications = loadSampleNotifications();
          updateNotificationBadge();
          setupTabs();
          
          // Notification bell click event
          document.getElementById('notificationBell').addEventListener('click', showNotificationModal);
          
          // Modal close events
          document.getElementById('notificationCloseBtn').addEventListener('click', closeNotificationModal);
          document.getElementById('notificationDoneBtn').addEventListener('click', closeNotificationModal);
          
          // Mark all as read button
          document.getElementById('markAllReadBtn').addEventListener('click', markAllAsRead);
          
          // Close modal when clicking outside
          document.getElementById('notificationModal').addEventListener('click', function(event) {
            if (event.target === this) {
              closeNotificationModal();
            }
          });

          // Check for low stock on page load to update badge
          fetch('get_low_stock.php')
            .then(response => response.json())
            .then(data => {
              if (data.length > 0) {
                // Add low stock notifications if not already present
                data.forEach(item => {
                  if (!notifications.some(n => n.message.includes(item.MaterialsName))) {
                    notifications.push({
                      id: Date.now() + Math.random(),
                      type: 'restock',
                      title: 'Low Stock Alert',
                      message: `${item.MaterialsName} - Quantity: ${item.Quantity}`,
                      date: new Date(),
                      read: false
                    });
                  }
                });
                updateNotificationBadge();
              }
            })
            .catch(error => console.error('Error fetching low stock:', error));
        });

        // Close notification modal if clicking outside
        document.getElementById('notificationModal').addEventListener('click', function(event) {
          if (event.target === this) {
            closeNotificationModal();
          }
        });

    </script>

</body>
</html>