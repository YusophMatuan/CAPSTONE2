<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$site_id = intval($_GET['site_id'] ?? 0);

// Fetch assigned tools for this site
$stmt = $conn->prepare("SELECT t.id, t.ToolsName, st.quantity 
                        FROM site_tools st
                        JOIN tools t ON st.tool_id = t.id
                        WHERE st.site_id = ?");
$stmt->bind_param("i", $site_id);
$stmt->execute();
$result = $stmt->get_result();

while($row = $result->fetch_assoc()):
?>
<tr>
  <td>
    <input type="checkbox" class="tool-checkbox" data-id="<?= $row['id'] ?>" checked>
  </td>
  <td><?= htmlspecialchars($row['ToolsName']) ?></td>
  <td>
    <input type="number" class="tool-qty" data-id="<?= $row['id'] ?>" min="1" value="<?= $row['quantity'] ?>">
  </td>
</tr>
<?php endwhile;

$stmt->close();
$conn->close();
?>