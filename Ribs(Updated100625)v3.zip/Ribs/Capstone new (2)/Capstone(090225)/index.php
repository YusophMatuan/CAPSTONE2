<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Welcome Back</title>
    <link rel="stylesheet" href="style.css?v=1.1">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
   <div class="login-container">
        <div class="login-card">
            <!-- Logo Section -->
            <div class="logo-container">
                <img src="media/MainLogo.png" alt="Company Logo" class="logo">
            </div>
            
            <div class="login-header">
                <h1>Welcome Back</h1>
                <p>Sign in to your account to continue</p>
            </div>
            
            <form class="login-form" action="login.php" method="POST">
                <div class="form-group">
                    <div class="input-wrapper">
                        <input type="email" name="email" id="email" required autocomplete="email">
                        <label for="email">Email Address</label>
                        <div class="input-border"></div>
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="input-wrapper">
                        <input type="password" name="password" id="password" required autocomplete="current-password">
                        <label for="password">Password</label>
                        <div class="input-border"></div>
                    </div>
                </div>
                
                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="remember" id="remember">
                        <span class="checkmark"></span>
                        <span class="remember-text">Remember me</span>
                    </label>
                    <a href="#" class="forgot-password" onclick="showForgotPassword()">Forgot Password?</a>
                </div>
                
                <button type="submit" class="login-btn">
                    <span>Sign In</span>
                </button>
            </form>
            
            <!-- Forgot Password Form -->
            <form class="forgot-password-form" id="forgotPasswordForm" action="forgot_password.php" method="POST" style="display: none;">
                <div class="form-group">
                    <div class="input-wrapper">
                        <input type="email" name="reset_email" id="reset_email" required autocomplete="email">
                        <label for="reset_email">Email Address</label>
                        <div class="input-border"></div>
                    </div>
                </div>
                
                <button type="submit" class="reset-btn">
                    <span>Send Reset Link</span>
                </button>
                
                <button type="button" class="back-btn" onclick="showLoginForm()">
                    <span>← Back to Login</span>
                </button>
            </form>
        </div>
    </div>

    <script>
        function showForgotPassword() {
            document.querySelector('.login-form').style.display = 'none';
            document.querySelector('.login-header h1').textContent = 'Reset Password';
            document.querySelector('.login-header p').textContent = 'Enter your email to receive a reset link';
            document.getElementById('forgotPasswordForm').style.display = 'flex';
        }
        
        function showLoginForm() {
            document.querySelector('.login-form').style.display = 'flex';
            document.querySelector('.login-header h1').textContent = 'Welcome Back';
            document.querySelector('.login-header p').textContent = 'Sign in to your account to continue';
            document.getElementById('forgotPasswordForm').style.display = 'none';
        }
    </script>
        </div>
    </div>
</body>
</html>