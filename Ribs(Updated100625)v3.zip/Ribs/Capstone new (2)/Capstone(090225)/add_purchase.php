<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product = trim($_POST['product'] ?? '');
    $supplier = trim($_POST['supplier'] ?? '');
    $quantity = intval($_POST['quantity'] ?? 0);
    $date = $_POST['date'] ?? '';

    $stmt = $conn->prepare("INSERT INTO purchase (Product, Supplier, Quantity, Date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $product, $supplier, $quantity, $date);

    if ($stmt->execute()) {
        echo "success";
    } else {
        echo "error: " . $stmt->error;
    }
    $stmt->close();
}
$conn->close();
?>