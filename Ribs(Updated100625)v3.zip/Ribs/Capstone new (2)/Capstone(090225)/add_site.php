<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";

$conn = new mysqli($servername, $username, $passwordDB, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siteName = isset($_POST['siteName']) ? trim($_POST['siteName']) : '';
    $startingDate = isset($_POST['startingDate']) ? $_POST['startingDate'] : '';
    $finishedDate = isset($_POST['finishedDate']) ? $_POST['finishedDate'] : null;
    $location = isset($_POST['location']) ? trim($_POST['location']) : '';
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';
    $status = "Pending";

    // Start transaction
    $conn->begin_transaction();

    try {
        // Insert into sites table
        $stmt = $conn->prepare("INSERT INTO sites (SiteName, StartingDate, FinishedDate, Location, Notes, Status) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $siteName, $startingDate, $finishedDate, $location, $notes, $status);
        
        if (!$stmt->execute()) {
            throw new Exception("Error inserting site: " . $stmt->error);
        }
        
        $site_id = $conn->insert_id;

        // Insert materials and deduct from inventory
        if (!empty($_POST['materials'])) {
            foreach ($_POST['materials'] as $matId) {
                $matId = intval($matId);
                $qtyField = 'material_qty_' . $matId;
                $qty = isset($_POST[$qtyField]) ? intval($_POST[$qtyField]) : 0;
                
                if ($qty > 0) {
                    // Check if enough quantity available
                    $checkStmt = $conn->prepare("SELECT Quantity FROM materials WHERE id = ?");
                    $checkStmt->bind_param("i", $matId);
                    $checkStmt->execute();
                    $result = $checkStmt->get_result();
                    $row = $result->fetch_assoc();
                    
                    if ($row['Quantity'] < $qty) {
                        throw new Exception("Not enough materials available");
                    }
                    
                    // Deduct from materials table
                    $updateStmt = $conn->prepare("UPDATE materials SET Quantity = Quantity - ? WHERE id = ?");
                    $updateStmt->bind_param("ii", $qty, $matId);
                    $updateStmt->execute();
                    
                    // Insert into site_materials
                    $insertStmt = $conn->prepare("INSERT INTO site_materials (site_id, material_id, quantity) VALUES (?, ?, ?)");
                    $insertStmt->bind_param("iii", $site_id, $matId, $qty);
                    $insertStmt->execute();
                }
            }
        }

        // Insert tools and deduct from inventory
        if (!empty($_POST['tools'])) {
            foreach ($_POST['tools'] as $toolId) {
                $toolId = intval($toolId);
                $qtyField = 'tool_qty_' . $toolId;
                $qty = isset($_POST[$qtyField]) ? intval($_POST[$qtyField]) : 0;
                
                if ($qty > 0) {
                    // Check if enough quantity available
                    $checkStmt = $conn->prepare("SELECT Quantity FROM tools WHERE id = ?");
                    $checkStmt->bind_param("i", $toolId);
                    $checkStmt->execute();
                    $result = $checkStmt->get_result();
                    $row = $result->fetch_assoc();
                    
                    if ($row['Quantity'] < $qty) {
                        throw new Exception("Not enough tools available");
                    }
                    
                    // Deduct from tools table
                    $updateStmt = $conn->prepare("UPDATE tools SET Quantity = Quantity - ? WHERE id = ?");
                    $updateStmt->bind_param("ii", $qty, $toolId);
                    $updateStmt->execute();
                    
                    // Insert into site_tools
                    $insertStmt = $conn->prepare("INSERT INTO site_tools (site_id, tool_id, quantity) VALUES (?, ?, ?)");
                    $insertStmt->bind_param("iii", $site_id, $toolId, $qty);
                    $insertStmt->execute();
                }
            }
        }

        // Commit transaction
        $conn->commit();
        echo "success";
        
    } catch (Exception $e) {
        // Rollback on error
        $conn->rollback();
        echo "error: " . $e->getMessage();
    }

    $conn->close();
}
?>