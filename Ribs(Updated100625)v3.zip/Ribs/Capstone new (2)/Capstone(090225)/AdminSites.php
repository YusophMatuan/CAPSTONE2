<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminSites.css?v=3.1">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
       <span>Art Glass & Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
      <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
    <div class="navbar-notification">
      <div class="notification-icon">
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>

  <div class="sites-section">
    <div class="sites-header">
      <h1>Project Sites</h1>
      <div class="header-actions">
        <input type="text" placeholder="Search sites..." class="search-input">
        <button id="add-btn" class="add-sites">
          <span class="btn-icon">+</span> Add Site
        </button>
        <button id="print-btn" class="export-pdf">
          <span class="btn-icon">⎙</span> Print
        </button>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th>Site Name</th>
            <th>Location</th>
            <th>Starting Date</th>
            <th>Finished Date</th>
            <th>Status</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
<?php
$servername = "localhost";
$username = "root";
$passwordDB = "";
$dbname = "capstone";
$conn = new mysqli($servername, $username, $passwordDB, $dbname);
$sql = "SELECT id, SiteName, Location, StartingDate, FinishedDate, Status FROM sites";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0):
    while($row = $result->fetch_assoc()):
        $statusClass = strtolower($row['Status']);
?>
    <tr data-site-id="<?php echo $row['id']; ?>">
      <td><?php echo htmlspecialchars($row['SiteName']); ?></td>
      <td><?php echo htmlspecialchars($row['Location']); ?></td>
      <td><?php echo htmlspecialchars($row['StartingDate']); ?></td>
      <td><?php echo htmlspecialchars($row['FinishedDate']); ?></td>
      <td><span class="status-badge <?php echo $statusClass; ?>"><?php echo htmlspecialchars($row['Status']); ?></span></td>
      <td><button class="action-btn open-btn">View Details</button></td>
    </tr>
<?php
    endwhile;
else:
?>
    <tr>
      <td colspan="6" class="no-data">No sites found.</td>
    </tr>
<?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Site Details Modal -->
  <div class="modal-overlay" id="modalOverlay">
    <div class="modal">
      <div class="modal-header">
        <h2 id="modalTitle">Site Details</h2>
        <button class="close-btn" id="modalCloseBtn">×</button>
      </div>
      
      <div class="modal-body">
        <div class="info-grid">
          <div class="info-item">
            <label>Starting Date:</label>
            <span id="modalStartingDate"></span>
          </div>
          <div class="info-item">
            <label>Finished Date:</label>
            <span id="modalFinishedDate"></span>
          </div>
          <div class="info-item full-width">
            <label>Location:</label>
            <span id="modalLocation"></span>
          </div>
        </div>

        <div class="note-section">
          <label for="modalNote">Notes:</label>
          <textarea id="modalNote" placeholder="Enter notes about this site..."></textarea>
        </div>

        <div class="materials-tools-grid">
          <div class="section-card">
            <h3>Materials</h3>
            <div class="table-wrapper">
              <table id="modalMaterials">
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>Material</th>
                    <th>Qty</th>
                  </tr>
                </thead>
                <tbody></tbody>
              </table>
            </div>
          </div>

          <div class="section-card">
            <h3>Tools</h3>
            <div class="table-wrapper">
              <table id="modalTools">
                <thead>
                  <tr>
                    <th>Select</th>
                    <th>Tool</th>
                    <th>Qty</th>
                  </tr>
                </thead>
                <tbody></tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="status-section">
          <label>Status:</label>
          <div class="status-radio-group">
            <label class="radio-label">
              <input type="radio" name="siteStatus" value="Pending" checked>
              <span>Pending</span>
            </label>
            <label class="radio-label">
              <input type="radio" name="siteStatus" value="Ongoing">
              <span>Ongoing</span>
            </label>
            <label class="radio-label">
              <input type="radio" name="siteStatus" value="Finished">
              <span>Finished</span>
            </label>
          </div>
        </div>
      </div>

      <div class="modal-footer">
        <button class="btn-secondary" id="modalCancelBtn">Cancel</button>
        <button class="btn-primary" id="modalDoneBtn">Save Changes</button>
      </div>
    </div>
  </div>

  <!-- Add Site Modal -->
  <div id="siteModal" class="modal-overlay">
    <div class="modal">
      <div class="modal-header">
        <h2>Add New Site</h2>
        <button class="close-btn" id="closeBtn">×</button>
      </div>
      
      <form id="siteForm">
        <div class="modal-body">
          <div class="form-group">
            <label for="siteName">Site Name:</label>
            <input type="text" id="siteName" name="siteName" required>
          </div>

          <div class="form-row">
            <div class="form-group">
              <label for="startingDate">Starting Date:</label>
              <input type="date" id="startingDate" name="startingDate" required>
            </div>
            <div class="form-group">
              <label for="finishedDate">Finished Date:</label>
              <input type="date" id="finishedDate" name="finishedDate">
            </div>
          </div>

          <div class="form-group">
            <label for="location">Location:</label>
            <input type="text" id="location" name="location" required>
          </div>

          <div class="form-group">
            <label for="notes">Notes:</label>
            <textarea id="notes" name="notes" rows="3"></textarea>
          </div>

          <div class="materials-tools-grid">
            <div class="section-card">
              <h3>Select Materials</h3>
              <div class="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Select</th>
                      <th>Material</th>
                      <th>Available</th>
                      <th>Qty</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $matConn = new mysqli($servername, $username, $passwordDB, $dbname);
                    $matResult = $matConn->query("SELECT id, MaterialsName, Quantity FROM materials");
                    if ($matResult && $matResult->num_rows > 0):
                      while($mat = $matResult->fetch_assoc()):
                    ?>
                    <tr>
                      <td><input type="checkbox" name="materials[]" value="<?php echo $mat['id']; ?>" class="material-checkbox"></td>
                      <td><?php echo htmlspecialchars($mat['MaterialsName']); ?></td>
                      <td><?php echo $mat['Quantity']; ?></td>
                      <td>
                        <input type="number" name="material_qty_<?php echo $mat['id']; ?>" min="1" max="<?php echo $mat['Quantity']; ?>" disabled>
                      </td>
                    </tr>
                    <?php endwhile; endif; ?>
                  </tbody>
                </table>
              </div>
            </div>

            <div class="section-card">
              <h3>Select Tools</h3>
              <div class="table-wrapper">
                <table>
                  <thead>
                    <tr>
                      <th>Select</th>
                      <th>Tool</th>
                      <th>Available</th>
                      <th>Qty</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $toolConn = new mysqli($servername, $username, $passwordDB, $dbname);
                    $toolResult = $toolConn->query("SELECT id, ToolsName, Quantity FROM tools");
                    if ($toolResult && $toolResult->num_rows > 0):
                      while($tool = $toolResult->fetch_assoc()):
                    ?>
                    <tr>
                      <td><input type="checkbox" name="tools[]" value="<?php echo $tool['id']; ?>" class="tool-checkbox"></td>
                      <td><?php echo htmlspecialchars($tool['ToolsName']); ?></td>
                      <td><?php echo $tool['Quantity']; ?></td>
                      <td>
                        <input type="number" name="tool_qty_<?php echo $tool['id']; ?>" min="1" max="<?php echo $tool['Quantity']; ?>" disabled>
                      </td>
                    </tr>
                    <?php endwhile; endif; ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn-secondary" onclick="document.getElementById('siteModal').style.display='none'">Cancel</button>
          <button type="submit" class="btn-primary">Add Site</button>
        </div>
      </form>
    </div>
  </div>

  <!-- Success Modal -->
  <div id="successModal" class="modal-overlay">
    <div class="success-modal">
      <div class="success-icon">✓</div>
      <h3>Success!</h3>
      <p>Site has been updated successfully.</p>
      <button class="btn-primary" id="successDoneBtn">Done</button>
    </div>
  </div>

  <!-- Notification Modal - FIXED STRUCTURE -->
  <div id="notificationModal" class="modal-overlay" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Modal Elements - Site Details
    const modalOverlay = document.getElementById('modalOverlay');
    const modalCloseBtn = document.getElementById('modalCloseBtn');
    const modalCancelBtn = document.getElementById('modalCancelBtn');
    const modalDoneBtn = document.getElementById('modalDoneBtn');
    const modalTitle = document.getElementById('modalTitle');
    const modalStartingDate = document.getElementById('modalStartingDate');
    const modalFinishedDate = document.getElementById('modalFinishedDate');
    const modalLocation = document.getElementById('modalLocation');
    const modalNote = document.getElementById('modalNote');
    const modalMaterials = document.getElementById('modalMaterials');
    const modalTools = document.getElementById('modalTools');

    // Modal Elements - Add Site
    const siteModal = document.getElementById('siteModal');
    const addBtn = document.getElementById('add-btn');
    const closeBtn = document.getElementById('closeBtn');
    const siteForm = document.getElementById('siteForm');

    // Success Modal
    const successModal = document.getElementById('successModal');
    const successDoneBtn = document.getElementById('successDoneBtn');

    let currentRow = null;

    // Open Site Details Modal
    function openModal(row) {
      currentRow = row;

      const siteName = row.cells[0].innerText || "Unknown site";
      const location = row.cells[1].innerText || "";
      const startingDate = row.cells[2].innerText || "";
      const finishedDate = row.cells[3].innerText || "";
      const statusCell = row.cells[4];
      const siteId = row.getAttribute('data-site-id');

      modalTitle.innerText = siteName;
      modalStartingDate.innerText = startingDate;
      modalFinishedDate.innerText = finishedDate;
      modalLocation.innerText = location;
      modalNote.value = "";

      // Clear tables
      modalMaterials.querySelector('tbody').innerHTML = "";
      modalTools.querySelector('tbody').innerHTML = "";

      // Fetch materials for this site
      fetch('get_site_materials.php?site_id=' + siteId)
        .then(response => response.text())
        .then(html => {
          modalMaterials.querySelector('tbody').innerHTML = html;
          attachCheckboxListeners(modalMaterials, 'material');
        })
        .catch(error => console.error('Error fetching materials:', error));

      // Fetch tools for this site
      fetch('get_site_tools.php?site_id=' + siteId)
        .then(response => response.text())
        .then(html => {
          modalTools.querySelector('tbody').innerHTML = html;
          attachCheckboxListeners(modalTools, 'tool');
        })
        .catch(error => console.error('Error fetching tools:', error));

      // Set status radio button
      const currentStatusText = statusCell.querySelector('.status-badge').innerText.trim();
      const radios = document.getElementsByName('siteStatus');
      let matched = false;
      
      radios.forEach(radio => {
        if (radio.value.toLowerCase() === currentStatusText.toLowerCase()) {
          radio.checked = true;
          matched = true;
        }
      });
      
      if (!matched) {
        radios[0].checked = true;
      }

      modalOverlay.style.display = "flex";
    }

    // Attach checkbox listeners for enabling/disabling quantity inputs
    function attachCheckboxListeners(table, type) {
      table.querySelectorAll(`input[type="checkbox"]`).forEach(cb => {
        cb.addEventListener('change', function() {
          const qtyInput = this.closest('tr').querySelector('input[type="number"]');
          if (qtyInput) {
            qtyInput.disabled = !this.checked;
            if (!this.checked) qtyInput.value = '';
          }
        });
      });
    }

    // Close Site Details Modal
    modalCloseBtn.addEventListener('click', () => {
      modalOverlay.style.display = "none";
    });

    modalCancelBtn.addEventListener('click', () => {
      modalOverlay.style.display = "none";
    });

    // Save Site Details
    modalDoneBtn.addEventListener('click', () => {
      if (!currentRow) return;

      const selectedStatus = document.querySelector('input[name="siteStatus"]:checked').value;
      const statusBadge = currentRow.cells[4].querySelector('.status-badge');
      
      // Update status text and class
      statusBadge.innerText = selectedStatus;
      statusBadge.className = 'status-badge ' + selectedStatus.toLowerCase();

      // Here you would also send an AJAX request to update the database
      const siteId = currentRow.getAttribute('data-site-id');
      const formData = new FormData();
      formData.append('site_id', siteId);
      formData.append('status', selectedStatus);
      formData.append('note', modalNote.value);

      // Collect selected materials and tools
      const materials = [];
      modalMaterials.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => {
        const row = cb.closest('tr');
        const qtyInput = row.querySelector('input[type="number"]');
        materials.push({
          id: cb.value,
          quantity: qtyInput.value
        });
      });

      const tools = [];
      modalTools.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => {
        const row = cb.closest('tr');
        const qtyInput = row.querySelector('input[type="number"]');
        tools.push({
          id: cb.value,
          quantity: qtyInput.value
        });
      });

      formData.append('materials', JSON.stringify(materials));
      formData.append('tools', JSON.stringify(tools));

      fetch('update_site.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.text())
      .then(data => {
        if (data.trim() === "success") {
          modalOverlay.style.display = "none";
          showSuccessModal();
        } else {
          alert("Error updating site: " + data);
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert("Error updating site");
      });
    });

    // Close modal when clicking outside
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) {
        modalOverlay.style.display = "none";
      }
    });

    // Attach event listeners to all open buttons
    document.querySelectorAll('.open-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const row = e.target.closest('tr');
        openModal(row);
      });
    });

    // Add Site Modal Functions
    addBtn.addEventListener('click', () => {
      siteModal.style.display = 'flex';
    });

    closeBtn.addEventListener('click', () => {
      siteModal.style.display = 'none';
      siteForm.reset();
      // Reset disabled states
      document.querySelectorAll('.material-checkbox, .tool-checkbox').forEach(cb => {
        cb.checked = false;
        const qtyInput = cb.closest('tr').querySelector('input[type="number"]');
        if (qtyInput) {
          qtyInput.disabled = true;
          qtyInput.value = '';
        }
      });
    });

    // Close Add Site modal when clicking outside
    siteModal.addEventListener('click', (e) => {
      if (e.target === siteModal) {
        siteModal.style.display = 'none';
        siteForm.reset();
      }
    });

    // Enable/disable quantity inputs in Add Site form
    document.addEventListener('DOMContentLoaded', function() {
      // For materials in add site form
      document.querySelectorAll('.material-checkbox').forEach(cb => {
        cb.addEventListener('change', function() {
          const qtyInput = this.closest('tr').querySelector('input[type="number"]');
          if (qtyInput) {
            qtyInput.disabled = !this.checked;
            if (!this.checked) qtyInput.value = '';
          }
        });
      });
      
      // For tools in add site form
      document.querySelectorAll('.tool-checkbox').forEach(cb => {
        cb.addEventListener('change', function() {
          const qtyInput = this.closest('tr').querySelector('input[type="number"]');
          if (qtyInput) {
            qtyInput.disabled = !this.checked;
            if (!this.checked) qtyInput.value = '';
          }
        });
      });
    });

    // Handle Add Site form submission
    siteForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const formData = new FormData(siteForm);

      fetch('add_site.php', {
        method: 'POST',
        body: formData
      })
      .then(response => response.text())
      .then(data => {
        if (data.trim() === "success") {
          siteModal.style.display = 'none';
          siteForm.reset();
          showSuccessModal();
          setTimeout(() => {
            location.reload();
          }, 1500);
        } else {
          alert("Error adding site: " + data);
        }
      })
      .catch(error => {
        alert("Error: " + error.message);
      });
    });

    // Success Modal Functions
    function showSuccessModal() {
      successModal.style.display = 'flex';
    }

    successDoneBtn.addEventListener('click', () => {
      successModal.style.display = 'none';
      location.reload();
    });

    successModal.addEventListener('click', (e) => {
      if (e.target === successModal) {
        successModal.style.display = 'none';
        location.reload();
      }
    });

    // Search functionality
    const searchInput = document.querySelector('.search-input');
    searchInput.addEventListener('input', (e) => {
      const searchTerm = e.target.value.toLowerCase();
      const rows = document.querySelectorAll('tbody tr');
      
      rows.forEach(row => {
        const siteName = row.cells[0]?.innerText.toLowerCase() || '';
        const location = row.cells[1]?.innerText.toLowerCase() || '';
        const status = row.cells[4]?.innerText.toLowerCase() || '';
        
        if (siteName.includes(searchTerm) || location.includes(searchTerm) || status.includes(searchTerm)) {
          row.style.display = '';
        } else {
          row.style.display = 'none';
        }
      });
    });

    // Print functionality
    const printBtn = document.getElementById('print-btn');
    printBtn.addEventListener('click', () => {
      window.print();
    });

    // Print styles
    const style = document.createElement('style');
    style.textContent = `
      @media print {
        .navbar,
        .header-actions,
        .action-btn {
          display: none !important;
        }
        
        .sites-section {
          box-shadow: none;
          margin: 0;
        }
        
        body {
          background: white;
        }
      }
    `;
    document.head.appendChild(style);

// Notification functionality
let notifications = [];
let unreadCount = 0;

// Sample notification data matching AdminDB
function loadSampleNotifications() {
  return [
    {
      id: 1,
      type: 'restock',
      title: 'Low Stock Alert',
      message: 'Glass Panels (5mm) are running low. Current quantity: 15 pieces',
      date: new Date('2023-10-15'),
      read: false
    },
    {
      id: 2,
      type: 'restock',
      title: 'Restock Needed',
      message: 'Aluminum Frames (Silver) need to be restocked. Only 8 units left.',
      date: new Date('2023-10-14'),
      read: false
    },
    {
      id: 3,
      type: 'other',
      title: 'New Site Assignment',
      message: 'You have been assigned to the Downtown Office project.',
      date: new Date('2023-10-13'),
      read: true
    },
    {
      id: 4,
      type: 'other',
      title: 'Approval Required',
      message: 'Purchase request #PR-2023-045 needs your approval.',
      date: new Date('2023-10-12'),
      read: false
    },
    {
      id: 5,
      type: 'restock',
      title: 'Critical Stock Level',
      message: 'Silicone Sealant is almost out of stock. Only 3 tubes remaining.',
      date: new Date('2023-10-10'),
      read: false
    }
  ];
}

// Format date for display
function formatDate(date) {
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

// Update notification badge
function updateNotificationBadge() {
  const badge = document.getElementById('notificationBadge');
  unreadCount = notifications.filter(n => !n.read).length;
  
  if (unreadCount > 0) {
    badge.style.display = 'block';
    badge.textContent = '';  // Empty to show just the red circle without number
  } else {
    badge.style.display = 'none';
  }
}

// Render notifications in a specific tab
function renderNotifications(containerId, filterType = 'all') {
  const container = document.getElementById(containerId);
  let filteredNotifications = notifications;
  
  if (filterType === 'restock') {
    filteredNotifications = notifications.filter(n => n.type === 'restock');
  } else if (filterType === 'other') {
    filteredNotifications = notifications.filter(n => n.type === 'other');
  }
  
  if (filteredNotifications.length === 0) {
    container.innerHTML = '<div class="empty-notification">No notifications found</div>';
    return;
  }
  
  // Sort by date (newest first)
  filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  container.innerHTML = filteredNotifications.map(notification => `
    <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
      <div class="notification-title">
        <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
        ${notification.title}
      </div>
      <div class="notification-message">${notification.message}</div>
      <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
    </div>
  `).join('');
  
  // Add click event to mark as read
  container.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {
      const notificationId = parseInt(this.getAttribute('data-id'));
      markAsRead(notificationId);
      this.classList.remove('unread');
    });
  });
}

// Mark notification as read
function markAsRead(notificationId) {
  const notification = notifications.find(n => n.id === notificationId);
  if (notification && !notification.read) {
    notification.read = true;
    updateNotificationBadge();
  }
}

// Mark all notifications as read
function markAllAsRead() {
  notifications.forEach(notification => {
    notification.read = true;
  });
  updateNotificationBadge();
  
  // Update UI
  document.querySelectorAll('.notification-item').forEach(item => {
    item.classList.remove('unread');
  });
}

// Tab switching functionality
function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabPanes = document.querySelectorAll('.tab-pane');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');
      
      // Update active tab button
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // Show corresponding tab pane
      tabPanes.forEach(pane => pane.classList.remove('active'));
      document.getElementById(`${tabId}-tab`).classList.add('active');
      
      // Render notifications for this tab
      if (tabId === 'all') {
        renderNotifications('allNotificationsList');
      } else if (tabId === 'restock') {
        renderNotifications('restockNotificationsList', 'restock');
      } else if (tabId === 'other') {
        renderNotifications('otherNotificationsList', 'other');
      }
    });
  });
}

// Show notification modal
function showNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'flex';
  
  // Render all notifications initially
  renderNotifications('allNotificationsList');
  renderNotifications('restockNotificationsList', 'restock');
  renderNotifications('otherNotificationsList', 'other');
}

// Close notification modal
function closeNotificationModal() {
  const modal = document.getElementById('notificationModal');
  modal.style.display = 'none';
}

// Initialize notification system
document.addEventListener('DOMContentLoaded', function() {
  // Load notifications
  notifications = loadSampleNotifications();
  updateNotificationBadge();
  setupTabs();
  
  // Notification bell click event
  const notificationBell = document.getElementById('notificationBell');
  if (notificationBell) {
    notificationBell.addEventListener('click', showNotificationModal);
  }
  
  // Modal close events
  const notificationCloseBtn = document.getElementById('notificationCloseBtn');
  const notificationDoneBtn = document.getElementById('notificationDoneBtn');
  const markAllReadBtn = document.getElementById('markAllReadBtn');
  
  if (notificationCloseBtn) {
    notificationCloseBtn.addEventListener('click', closeNotificationModal);
  }
  
  if (notificationDoneBtn) {
    notificationDoneBtn.addEventListener('click', closeNotificationModal);
  }
  
  if (markAllReadBtn) {
    markAllReadBtn.addEventListener('click', markAllAsRead);
  }
  
  // Close modal when clicking outside
  const notificationModal = document.getElementById('notificationModal');
  if (notificationModal) {
    notificationModal.addEventListener('click', function(event) {
      if (event.target === this) {
        closeNotificationModal();
      }
    });
  }
});
  </script>
</body>
</html>