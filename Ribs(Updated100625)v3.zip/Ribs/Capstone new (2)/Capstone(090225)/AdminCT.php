<?php
session_start();
// Check if user is logged in
if (!isset($_SESSION['Name'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Art Glass and Aluminum Supplies</title>
  <link rel="stylesheet" href="AdminCT.css?v=2.3"/>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,500&display=swap" />
</head>
<body>
  <nav class="navbar">
    <div class="navbar-logo-section">
      <img src="media/MainLogo.png" class="navbar-logo" alt="Logo" />
      <div class="navbar-company">
       <span>Art Glass & Aluminum Supply</span>
      </div>
    </div>
    <div class="navbar-links">
    <a href="AdminDb.php">Home</a>
      <div class="dropdown">
        <button class="dropbtn">Inventory</button>
        <div class="dropdown-content">
          <a href="AdminMat.php">Materials</a>
          <a href="AdminTools.php">Tools</a>
          <a href="AdminCT.php">Cutting List</a>
          <a href="AdminPurch.php">Purchasing</a>
          <a href="AdminSup.php">Suppliers</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropbtn">Project</button>
        <div class="dropdown-content">
          <a href="AdminSites.php">Sites</a>
          <a href="AdminOG.php">Outgoing</a>
        </div>
      </div>
      <a href="AdminApvl.php">Approvals</a>
      <a href="AdminHsty.php">History</a>
    </div>
<div class="navbar-notification">
      <div class="notification-icon">
        <!-- Bell SVG icon -->
        <svg id="notificationBell" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#31ac0e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
          <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        <span class="notification-badge" id="notificationBadge" style="display: none;"></span>
      </div>
    </div>
    <div class="navbar-profile dropdown">
      <div class="profile-icon">
        <img src="<?php echo isset($_SESSION['profilePhoto']) ? $_SESSION['profilePhoto'] : 'media/user.png'; ?>" alt="Profile" style="width:28px; height:28px; border-radius:50%;">
      </div>
      <span><?php echo isset($_SESSION['Name']) ? htmlspecialchars($_SESSION['Name']) : 'Username'; ?></span>
      <div class="dropdown-content profile-dropdown-content">
        <a href="AdminProf.php">Profile Settings</a>
        <a href="index.php">Log Out</a>
      </div>
    </div>
  </nav>

<div class="cutting-section">
    <div class="section-header">
      <h1>Cutting List</h1>
    </div>

    <div class="cutting-list">
      <!-- 1st Item: SD Section -->
      <div class="cutting-item">
        <div class="item-image">
          <img src="media/SDSection.png" alt="SD Section" class="cutting-image" />
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title">SD Section</h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value="section1">Section 1</div>
                  <div class="dropdown-item" data-value="section2">Section 2</div>
                  <div class="dropdown-item" data-value="section3">Section 3</div>
                  <div class="dropdown-item" data-value="section4">Section 4</div>
                  <div class="dropdown-item" data-value="section5">Section 5</div>
                </div>
              </div>
            </div>
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
          </div>
        </div>
      </div>

      <!-- 2nd Item: 798 Series -->
      <div class="cutting-item">
        <div class="item-image">
          <img src="media/798Series.png" alt="798 Series" class="cutting-image" />
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title">798 Series</h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value="section1">Section 1</div>
                  <div class="dropdown-item" data-value="section2">Section 2</div>
                  <div class="dropdown-item" data-value="section3">Section 3</div>
                  <div class="dropdown-item" data-value="section4">Section 4</div>
                  <div class="dropdown-item" data-value="section5">Section 5</div>
                </div>
              </div>
            </div>
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
          </div>
        </div>
      </div>

      <!-- 3rd Item: 900 Series (2 Panel) -->
      <div class="cutting-item">
        <div class="item-image">
          <img src="media/900Series(2panel).png" alt="900 Series (2 Panel)" class="cutting-image" />
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title">900 Series (2 Panel)</h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value="section1">Section 1</div>
                  <div class="dropdown-item" data-value="section2">Section 2</div>
                  <div class="dropdown-item" data-value="section3">Section 3</div>
                  <div class="dropdown-item" data-value="section4">Section 4</div>
                  <div class="dropdown-item" data-value="section5">Section 5</div>
                </div>
              </div>
            </div>
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
          </div>
        </div>
      </div>

      <!-- 4th Item: 900 Series (4 Panel) -->
      <div class="cutting-item">
        <div class="item-image">
          <img src="media/900Series(4panel).png" alt="900 Series (4 Panel)" class="cutting-image" />
        </div>
        <div class="item-content">
          <div class="item-header">
            <h3 class="item-title">900 Series (4 Panel)</h3>
          </div>
          <div class="item-measurements">
            <div class="measurement-group">
              <label>Section</label>
              <div class="custom-dropdown">
                <button class="dropdown-btn" type="button">
                  <span class="selected-text">Select Section</span>
                  <svg class="dropdown-arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
                <div class="dropdown-menu">
                  <div class="dropdown-item" data-value="section1">Section 1</div>
                  <div class="dropdown-item" data-value="section2">Section 2</div>
                  <div class="dropdown-item" data-value="section3">Section 3</div>
                  <div class="dropdown-item" data-value="section4">Section 4</div>
                  <div class="dropdown-item" data-value="section5">Section 5</div>
                </div>
              </div>
            </div>
            <div class="measurement-group">
              <label>Width (mm)</label>
              <input type="number" class="measurement-input" placeholder="Width">
            </div>
            <div class="measurement-group">
              <label>Height (mm)</label>
              <input type="number" class="measurement-input" placeholder="Height">
            </div>
            <div class="measurement-group">
              <label>Total</label>
              <input type="number" class="measurement-input" placeholder="Total">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

 <!-- Updated Notification Modal -->
  <div id="notificationModal" class="modal" style="display:none;">
    <div class="modal-content">
      <div class="modal-header">
        <h2>Notifications</h2>
        <button id="notificationCloseBtn" class="close-button">×</button>
      </div>
      <div class="modal-body">
        <div class="notification-tabs">
          <button class="tab-button active" data-tab="all">All</button>
          <button class="tab-button" data-tab="restock">Restock Warnings</button>
          <button class="tab-button" data-tab="other">Other Notifications</button>
        </div>
        <div class="notification-content">
          <div id="all-tab" class="tab-pane active">
            <div id="allNotificationsList" class="notification-list"></div>
          </div>
          <div id="restock-tab" class="tab-pane">
            <div id="restockNotificationsList" class="notification-list"></div>
          </div>
          <div id="other-tab" class="tab-pane">
            <div id="otherNotificationsList" class="notification-list"></div>
          </div>
        </div>
        <div class="modal-actions">
          <button id="markAllReadBtn">Mark All as Read</button>
          <button id="notificationDoneBtn">Done</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    // Custom dropdown functionality
    document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
      const btn = dropdown.querySelector('.dropdown-btn');
      const menu = dropdown.querySelector('.dropdown-menu');
      const selectedText = dropdown.querySelector('.selected-text');
      
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        
        // Close other dropdowns
        document.querySelectorAll('.custom-dropdown').forEach(other => {
          if (other !== dropdown) {
            other.classList.remove('active');
          }
        });
        
        dropdown.classList.toggle('active');
      });
      
      dropdown.querySelectorAll('.dropdown-item').forEach(item => {
        item.addEventListener('click', (e) => {
          selectedText.textContent = item.textContent;
          dropdown.classList.remove('active');
          
          // Add selected class for styling
          dropdown.querySelectorAll('.dropdown-item').forEach(i => i.classList.remove('selected'));
          item.classList.add('selected');
        });
      });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', () => {
      document.querySelectorAll('.custom-dropdown').forEach(dropdown => {
        dropdown.classList.remove('active');
      });
    });

// Notification functionality
let notifications = [];
let unreadCount = 0;

async function loadNotifications() {
  try {
    const response = await fetch('get_low_stock.php');
    const lowStockData = await response.json();

    const restockNotifications = lowStockData.map((item, index) => ({
      id: index + 1,
      type: 'restock',
      title: 'Low Stock Alert',
      message: `${item.MaterialsName} are running low. Current quantity: ${item.Quantity}`,
      date: new Date(),
      read: false
    }));

    notifications = restockNotifications;
    updateNotificationBadge();
  } catch (error) {
    console.error('Error loading notifications:', error);
    notifications = [];
    updateNotificationBadge();
  }
}

function formatDate(date) {
  const now = new Date();
  const diffTime = Math.abs(now - date);
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  
  if (diffDays === 1) return 'Yesterday';
  if (diffDays < 7) return `${diffDays} days ago`;
  
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
}

function updateNotificationBadge() {
  const badge = document.getElementById('notificationBadge');
  if (badge) {
    unreadCount = notifications.filter(n => !n.read).length;
    
    if (unreadCount > 0) {
      badge.style.display = 'block';
      badge.textContent = '';
    } else {
      badge.style.display = 'none';
    }
  }
}

function renderNotifications(containerId, filterType = 'all') {
  const container = document.getElementById(containerId);
  if (!container) return;
  
  let filteredNotifications = notifications;
  
  if (filterType === 'restock') {
    filteredNotifications = notifications.filter(n => n.type === 'restock');
  } else if (filterType === 'other') {
    filteredNotifications = notifications.filter(n => n.type === 'other');
  }
  
  if (filteredNotifications.length === 0) {
    container.innerHTML = '<div class="empty-notification">No notifications found</div>';
    return;
  }
  
  filteredNotifications.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  container.innerHTML = filteredNotifications.map(notification => `
    <div class="notification-item ${notification.type} ${notification.read ? '' : 'unread'}" data-id="${notification.id}">
      <div class="notification-title">
        <span class="notification-type">${notification.type === 'restock' ? 'Restock' : 'Other'}</span>
        ${notification.title}
      </div>
      <div class="notification-message">${notification.message}</div>
      <div class="notification-date">Declared on: ${formatDate(notification.date)}</div>
    </div>
  `).join('');
  
  container.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', function() {
      const notificationId = parseInt(this.getAttribute('data-id'));
      markAsRead(notificationId);
      this.classList.remove('unread');
    });
  });
}

function markAsRead(notificationId) {
  const notification = notifications.find(n => n.id === notificationId);
  if (notification && !notification.read) {
    notification.read = true;
    updateNotificationBadge();
  }
}

function markAllAsRead() {
  notifications.forEach(notification => {
    notification.read = true;
  });
  updateNotificationBadge();
  
  document.querySelectorAll('.notification-item').forEach(item => {
    item.classList.remove('unread');
  });
}

function setupTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  const tabPanes = document.querySelectorAll('.tab-pane');
  
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.getAttribute('data-tab');
      
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      tabPanes.forEach(pane => pane.classList.remove('active'));
      const targetTab = document.getElementById(`${tabId}-tab`);
      if (targetTab) {
        targetTab.classList.add('active');
      }
      
      if (tabId === 'all') {
        renderNotifications('allNotificationsList');
      } else if (tabId === 'restock') {
        renderNotifications('restockNotificationsList', 'restock');
      } else if (tabId === 'other') {
        renderNotifications('otherNotificationsList', 'other');
      }
    });
  });
}

function showNotificationModal() {
  const modal = document.getElementById('notificationModal');
  if (modal) {
    modal.style.display = 'flex';
    
    renderNotifications('allNotificationsList');
    renderNotifications('restockNotificationsList', 'restock');
    renderNotifications('otherNotificationsList', 'other');
  }
}

function closeNotificationModal() {
  const modal = document.getElementById('notificationModal');
  if (modal) {
    modal.style.display = 'none';
  }
}

document.addEventListener('DOMContentLoaded', async function() {
  await loadNotifications();
  updateNotificationBadge();
  setupTabs();
  
  const notificationBell = document.getElementById('notificationBell');
  if (notificationBell) {
    notificationBell.addEventListener('click', showNotificationModal);
  }
  
  const notificationCloseBtn = document.getElementById('notificationCloseBtn');
  const notificationDoneBtn = document.getElementById('notificationDoneBtn');
  const markAllReadBtn = document.getElementById('markAllReadBtn');
  
  if (notificationCloseBtn) {
    notificationCloseBtn.addEventListener('click', closeNotificationModal);
  }
  
  if (notificationDoneBtn) {
    notificationDoneBtn.addEventListener('click', closeNotificationModal);
  }
  
  if (markAllReadBtn) {
    markAllReadBtn.addEventListener('click', markAllAsRead);
  }
  
  const notificationModal = document.getElementById('notificationModal');
  if (notificationModal) {
    notificationModal.addEventListener('click', function(event) {
      if (event.target === this) {
        closeNotificationModal();
      }
    });
  }
});
  </script>
</body>
</html>